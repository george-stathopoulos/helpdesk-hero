import { __ } from '@wordpress/i18n';
import { Card, PageHead } from '../ui/components/ui';
import { ProBadge } from '../ui/components/kit';
import Icon from '../ui/components/Icon';

const boot = window.hdhBoot || {};

/**
 * Where tickets are answered. The free hub has its own inbox and emails the team;
 * Helpdesk Hero Pro replaces this page with Help Scout and Zendesk settings.
 *
 * @return {JSX.Element} Page.
 */
export default function Helpdesk() {
	return (
		<>
			<PageHead
				title={ __( 'Help desk', 'helpdesk-hero-hub' ) }
				lede={ __(
					'Where your team answers tickets.',
					'helpdesk-hero-hub'
				) }
			/>
			<div
				className="hdh-choices"
				style={ { gridTemplateColumns: 'repeat(2, minmax(0, 1fr))' } }
			>
				<div className="hdh-choice is-active">
					<Icon name="inbox" size={ 22 } />
					<strong>
						{ __( 'Hub inbox and email', 'helpdesk-hero-hub' ) }
					</strong>
					<span>
						{ __(
							'In use. New tickets and customer replies are emailed to your team (Settings › Team email), and you answer in the Inbox. Customers see your replies in their dashboard and get an email.',
							'helpdesk-hero-hub'
						) }
					</span>
				</div>
				<a
					className="hdh-choice"
					href={ boot.proUrl }
					target="_blank"
					rel="noopener noreferrer"
				>
					<Icon name="plug" size={ 22 } />
					<strong>
						{ __( 'Help Scout and Zendesk', 'helpdesk-hero-hub' ) }
						<ProBadge />
					</strong>
					<span>
						{ __(
							'Tickets become Help Scout conversations or Zendesk tickets with the diagnostics attached and a health-check note for your agents. Replies and status sync both ways.',
							'helpdesk-hero-hub'
						) }
					</span>
				</a>
			</div>
			<Card style={ { marginTop: 18 } }>
				<p className="hdh-muted">
					{ __(
						'Whichever you use, customers keep the same experience: tickets and replies in their dashboard, and your team logs in from the hub.',
						'helpdesk-hero-hub'
					) }
				</p>
			</Card>
		</>
	);
}
