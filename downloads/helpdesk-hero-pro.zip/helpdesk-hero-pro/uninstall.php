<?php
/**
 * Uninstall: release the license and remove Pro settings, time entries and the Agent role.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'helpdesk_hero_pro_settings' );
delete_option( 'helpdesk_hero_pro_supporters' );
delete_option( 'helpdesk_hero_pro_license' );
foreach ( array( 'helpdesk_hero_pro_macros', 'helpdesk_hero_pro_notify', 'helpdesk_hero_pro_time_db', 'helpdesk_hero_pro_sla', 'helpdesk_hero_pro_statuses', 'helpdesk_hero_pro_fields', 'helpdesk_hero_pro_attachments', 'helpdesk_hero_pro_modules', 'helpdesk_hero_pro_billing', 'helpdesk_hero_pro_services', 'helpdesk_hero_pro_site_billing', 'helpdesk_hero_pro_automations', 'helpdesk_hero_pro_views', 'helpdesk_hero_pro_examples' ) as $helpdesk_hero_pro_option ) {
	delete_option( $helpdesk_hero_pro_option );
}
global $wpdb;
$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'helpdesk_hero_pro_time' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
delete_transient( 'helpdesk_hero_pro_update_manifest' );
wp_clear_scheduled_hook( 'helpdesk_hero_pro_license_check' );
wp_clear_scheduled_hook( 'helpdesk_hero_pro_triage' );
wp_clear_scheduled_hook( 'helpdesk_hero_pro_sla_check' );
wp_clear_scheduled_hook( 'helpdesk_hero_pro_automations', 'helpdesk_hero_pro_views', 'helpdesk_hero_pro_examples' );
delete_option( 'helpdesk_hero_pro_round_robin' );
delete_metadata( 'user', 0, 'helpdesk_hero_pro_views', '', true );
remove_role( 'helpdesk_hero_agent' );
$helpdesk_hero_pro_admin = get_role( 'administrator' );
if ( $helpdesk_hero_pro_admin ) {
	$helpdesk_hero_pro_admin->remove_cap( 'helpdesk_hero_hub_access' );
}
