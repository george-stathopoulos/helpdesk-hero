<?php
/**
 * Uninstall: release the license and remove Pro settings and the Agent role.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'helpdesk_hero_pro_settings' );
delete_option( 'helpdesk_hero_pro_supporters' );
delete_option( 'helpdesk_hero_pro_license' );
delete_transient( 'helpdesk_hero_pro_update_manifest' );
wp_clear_scheduled_hook( 'helpdesk_hero_pro_license_check' );
wp_clear_scheduled_hook( 'helpdesk_hero_pro_triage' );
remove_role( 'helpdesk_hero_agent' );
$helpdesk_hero_pro_admin = get_role( 'administrator' );
if ( $helpdesk_hero_pro_admin ) {
	$helpdesk_hero_pro_admin->remove_cap( 'helpdesk_hero_hub_access' );
}
