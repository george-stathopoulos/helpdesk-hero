<?php
/**
 * Plugin Name:       Helpdesk Hero Pro
 * Plugin URI:        https://wordpress.org/plugins/helpdesk-hero-hub/
 * Description:       Adds to Helpdesk Hero Hub: Help Scout and Zendesk, advanced analytics with PDF reports, your branding on customer sites, customer reviews, AI triage and reply drafts, broadcasts and a Support Agent role.
 * Version:           2.1.0
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  helpdesk-hero-hub
 * Author:            George Stathopoulos
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       helpdesk-hero-pro
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

define( 'HELPDESK_HERO_PRO_VERSION', '2.1.0' );
define( 'HELPDESK_HERO_PRO_FILE', __FILE__ );
define( 'HELPDESK_HERO_PRO_DIR', plugin_dir_path( __FILE__ ) );
define( 'HELPDESK_HERO_PRO_URL', plugin_dir_url( __FILE__ ) );

/*
 * Store configuration. Set these to your Lemon Squeezy store before building a release.
 *
 * - HELPDESK_HERO_PRO_STORE_ID / HELPDESK_HERO_PRO_PRODUCT_ID: license keys from any other store or product are rejected.
 *   Leave HELPDESK_HERO_PRO_PRODUCT_ID at 0 to accept every product in the store.
 * - HELPDESK_HERO_PRO_BUY_URL: where the "Buy a license" button points.
 * - HELPDESK_HERO_PRO_UPDATE_URL: JSON update manifest (see includes/class-updater.php). Empty disables updates.
 */
defined( 'HELPDESK_HERO_PRO_STORE_ID' ) || define( 'HELPDESK_HERO_PRO_STORE_ID', 0 );
defined( 'HELPDESK_HERO_PRO_PRODUCT_ID' ) || define( 'HELPDESK_HERO_PRO_PRODUCT_ID', 0 );
defined( 'HELPDESK_HERO_PRO_BUY_URL' ) || define( 'HELPDESK_HERO_PRO_BUY_URL', '' );
defined( 'HELPDESK_HERO_PRO_UPDATE_URL' ) || define( 'HELPDESK_HERO_PRO_UPDATE_URL', '' );

require_once HELPDESK_HERO_PRO_DIR . 'includes/class-license.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-modules.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-updater.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-triage.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-team.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-analytics.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-macros.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-notify.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-time.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-billing.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-automations.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-views.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-examples.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-sla.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-statuses.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-extras.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-rest.php';
require_once HELPDESK_HERO_PRO_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'Helpdesk_Hero_Pro_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Helpdesk_Hero_Pro_Plugin', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		// Help desk connectors extend the hub's base class, so load them once the hub is loaded.
		if ( class_exists( 'Helpdesk_Hero_Hub_Helpdesk' ) ) {
			require_once HELPDESK_HERO_PRO_DIR . 'includes/class-helpdesks.php';
			require_once HELPDESK_HERO_PRO_DIR . 'includes/helpdesks/class-helpscout.php';
			require_once HELPDESK_HERO_PRO_DIR . 'includes/helpdesks/class-zendesk.php';
		}
		Helpdesk_Hero_Pro_Plugin::boot();
	},
	20
);
