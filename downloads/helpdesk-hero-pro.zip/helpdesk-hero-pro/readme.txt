=== Helpdesk Hero Pro ===
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add-on for Helpdesk Hero Hub.

== Description ==

Needs the free Helpdesk Hero Hub plugin. Customer sites don't need anything extra.

* **Help Scout and Zendesk:** tickets become conversations or tickets with the health check and diagnostics as an internal note; replies and status sync both ways.
* **Advanced analytics:** any date range, per site; categories, priorities, tags, recurring issues, busiest sites and customer ratings; PDF reports for clients.
* **Branding:** your help center name, logo, colour, contact details and note on every customer's help center.
* **Customer ratings:** customers rate support when a ticket closes or access ends, with a short comment.
* **Supporters:** choose which team members reply to customers and log in to their sites, and the name customers see. Each supporter gets a personal temporary account on the customer's site, deleted with every other support account when access ends.
* **Support Agent role** for team members who are not administrators.
* **AI triage** brief for every new ticket (summary, likely cause, suspects, first steps) and reply drafts, using the AI provider connected to the hub site (WordPress 7.0 AI Client).
* **Messages to every connected site** at once.

== External services ==

* **Lemon Squeezy License API** (https://api.lemonsqueezy.com/): activates and checks your license key, sending the key and the site's domain. [Terms](https://www.lemonsqueezy.com/terms) and [privacy policy](https://www.lemonsqueezy.com/privacy).
* **Help Scout** (only if chosen under Help desk): tickets, replies, internal notes and diagnostics are sent to `https://api.helpscout.net/`, and replies are read back every 5 minutes. [Terms](https://www.helpscout.com/company/legal/terms-of-service/) and [privacy policy](https://www.helpscout.com/company/legal/privacy/).
* **Zendesk** (only if chosen under Help desk): the same data is sent to `https://YOUR-SUBDOMAIN.zendesk.com/api/v2/`, and comments are read back every 5 minutes. [Terms](https://www.zendesk.com/company/agreements-and-terms/main-services-agreement/) and [privacy policy](https://www.zendesk.com/company/agreements-and-terms/privacy-notice/).
* **Your AI provider** (only when AI triage is used), through WordPress's AI Client.

== Changelog ==

= 2.0.0 =
* Works with Helpdesk Hero Hub; pages and panels in the new dashboard.
* Help Scout and Zendesk moved here from the hub.
* Advanced analytics with PDF reports, customer ratings, Supporters, help center branding.

= 1.0.0 =
* First release.
