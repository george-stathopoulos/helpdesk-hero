=== Helpdesk Hero Pro ===
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add-on for Helpdesk Hero Hub.

== Description ==

Needs the free Helpdesk Hero Hub plugin. Customer sites don't need anything extra.

* **Advanced analytics:** any date range, per site; categories, priorities, tags, recurring issues, busiest sites and customer ratings; PDF reports for clients.
* **White label:** your help center name, logo (from the Media Library), colour, link, contact details and note on every customer's help center, with a live preview.
* **Customer ratings:** customers rate support when a ticket closes or access ends, with a short comment.
* **Supporters:** choose which team members reply to customers and log in to their sites, and the name customers see. Each supporter gets a personal temporary account on the customer's site, deleted with every other support account when access ends.
* **Support Agent role** for team members who are not administrators.
* **AI triage** brief for every new ticket (summary, likely cause, suspects, first steps) and reply drafts, using the AI provider connected to the hub site (WordPress 7.0 AI Client). Works with the free, local AI Provider for WebLLM: the model runs in your browser, with no API key and nothing sent to an outside service.
* **Messages to every connected site** at once.
* **Help Scout and Zendesk:** coming soon.

To try Pro on a test site (local, development or staging environment, a local address, or WordPress Playground), enter TEST as the license key.

== External services ==

* **Lemon Squeezy License API** (https://api.lemonsqueezy.com/): activates and checks your license key, sending the key and the site's domain. [Terms](https://www.lemonsqueezy.com/terms) and [privacy policy](https://www.lemonsqueezy.com/privacy).
* **Your AI provider** (only when AI triage is used), through WordPress's AI Client.

== Changelog ==

= 2.0.0 =
* Works with Helpdesk Hero Hub; pages and panels in the new dashboard.
* Advanced analytics with PDF reports, customer ratings, Supporters, white label.
* TEST license key for test sites.
* Works with the local AI Provider for WebLLM (briefs are written when a ticket is opened).
* Help Scout and Zendesk shown as coming soon until they're released.

= 1.0.0 =
* First release.
