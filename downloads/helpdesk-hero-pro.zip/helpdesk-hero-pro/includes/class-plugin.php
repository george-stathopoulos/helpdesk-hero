<?php
/**
 * Pro bootstrap.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Wires Pro into the hub. The license screen is always available; the features switch on
 * only with an active license.
 */
final class Helpdesk_Hero_Pro_Plugin {

	const OPTION = 'helpdesk_hero_pro_settings';

	/**
	 * Settings merged over defaults.
	 *
	 * @return array
	 */
	public static function settings() {
		$stored = get_option( self::OPTION, array() );
		return array_merge(
			array(
				'auto_triage' => true,
				'triage_note' => true,
				'brand_name'    => '',
				'brand_logo'    => '',
				'brand_color'   => '',
				'brand_intro'   => '',
				'brand_url'     => '',
				'brand_contact' => '',
			),
			is_array( $stored ) ? $stored : array()
		);
	}

	/**
	 * Save settings.
	 *
	 * @param array $in Raw values.
	 */
	public static function save_settings( array $in ) {
		$color = sanitize_hex_color( (string) ( $in['brand_color'] ?? '' ) );
		update_option(
			self::OPTION,
			array(
				'auto_triage' => ! empty( $in['auto_triage'] ),
				'triage_note' => ! empty( $in['triage_note'] ),
				'brand_logo'  => esc_url_raw( (string) ( $in['brand_logo'] ?? '' ), array( 'http', 'https' ) ),
				'brand_color' => $color ? $color : '',
				'brand_intro' => sanitize_textarea_field( (string) ( $in['brand_intro'] ?? '' ) ),
				'brand_url'   => esc_url_raw( (string) ( $in['brand_url'] ?? '' ) ),
				'brand_name'    => substr( sanitize_text_field( (string) ( $in['brand_name'] ?? '' ) ), 0, 40 ),
				'brand_contact' => substr( sanitize_textarea_field( (string) ( $in['brand_contact'] ?? '' ) ), 0, 500 ),
			),
			false
		);
	}

	/**
	 * Start once all plugins are loaded, if the hub is active.
	 */
	public static function boot() {
		if ( ! class_exists( 'Helpdesk_Hero_Hub_Plugin' ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'missing_notice' ) );
			return;
		}
		Helpdesk_Hero_Pro_Updater::init();
		add_action( Helpdesk_Hero_Pro_License::CRON, array( 'Helpdesk_Hero_Pro_License', 'check' ) );
		add_action( 'rest_api_init', array( 'Helpdesk_Hero_Pro_REST', 'register' ) );
		add_action( 'helpdesk_hero_hub_admin_enqueue', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( HELPDESK_HERO_PRO_FILE ), array( __CLASS__, 'action_links' ) );
		// Pro's settings travel with the hub's backups, licensed or not.
		add_filter( 'helpdesk_hero_hub_backup', array( __CLASS__, 'backup' ), 10, 2 );
		add_action( 'helpdesk_hero_hub_restore', array( __CLASS__, 'restore' ) );

		if ( Helpdesk_Hero_Pro_License::is_active() ) {
			add_filter( 'helpdesk_hero_hub_pro_active', '__return_true' );
			Helpdesk_Hero_Pro_Helpdesks::init();
			Helpdesk_Hero_Pro_Team::init();
			// The time table exists whether or not the module is on, so data survives switching.
			Helpdesk_Hero_Pro_Time::init();
			$modules = array(
				'analytics'   => array( 'Helpdesk_Hero_Pro_Analytics', 'init' ),
				'triage'      => array( 'Helpdesk_Hero_Pro_Triage', 'init' ),
				'replies'     => array( 'Helpdesk_Hero_Pro_Macros', 'init' ),
				'notify'      => array( 'Helpdesk_Hero_Pro_Notify', 'init' ),
				'sla'         => array( 'Helpdesk_Hero_Pro_SLA', 'init' ),
				'statuses'    => array( 'Helpdesk_Hero_Pro_Statuses', 'init' ),
				'fields'      => array( 'Helpdesk_Hero_Pro_Extras', 'init_fields' ),
				'attachments' => array( 'Helpdesk_Hero_Pro_Extras', 'init_attachments' ),
				'time'        => array( 'Helpdesk_Hero_Pro_Billing', 'init' ),
				'automations' => array( 'Helpdesk_Hero_Pro_Automations', 'init' ),
			);
			foreach ( $modules as $id => $init ) {
				if ( Helpdesk_Hero_Pro_Modules::on( $id ) ) {
					call_user_func( $init );
				}
			}
			/**
			 * Fires after Pro modules are loaded (later modules hook in here).
			 */
			do_action( 'helpdesk_hero_pro_modules_loaded' );
		}
	}

	/**
	 * Add Pro's settings, help desk connection and supporters to a hub backup. The license key
	 * isn't included: activate it again on the new install.
	 *
	 * @param array $data    Backup.
	 * @param bool  $secrets Include secrets (help desk keys).
	 * @return array
	 */
	public static function backup( $data, $secrets ) {
		$supporters = array();
		foreach ( Helpdesk_Hero_Pro_Team::supporters() as $row ) {
			$user = get_userdata( (int) $row['user_id'] );
			if ( $user ) {
				$supporters[] = array(
					'email' => $user->user_email,
					'name'  => $row['name'],
				);
			}
		}
		$data['addons']['pro'] = array(
			'settings'         => get_option( self::OPTION, null ),
			'helpdesk'         => get_option( Helpdesk_Hero_Pro_Helpdesks::OPTION, null ),
			'helpdesk_secrets' => $secrets ? get_option( Helpdesk_Hero_Pro_Helpdesks::SECRETS, null ) : null,
			'supporters'       => $supporters,
			'macros'           => get_option( Helpdesk_Hero_Pro_Macros::OPTION, null ),
			'modules'          => get_option( Helpdesk_Hero_Pro_Modules::OPTION, null ),
			'automations'      => get_option( Helpdesk_Hero_Pro_Automations::OPTION, null ),
			'views'            => get_option( Helpdesk_Hero_Pro_Views::OPTION, null ),
			'sla'              => get_option( Helpdesk_Hero_Pro_SLA::OPTION, null ),
			'statuses'         => get_option( Helpdesk_Hero_Pro_Statuses::OPTION, null ),
			'fields'           => get_option( Helpdesk_Hero_Pro_Extras::FIELDS, null ),
			'billing'          => get_option( Helpdesk_Hero_Pro_Billing::SETTINGS, null ),
			'services'         => get_option( Helpdesk_Hero_Pro_Billing::SERVICES, null ),
			'site_billing'     => get_option( Helpdesk_Hero_Pro_Billing::SITES, null ),
			'attachments'      => get_option( Helpdesk_Hero_Pro_Extras::ATTACHMENTS, null ),
			'notify'           => $secrets ? Helpdesk_Hero_Pro_Notify::settings() : null,
			'time'             => self::time_rows(),
		);
		return $data;
	}

	/**
	 * Time entries for a backup.
	 *
	 * @return array[]
	 */
	private static function time_rows() {
		global $wpdb;
		if ( get_option( Helpdesk_Hero_Pro_Time::DB_OPTION ) !== Helpdesk_Hero_Pro_Time::DB_VERSION ) {
			return array();
		}
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY id ASC', Helpdesk_Hero_Pro_Time::table() ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Restore Pro's part of a hub backup. Supporters are matched to users by email address.
	 *
	 * @param array $data Backup.
	 */
	public static function restore( $data ) {
		$pro = (array) ( $data['addons']['pro'] ?? array() );
		if ( ! $pro ) {
			return;
		}
		if ( is_array( $pro['settings'] ?? null ) ) {
			self::save_settings( $pro['settings'] );
		}
		if ( is_array( $pro['helpdesk'] ?? null ) ) {
			update_option( Helpdesk_Hero_Pro_Helpdesks::OPTION, array_map( 'sanitize_text_field', array_filter( $pro['helpdesk'], 'is_scalar' ) ), false );
		}
		if ( is_array( $pro['helpdesk_secrets'] ?? null ) ) {
			update_option( Helpdesk_Hero_Pro_Helpdesks::SECRETS, array_map( 'strval', array_filter( $pro['helpdesk_secrets'], 'is_scalar' ) ), false );
		}
		$rows = array();
		foreach ( (array) ( $pro['supporters'] ?? array() ) as $row ) {
			$user = is_array( $row ) ? get_user_by( 'email', (string) ( $row['email'] ?? '' ) ) : false;
			if ( $user ) {
				$rows[] = array(
					'user_id' => $user->ID,
					'name'    => (string) ( $row['name'] ?? '' ),
				);
			}
		}
		Helpdesk_Hero_Pro_Team::save_supporters( $rows );
		if ( is_array( $pro['modules'] ?? null ) ) {
			update_option( Helpdesk_Hero_Pro_Modules::OPTION, array_map( 'boolval', array_intersect_key( $pro['modules'], Helpdesk_Hero_Pro_Modules::all() ) ), false );
		}
		if ( is_array( $pro['macros'] ?? null ) ) {
			Helpdesk_Hero_Pro_Macros::save( $pro['macros'] );
		}
		if ( is_array( $pro['views'] ?? null ) ) {
			update_option( Helpdesk_Hero_Pro_Views::OPTION, array(), false );
			foreach ( $pro['views'] as $view ) {
				if ( is_array( $view ) ) {
					$list   = Helpdesk_Hero_Pro_Views::shared();
					$list[] = $view;
					update_option( Helpdesk_Hero_Pro_Views::OPTION, $list, false );
				}
			}
		}
		if ( is_array( $pro['automations'] ?? null ) ) {
			Helpdesk_Hero_Pro_Automations::save( $pro['automations'] );
		}
		if ( is_array( $pro['statuses'] ?? null ) ) {
			Helpdesk_Hero_Pro_Statuses::save( $pro['statuses'] );
		}
		if ( is_array( $pro['sla'] ?? null ) ) {
			Helpdesk_Hero_Pro_SLA::save( $pro['sla'] );
		}
		if ( is_array( $pro['billing'] ?? null ) ) {
			Helpdesk_Hero_Pro_Billing::save_settings( $pro['billing'] );
		}
		if ( is_array( $pro['services'] ?? null ) ) {
			Helpdesk_Hero_Pro_Billing::save_services( $pro['services'] );
		}
		if ( is_array( $pro['site_billing'] ?? null ) ) {
			foreach ( $pro['site_billing'] as $site_id => $row ) {
				Helpdesk_Hero_Pro_Billing::save_site( (int) $site_id, (array) $row );
			}
		}
		if ( is_array( $pro['fields'] ?? null ) ) {
			Helpdesk_Hero_Pro_Extras::save_fields( $pro['fields'] );
		}
		if ( is_array( $pro['attachments'] ?? null ) ) {
			Helpdesk_Hero_Pro_Extras::save_attachments( $pro['attachments'] );
		}
		if ( is_array( $pro['notify'] ?? null ) ) {
			// Settings arrive readable (the backup file itself is encrypted); store them encrypted.
			$notify = $pro['notify'];
			update_option( Helpdesk_Hero_Pro_Notify::OPTION, array(), false );
			$hooks = array();
			foreach ( (array) ( $notify['webhooks'] ?? array() ) as $hook ) {
				$hooks[] = array(
					'id'     => sanitize_key( (string) ( $hook['id'] ?? '' ) ),
					'url'    => esc_url_raw( (string) ( $hook['url'] ?? '' ), array( 'https' ) ),
					'events' => array_map( 'sanitize_key', (array) ( $hook['events'] ?? array() ) ),
					'secret' => Helpdesk_Hero_Hub_Crypto::encrypt( (string) ( $hook['secret'] ?? '' ) ),
				);
			}
			update_option(
				Helpdesk_Hero_Pro_Notify::OPTION,
				array(
					'slack_url'    => Helpdesk_Hero_Hub_Crypto::encrypt( esc_url_raw( (string) ( $notify['slack_url'] ?? '' ), array( 'https' ) ) ),
					'slack_events' => array_map( 'sanitize_key', (array) ( $notify['slack_events'] ?? array() ) ),
					'webhooks'     => $hooks,
				),
				false
			);
		}
		if ( is_array( $pro['time'] ?? null ) ) {
			global $wpdb;
			Helpdesk_Hero_Pro_Time::maybe_install();
			$wpdb->query( $wpdb->prepare( 'DELETE FROM %i', Helpdesk_Hero_Pro_Time::table() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			foreach ( $pro['time'] as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
					Helpdesk_Hero_Pro_Time::table(),
					array(
						'id'         => (int) ( $row['id'] ?? 0 ),
						'ticket_id'  => (int) ( $row['ticket_id'] ?? 0 ),
						'site_id'    => (int) ( $row['site_id'] ?? 0 ),
						'user_id'    => (int) ( $row['user_id'] ?? 0 ),
						'kind'         => 'charge' === ( $row['kind'] ?? '' ) ? 'charge' : 'time',
						'service'      => sanitize_key( (string) ( $row['service'] ?? '' ) ),
						'rate'         => (float) ( $row['rate'] ?? 0 ),
						'amount'       => (float) ( $row['amount'] ?? 0 ),
						'state'        => in_array( $row['state'] ?? '', Helpdesk_Hero_Pro_Time::STATES, true ) ? $row['state'] : 'unbilled',
						'invoice_ref'  => sanitize_text_field( (string) ( $row['invoice_ref'] ?? '' ) ),
						'billing_note' => sanitize_text_field( (string) ( $row['billing_note'] ?? '' ) ),
						'source'       => sanitize_key( (string) ( $row['source'] ?? 'manual' ) ),
						'source_ref'   => sanitize_key( (string) ( $row['source_ref'] ?? '' ) ),
						'minutes'    => (int) ( $row['minutes'] ?? 0 ),
						'billable'   => empty( $row['billable'] ) ? 0 : 1,
						'note'       => sanitize_text_field( (string) ( $row['note'] ?? '' ) ),
						'worked_on'  => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $row['worked_on'] ?? '' ) ) ? $row['worked_on'] : gmdate( 'Y-m-d' ),
						'created_at' => sanitize_text_field( (string) ( $row['created_at'] ?? gmdate( 'Y-m-d H:i:s' ) ) ),
					)
				);
			}
		}
	}

	/**
	 * Activation.
	 */
	public static function activate() {
		if ( ! wp_next_scheduled( Helpdesk_Hero_Pro_License::CRON ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', Helpdesk_Hero_Pro_License::CRON );
		}
		Helpdesk_Hero_Pro_Team::add_role();
	}

	/**
	 * Deactivation. The license and settings are kept.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( Helpdesk_Hero_Pro_License::CRON );
		wp_clear_scheduled_hook( Helpdesk_Hero_Pro_SLA::CRON );
		wp_clear_scheduled_hook( Helpdesk_Hero_Pro_Automations::CRON );
		Helpdesk_Hero_Pro_Team::remove_role();
	}

	/**
	 * Load the Pro pages and panels into the hub dashboard.
	 *
	 * @param string $handle Hub dashboard script handle.
	 */
	public static function assets( $handle ) {
		$asset_file = HELPDESK_HERO_PRO_DIR . 'build/index.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;
		// The Media Library, for choosing a white label logo.
		wp_enqueue_media();
		wp_enqueue_script( 'helpdesk-hero-pro-admin', HELPDESK_HERO_PRO_URL . 'build/index.js', array_merge( $asset['dependencies'], array( $handle ) ), $asset['version'], true );
		wp_set_script_translations( 'helpdesk-hero-pro-admin', 'helpdesk-hero-pro' );
		wp_add_inline_script(
			'helpdesk-hero-pro-admin',
			'window.hdhProBoot = ' . wp_json_encode(
				array(
					'licensed' => Helpdesk_Hero_Pro_License::is_active(),
					'modules'  => Helpdesk_Hero_Pro_Modules::states(),
					'buyUrl'   => (string) HELPDESK_HERO_PRO_BUY_URL,
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Plugins screen link.
	 *
	 * @param string[] $links Links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=helpdesk-hero-hub#/settings/pro' ) ) . '">' . esc_html( Helpdesk_Hero_Pro_License::is_active() ? __( 'Settings', 'helpdesk-hero-pro' ) : __( 'Activate license', 'helpdesk-hero-pro' ) ) . '</a>' );
		return $links;
	}

	/**
	 * Notice when the hub is missing.
	 */
	public static function missing_notice() {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'Helpdesk Hero Pro needs the free Helpdesk Hero Hub plugin. Install and activate it to use Pro.', 'helpdesk-hero-pro' ) . '</p></div>';
		}
	}
}
