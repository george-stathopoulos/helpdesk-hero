<?php
/**
 * Pro modules.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Each Pro feature is a module the team can switch off. A module that's off does nothing and
 * disappears from the menus, the ticket sidebar, the reply box and Settings. Its settings and
 * data are kept, so switching it back on picks up where it left off.
 */
final class Helpdesk_Hero_Pro_Modules {

	const OPTION = 'helpdesk_hero_pro_modules';

	/**
	 * All modules: id => { label, description, group }.
	 *
	 * @return array<string, array>
	 */
	public static function all() {
		return array(
			'replies'     => array(
				'label' => __( 'Saved replies', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Replies your team inserts with one click, with the customer’s name and site filled in.', 'helpdesk-hero-pro' ),
				'group' => 'work',
			),
			'views'       => array(
				'label' => __( 'Inbox views', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Saved filters as tabs above the Inbox, such as “My tickets” or “VIP with low ratings”, for you or the whole team.', 'helpdesk-hero-pro' ),
				'group' => 'work',
			),
			'automations' => array(
				'label' => __( 'Automations', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Rules that act on tickets for you: assign, tag, change status, follow up, notify.', 'helpdesk-hero-pro' ),
				'group' => 'work',
			),
			'time'        => array(
				'label' => __( 'Time & billing', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Track time per ticket, services with rates, retainers, and what’s been invoiced and paid.', 'helpdesk-hero-pro' ),
				'group' => 'work',
			),
			'sla'         => array(
				'label' => __( 'Service levels (SLA)', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Reply and resolution targets per customer tier, with warnings before they’re missed.', 'helpdesk-hero-pro' ),
				'group' => 'work',
			),
			'notify'      => array(
				'label' => __( 'Slack and webhooks', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Tell your team’s chat and other tools when tickets arrive or need attention.', 'helpdesk-hero-pro' ),
				'group' => 'work',
			),
			'statuses'    => array(
				'label' => __( 'Custom statuses', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Statuses such as “In progress” on top of Open, Waiting and Closed.', 'helpdesk-hero-pro' ),
				'group' => 'tickets',
			),
			'fields'      => array(
				'label' => __( 'Ticket fields', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Extra questions on the customer’s New ticket screen.', 'helpdesk-hero-pro' ),
				'group' => 'tickets',
			),
			'attachments' => array(
				'label' => __( 'Attachments', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Screenshots and files on tickets and replies, in both directions.', 'helpdesk-hero-pro' ),
				'group' => 'tickets',
			),
			'merge'       => array(
				'label' => __( 'Merge tickets', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Combine duplicate tickets from the same site.', 'helpdesk-hero-pro' ),
				'group' => 'tickets',
			),
			'analytics'   => array(
				'label' => __( 'Analytics and ratings', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Reports for any period and site, PDF exports, and customer ratings.', 'helpdesk-hero-pro' ),
				'group' => 'insight',
			),
			'triage'      => array(
				'label' => __( 'AI triage and drafts', 'helpdesk-hero-pro' ),
				'desc'  => __( 'A brief for each new ticket and reply drafts, with your site’s AI provider.', 'helpdesk-hero-pro' ),
				'group' => 'insight',
			),
			'whitelabel'  => array(
				'label' => __( 'White label', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Your name, logo, colour, links and text in your customers’ help center.', 'helpdesk-hero-pro' ),
				'group' => 'customers',
			),
			'broadcast'   => array(
				'label' => __( 'Messages to every site', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Send one dashboard message to many sites at once.', 'helpdesk-hero-pro' ),
				'group' => 'customers',
			),
			'usage'       => array(
				'label' => __( 'Usage for customers', 'helpdesk-hero-pro' ),
				'desc'  => __( 'Customers see time spent on their tickets and how much of their retainer is used (needs Time & billing).', 'helpdesk-hero-pro' ),
				'group' => 'customers',
			),
		);
	}

	/**
	 * Which modules are on (all, unless switched off).
	 *
	 * @return array<string, bool>
	 */
	public static function states() {
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		$out    = array();
		foreach ( array_keys( self::all() ) as $id ) {
			// Customer-facing usage is opt-in; everything else starts on.
			$out[ $id ] = array_key_exists( $id, $stored ) ? (bool) $stored[ $id ] : 'usage' !== $id;
		}
		return $out;
	}

	/**
	 * Whether a module is on (and the license active).
	 *
	 * @param string $id Module.
	 * @return bool
	 */
	public static function on( $id ) {
		return Helpdesk_Hero_Pro_License::is_active() && ! empty( self::states()[ $id ] );
	}

	/**
	 * Save module states.
	 *
	 * @param array $in id => bool.
	 * @return array<string, bool>
	 */
	public static function save( array $in ) {
		$before = self::states();
		$out    = array();
		foreach ( array_keys( self::all() ) as $id ) {
			$out[ $id ] = ! empty( $in[ $id ] );
		}
		update_option( self::OPTION, $out, false );
		// Settings that travel with the policy change with their modules.
		foreach ( array( 'fields', 'attachments', 'usage', 'time' ) as $id ) {
			if ( $before[ $id ] !== $out[ $id ] ) {
				Helpdesk_Hero_Hub_Policy::push_all();
				break;
			}
		}
		return self::states();
	}
}
