<?php
/**
 * Automations.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Rules that act on tickets: when something happens (or a time passes), if the ticket matches
 * the conditions, do the actions.
 *
 * Safeguards:
 * - An automation's own actions never trigger automations (no loops).
 * - An automation sends a customer at most one reply per ticket.
 * - Time-based automations act once per ticket for the same situation.
 * - Every run is written to the ticket's history.
 *
 * Manual automations don't run by themselves: they're buttons on the ticket that do several
 * things at once.
 */
final class Helpdesk_Hero_Pro_Automations {

	const OPTION = 'helpdesk_hero_pro_automations';
	const CRON   = 'helpdesk_hero_pro_automations';
	const RR     = 'helpdesk_hero_pro_round_robin';

	/**
	 * Running actions now: events they cause are ignored.
	 *
	 * @var bool
	 */
	private static $running = false;

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'helpdesk_hero_hub_ticket_created', array( __CLASS__, 'on_created' ), 30 );
		add_action( 'helpdesk_hero_hub_customer_replied', array( __CLASS__, 'on_customer_replied' ), 30 );
		add_action( 'helpdesk_hero_hub_reply_sent', array( __CLASS__, 'on_team_replied' ), 30 );
		add_action( 'helpdesk_hero_hub_status_changed', array( __CLASS__, 'on_status' ), 30, 2 );
		add_action( 'helpdesk_hero_hub_ticket_assigned', array( __CLASS__, 'on_assigned' ), 30, 2 );
		add_action( 'helpdesk_hero_hub_ticket_rated', array( __CLASS__, 'on_rated' ), 30, 2 );
		add_action( 'helpdesk_hero_hub_tags_changed', array( __CLASS__, 'on_tags' ), 30, 2 );
		add_action( 'helpdesk_hero_pro_sla_alert', array( __CLASS__, 'on_sla' ), 30, 2 );
		add_filter( 'helpdesk_hero_hub_describe_event', array( __CLASS__, 'describe' ), 10, 2 );
		add_action( self::CRON, array( __CLASS__, 'timed' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	/**
	 * Check time-based automations every 5 minutes.
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, 'helpdesk_hero_5min', self::CRON );
		}
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Definitions.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Triggers: id => [ label, takes a number of hours ].
	 *
	 * @return array
	 */
	public static function triggers() {
		return array(
			'ticket_created'   => array( __( 'A ticket arrives', 'helpdesk-hero-pro' ), false ),
			'customer_replied' => array( __( 'The customer replies', 'helpdesk-hero-pro' ), false ),
			'team_replied'     => array( __( 'Your team replies', 'helpdesk-hero-pro' ), false ),
			'status_changed'   => array( __( 'The status changes', 'helpdesk-hero-pro' ), false ),
			'tag_added'        => array( __( 'A tag is added', 'helpdesk-hero-pro' ), false ),
			'assigned'         => array( __( 'The ticket is assigned', 'helpdesk-hero-pro' ), false ),
			'rated'            => array( __( 'The customer rates the ticket', 'helpdesk-hero-pro' ), false ),
			'sla_warning'      => array( __( 'An SLA target is due within the hour', 'helpdesk-hero-pro' ), false ),
			'sla_breached'     => array( __( 'An SLA target is missed', 'helpdesk-hero-pro' ), false ),
			'no_team_reply'    => array( __( 'No reply from your team for … hours', 'helpdesk-hero-pro' ), true ),
			'waiting_customer' => array( __( 'Waiting on the customer for … hours', 'helpdesk-hero-pro' ), true ),
			'closed_for'       => array( __( 'Closed for … hours', 'helpdesk-hero-pro' ), true ),
			'manual'           => array( __( 'Someone clicks it on a ticket (manual)', 'helpdesk-hero-pro' ), false ),
		);
	}

	/**
	 * All automations.
	 *
	 * @return array[]
	 */
	public static function all() {
		$list = get_option( self::OPTION, array() );
		return is_array( $list ) ? array_values( $list ) : array();
	}

	/**
	 * Save the list (order is the order they run in).
	 *
	 * @param array $list Automations.
	 * @return array[]
	 */
	public static function save( array $list ) {
		$clean = array();
		foreach ( array_slice( $list, 0, 100 ) as $a ) {
			$name = trim( sanitize_text_field( (string) ( $a['name'] ?? '' ) ) );
			$trig = (string) ( $a['trigger'] ?? '' );
			if ( '' === $name || ! isset( self::triggers()[ $trig ] ) ) {
				continue;
			}
			$id = sanitize_key( (string) ( $a['id'] ?? '' ) );
			while ( '' === $id || isset( $clean[ $id ] ) ) {
				$id = 'auto-' . strtolower( wp_generate_password( 6, false ) );
			}
			$conditions = array();
			foreach ( array_slice( (array) ( $a['conditions'] ?? array() ), 0, 20 ) as $c ) {
				$field = sanitize_key( (string) ( $c['field'] ?? '' ) );
				if ( '' === $field ) {
					continue;
				}
				$conditions[] = array(
					'field' => $field,
					'op'    => in_array( $c['op'] ?? '', array( 'is', 'is_not', 'contains', 'lte', 'gte' ), true ) ? $c['op'] : 'is',
					'value' => substr( sanitize_text_field( (string) ( $c['value'] ?? '' ) ), 0, 200 ),
				);
			}
			$actions = array();
			foreach ( array_slice( (array) ( $a['actions'] ?? array() ), 0, 20 ) as $x ) {
				$type = sanitize_key( (string) ( $x['type'] ?? '' ) );
				if ( '' === $type ) {
					continue;
				}
				$actions[] = array(
					'type'  => $type,
					'value' => substr( sanitize_textarea_field( (string) ( $x['value'] ?? '' ) ), 0, 2000 ),
				);
			}
			if ( ! $actions ) {
				continue;
			}
			$clean[ $id ] = array(
				'id'         => $id,
				'name'       => substr( $name, 0, 80 ),
				'enabled'    => ! empty( $a['enabled'] ),
				'trigger'    => $trig,
				'hours'      => max( 1, min( 24 * 365, (int) ( $a['hours'] ?? 24 ) ) ),
				'match'      => 'any' === ( $a['match'] ?? '' ) ? 'any' : 'all',
				'conditions' => $conditions,
				'actions'    => $actions,
			);
		}
		update_option( self::OPTION, array_values( $clean ), false );
		return self::all();
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Events.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Run the automations for a trigger on a ticket.
	 *
	 * @param string $trigger Trigger.
	 * @param int    $id      Ticket.
	 * @param array  $event   Event data (status, rating, tag…).
	 */
	public static function fire( $trigger, $id, array $event = array() ) {
		if ( self::$running ) {
			return;
		}
		foreach ( self::all() as $a ) {
			if ( ! $a['enabled'] || $a['trigger'] !== $trigger ) {
				continue;
			}
			$ticket = Helpdesk_Hero_Hub::ticket( (int) $id );
			if ( ! $ticket || (int) $ticket['merged_into'] ) {
				return;
			}
			if ( self::matches( $a, $ticket, $event ) ) {
				self::run( $a, $ticket );
			}
		}
	}

	/**
	 * New ticket.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_created( $ticket ) {
		self::fire( 'ticket_created', (int) $ticket['id'] );
	}

	/**
	 * Customer reply.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_customer_replied( $ticket ) {
		self::fire( 'customer_replied', (int) $ticket['id'] );
	}

	/**
	 * Team reply.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_team_replied( $ticket ) {
		self::fire( 'team_replied', (int) $ticket['id'] );
	}

	/**
	 * Status change.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $status New status.
	 */
	public static function on_status( $ticket, $status ) {
		self::fire( 'status_changed', (int) $ticket['id'], array( 'status' => $status ) );
	}

	/**
	 * Assignment.
	 *
	 * @param array $ticket  Ticket.
	 * @param int   $user_id Assignee.
	 */
	public static function on_assigned( $ticket, $user_id ) {
		self::fire( 'assigned', (int) $ticket['id'], array( 'assignee' => (int) $user_id ) );
	}

	/**
	 * Rating.
	 *
	 * @param array $ticket Ticket.
	 * @param int   $rating Stars.
	 */
	public static function on_rated( $ticket, $rating ) {
		self::fire( 'rated', (int) $ticket['id'], array( 'rating' => (int) $rating ) );
	}

	/**
	 * Tags changed: fire for each added tag.
	 *
	 * @param array    $ticket Ticket before.
	 * @param string[] $tags   New tags.
	 */
	public static function on_tags( $ticket, $tags ) {
		foreach ( array_diff( (array) $tags, (array) $ticket['tags'] ) as $tag ) {
			self::fire( 'tag_added', (int) $ticket['id'], array( 'tag' => (string) $tag ) );
		}
	}

	/**
	 * SLA alert.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $kind   warning | breached.
	 */
	public static function on_sla( $ticket, $kind ) {
		self::fire( 'breached' === $kind ? 'sla_breached' : 'sla_warning', (int) $ticket['id'] );
	}

	/**
	 * Time-based automations: each ticket once per situation.
	 */
	public static function timed() {
		global $wpdb;
		$table = Helpdesk_Hero_Hub_DB::table( 'tickets' );
		foreach ( self::all() as $a ) {
			if ( ! $a['enabled'] || ! in_array( $a['trigger'], array( 'no_team_reply', 'waiting_customer', 'closed_for' ), true ) ) {
				continue;
			}
			$before = Helpdesk_Hero_Hub_DB::now( -$a['hours'] * HOUR_IN_SECONDS );
			switch ( $a['trigger'] ) {
				case 'no_team_reply':
					$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, customer_at AS stamp FROM %i WHERE status = 'open' AND merged_into = 0 AND customer_at IS NOT NULL AND customer_at < %s LIMIT 200", $table, $before ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					break;
				case 'waiting_customer':
					$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, updated_at AS stamp FROM %i WHERE status = 'pending' AND merged_into = 0 AND updated_at < %s LIMIT 200", $table, $before ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					break;
				default:
					$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, closed_at AS stamp FROM %i WHERE status = 'closed' AND merged_into = 0 AND closed_at IS NOT NULL AND closed_at < %s AND closed_at > %s LIMIT 200", $table, $before, Helpdesk_Hero_Hub_DB::now( -( $a['hours'] + 72 ) * HOUR_IN_SECONDS ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			}
			foreach ( $rows as $row ) {
				$key = $a['id'] . '|' . $row['stamp'];
				if ( self::ran( (int) $row['id'], 'key', $key ) ) {
					continue;
				}
				$ticket = Helpdesk_Hero_Hub::ticket( (int) $row['id'] );
				if ( $ticket && self::matches( $a, $ticket, array() ) ) {
					self::run( $a, $ticket, $key );
				}
			}
		}
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Conditions.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Fields conditions can test.
	 *
	 * @return array<string, string>
	 */
	public static function fields() {
		$out = array(
			'site'           => __( 'Site', 'helpdesk-hero-pro' ),
			'tier'           => __( 'Customer tier', 'helpdesk-hero-pro' ),
			'priority'       => __( 'Priority', 'helpdesk-hero-pro' ),
			'category'       => __( 'Category', 'helpdesk-hero-pro' ),
			'service'        => __( 'Service', 'helpdesk-hero-pro' ),
			'tag'            => __( 'Tag', 'helpdesk-hero-pro' ),
			'status'         => __( 'Status', 'helpdesk-hero-pro' ),
			'assignee'       => __( 'Assigned to', 'helpdesk-hero-pro' ),
			'rating'         => __( 'Rating (stars)', 'helpdesk-hero-pro' ),
			'subject'        => __( 'Subject', 'helpdesk-hero-pro' ),
			'customer_email' => __( 'Customer email', 'helpdesk-hero-pro' ),
			'business_hours' => __( 'During business hours', 'helpdesk-hero-pro' ),
			'event_status'   => __( 'New status (status trigger)', 'helpdesk-hero-pro' ),
			'event_tag'      => __( 'Tag added (tag trigger)', 'helpdesk-hero-pro' ),
		);
		foreach ( Helpdesk_Hero_Hub::field_definitions() as $f ) {
			$out[ 'field_' . $f['id'] ] = sprintf( /* translators: %s: field label */ __( 'Field: %s', 'helpdesk-hero-pro' ), $f['label'] );
		}
		return $out;
	}

	/**
	 * A ticket's value for a field (a list for tags).
	 *
	 * @param string $field  Field.
	 * @param array  $ticket Ticket.
	 * @param array  $event  Event.
	 * @return mixed
	 */
	private static function value( $field, array $ticket, array $event ) {
		switch ( $field ) {
			case 'site':
				return (string) $ticket['site_id'];
			case 'tier':
				$site = Helpdesk_Hero_Hub::site( (int) $ticket['site_id'] );
				return $site ? (string) $site['tier'] : '';
			case 'tag':
				return array_map( 'strval', (array) $ticket['tags'] );
			case 'status':
				return '' !== (string) $ticket['custom_status'] ? array( $ticket['status'], 'custom:' . $ticket['custom_status'] ) : array( $ticket['status'] );
			case 'assignee':
				return (string) (int) $ticket['assignee_id'];
			case 'rating':
				return (int) ( $event['rating'] ?? $ticket['rating'] );
			case 'business_hours':
				return class_exists( 'Helpdesk_Hero_Pro_SLA' ) && Helpdesk_Hero_Pro_SLA::in_hours( time() ) ? 'yes' : 'no';
			case 'event_status':
				return (string) ( $event['status'] ?? '' );
			case 'event_tag':
				return (string) ( $event['tag'] ?? '' );
		}
		if ( 0 === strpos( $field, 'field_' ) ) {
			$values = $ticket['fields'] ? (array) json_decode( (string) $ticket['fields'], true ) : array();
			$v      = $values[ substr( $field, 6 ) ] ?? '';
			return is_bool( $v ) ? ( $v ? 'yes' : 'no' ) : (string) $v;
		}
		return (string) ( $ticket[ $field ] ?? '' );
	}

	/**
	 * Whether a ticket meets an automation's conditions.
	 *
	 * @param array $a      Automation.
	 * @param array $ticket Ticket.
	 * @param array $event  Event.
	 * @return bool
	 */
	public static function matches( array $a, array $ticket, array $event ) {
		if ( ! $a['conditions'] ) {
			return true;
		}
		$results = array();
		foreach ( $a['conditions'] as $c ) {
			$v      = self::value( $c['field'], $ticket, $event );
			$target = (string) $c['value'];
			switch ( $c['op'] ) {
				case 'is_not':
					$ok = is_array( $v ) ? ! in_array( $target, $v, true ) : (string) $v !== $target;
					break;
				case 'contains':
					$ok = false !== stripos( is_array( $v ) ? implode( ' ', $v ) : (string) $v, $target );
					break;
				case 'lte':
					$ok = is_numeric( $v ) && (float) $v <= (float) $target && (float) $v > 0;
					break;
				case 'gte':
					$ok = is_numeric( $v ) && (float) $v >= (float) $target;
					break;
				default:
					$ok = is_array( $v ) ? in_array( $target, $v, true ) : (string) $v === $target;
			}
			$results[] = $ok;
		}
		return 'any' === $a['match'] ? in_array( true, $results, true ) : ! in_array( false, $results, true );
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Actions.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Actions: id => label.
	 *
	 * @return array<string, string>
	 */
	public static function actions() {
		return array(
			'assign'       => __( 'Assign to', 'helpdesk-hero-pro' ),
			'set_status'   => __( 'Set status', 'helpdesk-hero-pro' ),
			'add_tag'      => __( 'Add tag', 'helpdesk-hero-pro' ),
			'remove_tag'   => __( 'Remove tag', 'helpdesk-hero-pro' ),
			'set_priority' => __( 'Set priority', 'helpdesk-hero-pro' ),
			'set_service'  => __( 'Set service', 'helpdesk-hero-pro' ),
			'send_reply'   => __( 'Send a saved reply to the customer', 'helpdesk-hero-pro' ),
			'add_note'     => __( 'Add an internal note', 'helpdesk-hero-pro' ),
			'email'        => __( 'Email', 'helpdesk-hero-pro' ),
			'slack'        => __( 'Post to Slack', 'helpdesk-hero-pro' ),
		);
	}

	/**
	 * Whether an automation already did something on a ticket.
	 *
	 * @param int    $ticket_id Ticket.
	 * @param string $what      key | reply.
	 * @param string $value     Key or automation ID.
	 * @return bool
	 */
	private static function ran( $ticket_id, $what, $value ) {
		foreach ( Helpdesk_Hero_Hub::history( (int) $ticket_id ) as $h ) {
			if ( 'automation' !== $h['type'] ) {
				continue;
			}
			if ( 'key' === $what && ( $h['payload']['key'] ?? '' ) === $value ) {
				return true;
			}
			if ( 'reply' === $what && ( $h['payload']['id'] ?? '' ) === $value && ! empty( $h['payload']['replied'] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Run an automation's actions on a ticket.
	 *
	 * @param array  $a      Automation.
	 * @param array  $ticket Ticket.
	 * @param string $key    Time-based situation key.
	 * @return string[] What was done.
	 */
	public static function run( array $a, array $ticket, $key = '' ) {
		$was     = self::$running;
		$done    = array();
		$replied = false;
		self::$running = true;
		try {
			foreach ( $a['actions'] as $x ) {
				$ticket = Helpdesk_Hero_Hub::ticket( (int) $ticket['id'] );
				if ( ! $ticket ) {
					break;
				}
				$text = self::act( $a, $ticket, $x, $replied );
				if ( '' !== $text ) {
					$done[] = $text;
				}
			}
		} finally {
			self::$running = $was;
		}
		if ( $done ) {
			Helpdesk_Hero_Hub::log(
				$ticket,
				'automation',
				array(
					'id'      => $a['id'],
					'name'    => $a['name'],
					'done'    => $done,
					'key'     => $key,
					'replied' => $replied,
				)
			);
		}
		return $done;
	}

	/**
	 * Do one action.
	 *
	 * @param array $a       Automation.
	 * @param array $ticket  Ticket.
	 * @param array $x       Action.
	 * @param bool  $replied Set when a reply was sent.
	 * @return string What was done ('' if nothing).
	 */
	private static function act( array $a, array $ticket, array $x, &$replied ) {
		$v = (string) $x['value'];
		switch ( $x['type'] ) {
			case 'assign':
				$user = 'round_robin' === $v ? self::next_supporter( $a['id'] ) : (int) $v;
				if ( 'none' === $v ) {
					$user = 0;
				}
				$r = Helpdesk_Hero_Hub::assign( $ticket, $user );
				$u = $user ? get_userdata( $user ) : false;
				/* translators: %s: person */
				return is_wp_error( $r ) ? '' : ( $u ? sprintf( __( 'assigned to %s', 'helpdesk-hero-pro' ), $u->display_name ) : __( 'unassigned', 'helpdesk-hero-pro' ) );
			case 'set_status':
				if ( 0 === strpos( $v, 'custom:' ) ) {
					$r = Helpdesk_Hero_Hub::set_custom_status( $ticket, substr( $v, 7 ) );
					/* translators: %s: status */
					return is_wp_error( $r ) ? '' : sprintf( __( 'status set to %s', 'helpdesk-hero-pro' ), substr( $v, 7 ) );
				}
				Helpdesk_Hero_Hub::set_status( $ticket, $v );
				/* translators: %s: status */
				return sprintf( __( 'status set to %s', 'helpdesk-hero-pro' ), $v );
			case 'add_tag':
			case 'remove_tag':
				$tags = array_values( array_diff( (array) $ticket['tags'], array( $v ) ) );
				if ( 'add_tag' === $x['type'] ) {
					$tags[] = $v;
				}
				Helpdesk_Hero_Hub::set_tags( $ticket, $tags );
				/* translators: %s: tag */
				return sprintf( 'add_tag' === $x['type'] ? __( 'tag %s added', 'helpdesk-hero-pro' ) : __( 'tag %s removed', 'helpdesk-hero-pro' ), $v );
			case 'set_priority':
				if ( ! in_array( $v, array( 'low', 'normal', 'high', 'urgent' ), true ) ) {
					return '';
				}
				Helpdesk_Hero_Hub::update_ticket( (int) $ticket['id'], array( 'priority' => $v ) );
				/* translators: %s: priority */
				return sprintf( __( 'priority set to %s', 'helpdesk-hero-pro' ), $v );
			case 'set_service':
				if ( ! class_exists( 'Helpdesk_Hero_Pro_Billing' ) || ! Helpdesk_Hero_Pro_Modules::on( 'time' ) ) {
					return '';
				}
				$r = Helpdesk_Hero_Pro_Billing::set_service( $ticket, $v );
				/* translators: %s: service */
				return is_wp_error( $r ) ? '' : sprintf( __( 'service set to %s', 'helpdesk-hero-pro' ), $v );
			case 'send_reply':
				// One automatic reply per ticket per automation, so a rule can't flood a customer.
				if ( self::ran( (int) $ticket['id'], 'reply', $a['id'] ) ) {
					return '';
				}
				$macro = null;
				foreach ( Helpdesk_Hero_Pro_Macros::all() as $m ) {
					if ( $m['id'] === $v ) {
						$macro = $m;
					}
				}
				if ( ! $macro ) {
					return '';
				}
				$r = Helpdesk_Hero_Hub::agent_reply( $ticket, self::fill( $macro['body'], $ticket ) );
				if ( is_wp_error( $r ) ) {
					return '';
				}
				$replied = true;
				/* translators: %s: saved reply */
				return sprintf( __( 'sent the reply “%s”', 'helpdesk-hero-pro' ), $macro['name'] );
			case 'add_note':
				if ( '' === trim( $v ) ) {
					return '';
				}
				Helpdesk_Hero_Hub::add_note( $ticket, self::fill( $v, $ticket ) );
				return __( 'added a note', 'helpdesk-hero-pro' );
			case 'email':
				$to = 'assignee' === $v
					? ( (int) $ticket['assignee_id'] && get_userdata( (int) $ticket['assignee_id'] ) ? get_userdata( (int) $ticket['assignee_id'] )->user_email : '' )
					: ( 'team' === $v ? Helpdesk_Hero_Hub_Settings::notify_email() : sanitize_email( $v ) );
				if ( ! is_email( $to ) ) {
					return '';
				}
				wp_mail(
					$to,
					/* translators: 1: automation, 2: ticket subject */
					sprintf( __( '[%1$s] %2$s', 'helpdesk-hero-pro' ), $a['name'], $ticket['subject'] ),
					/* translators: 1: automation, 2: link */
					sprintf( __( "The automation “%1\$s” ran on this ticket.\n\n%2\$s", 'helpdesk-hero-pro' ), $a['name'], Helpdesk_Hero_Hub::ticket_url( (int) $ticket['id'] ) )
				);
				/* translators: %s: email address */
				return sprintf( __( 'emailed %s', 'helpdesk-hero-pro' ), $to );
			case 'slack':
				$url = Helpdesk_Hero_Pro_Notify::settings()['slack_url'];
				if ( '' === $url ) {
					return '';
				}
				wp_remote_post(
					$url,
					array(
						'timeout'  => 3,
						'blocking' => false,
						'headers'  => array( 'Content-Type' => 'application/json' ),
						'body'     => wp_json_encode( array( 'text' => str_replace( array( '&', '<', '>' ), array( '&amp;', '&lt;', '&gt;' ), self::fill( '' !== trim( $v ) ? $v : $a['name'], $ticket ) ) . "\n<" . Helpdesk_Hero_Hub::ticket_url( (int) $ticket['id'] ) . '|#' . (int) $ticket['id'] . '>' ) ),
					)
				);
				return __( 'posted to Slack', 'helpdesk-hero-pro' );
		}
		return '';
	}

	/**
	 * Fill variables in a text, as saved replies do.
	 *
	 * @param string $text   Text.
	 * @param array  $ticket Ticket.
	 * @return string
	 */
	private static function fill( $text, array $ticket ) {
		$site  = Helpdesk_Hero_Hub::site( (int) $ticket['site_id'] );
		$name  = (string) $ticket['customer_name'];
		$parts = preg_split( '/\s+/', trim( $name ) );
		$vars  = array(
			'customer_name'       => $name,
			'customer_first_name' => $parts ? $parts[0] : $name,
			'site_name'           => $site ? ( $site['name'] ? $site['name'] : $site['label'] ) : '',
			'site_url'            => $site ? $site['url'] : '',
			'ticket_id'           => (string) $ticket['id'],
			'ticket_subject'      => (string) $ticket['subject'],
			'agent_name'          => Helpdesk_Hero_Hub_Settings::team_name(),
			'team_name'           => Helpdesk_Hero_Hub_Settings::team_name(),
		);
		return preg_replace_callback(
			'/\{([a-z_]+)\}/',
			static function ( $m ) use ( $vars ) {
				return $vars[ $m[1] ] ?? $m[0];
			},
			(string) $text
		);
	}

	/**
	 * The next supporter in turn for a round-robin automation.
	 *
	 * @param string $id Automation.
	 * @return int User (0 if nobody).
	 */
	private static function next_supporter( $id ) {
		$team = array_values(
			array_filter(
				Helpdesk_Hero_Hub::team(),
				static function ( $u ) {
					return ! empty( $u['supporter'] );
				}
			)
		);
		if ( ! $team ) {
			return 0;
		}
		$turns       = (array) get_option( self::RR, array() );
		$i           = ( (int) ( $turns[ $id ] ?? -1 ) + 1 ) % count( $team );
		$turns[ $id ] = $i;
		update_option( self::RR, $turns, false );
		return (int) $team[ $i ]['id'];
	}

	/**
	 * Run a manual automation on a ticket.
	 *
	 * @param string $id        Automation.
	 * @param int    $ticket_id Ticket.
	 * @return array|WP_Error { done }
	 */
	public static function run_manual( $id, $ticket_id ) {
		$ticket = Helpdesk_Hero_Hub::ticket( (int) $ticket_id );
		foreach ( self::all() as $a ) {
			if ( $a['id'] === $id && 'manual' === $a['trigger'] && $a['enabled'] && $ticket ) {
				return array( 'done' => self::run( $a, $ticket ) );
			}
		}
		return new WP_Error( 'helpdesk_hero_pro_automation', __( 'Automation not found.', 'helpdesk-hero-pro' ), array( 'status' => 404 ) );
	}

	/**
	 * History line for an automation run.
	 *
	 * @param string $text  Text.
	 * @param array  $event History item.
	 * @return string
	 */
	public static function describe( $text, $event ) {
		if ( 'automation' !== ( $event['type'] ?? '' ) ) {
			return $text;
		}
		$p = (array) $event['payload'];
		/* translators: 1: automation, 2: what it did */
		return sprintf( __( 'Automation “%1$s”: %2$s', 'helpdesk-hero-pro' ), $p['name'] ?? '', implode( ', ', (array) ( $p['done'] ?? array() ) ) );
	}
}
