<?php
/**
 * REST API for the Pro pages and panels.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * License and settings (administrators), triage, drafts and broadcasts (hub agents).
 */
final class Helpdesk_Hero_Pro_REST {

	const NS = 'helpdesk-hero-pro/v1';

	/**
	 * Register routes.
	 */
	public static function register() {
		$admin    = static function () {
			return current_user_can( 'manage_options' );
		};
		$licensed = static function () {
			return current_user_can( 'helpdesk_hero_hub' ) && Helpdesk_Hero_Pro_License::is_active();
		};
		$licensed_admin = static function () {
			return current_user_can( 'manage_options' ) && Helpdesk_Hero_Pro_License::is_active();
		};
		$routes = array(
			array( '/settings', 'GET', 'settings', $admin ),
			array( '/settings', 'POST', 'save_settings', $admin ),
			array( '/license', 'POST', 'license', $admin ),
			array( '/triage/(?P<id>\d+)', 'GET', 'triage', $licensed ),
			array( '/triage/(?P<id>\d+)', 'POST', 'regenerate', $licensed ),
			array( '/draft/(?P<id>\d+)', 'POST', 'draft', $licensed ),
			array( '/broadcast', 'POST', 'broadcast', $licensed ),
			array( '/analytics', 'GET', 'analytics', $licensed ),
			array( '/helpdesk', 'GET', 'helpdesk', $licensed_admin ),
			array( '/helpdesk', 'POST', 'save_helpdesk', $licensed_admin ),
			array( '/helpdesk/test', 'POST', 'test_helpdesk', $licensed_admin ),
			array( '/supporters', 'GET', 'supporters', $licensed_admin ),
			array( '/supporters', 'POST', 'save_supporters', $licensed_admin ),
		);
		foreach ( $routes as $r ) {
			register_rest_route(
				self::NS,
				$r[0],
				array(
					'methods'             => $r[1],
					'callback'            => array( __CLASS__, $r[2] ),
					'permission_callback' => $r[3],
				)
			);
		}
	}

	/**
	 * License state and settings.
	 *
	 * @return array
	 */
	public static function settings() {
		return array(
			'license'  => Helpdesk_Hero_Pro_License::public_state(),
			'settings' => Helpdesk_Hero_Pro_Plugin::settings(),
			'ai'       => Helpdesk_Hero_Hub_AI::available(),
			'buy_url'  => (string) HELPDESK_HERO_PRO_BUY_URL,
		);
	}

	/**
	 * Save settings; branding goes to every connected site.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_settings( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Plugin::save_settings( (array) $request->get_json_params() );
		$sent = Helpdesk_Hero_Pro_License::is_active() ? Helpdesk_Hero_Pro_Team::broadcast_branding() : 0;
		return array_merge( self::settings(), array( 'sent' => $sent ) );
	}

	/**
	 * Activate, check or deactivate the license.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function license( WP_REST_Request $request ) {
		$op = sanitize_key( (string) $request->get_param( 'op' ) );
		if ( 'activate' === $op ) {
			$result = Helpdesk_Hero_Pro_License::activate( (string) $request->get_param( 'key' ) );
			if ( is_wp_error( $result ) ) {
				$result->add_data( array( 'status' => 400 ) );
				return $result;
			}
			Helpdesk_Hero_Pro_Team::add_role();
			// Ratings and branding now apply: send every site its policy again.
			Helpdesk_Hero_Pro_Analytics::init();
			Helpdesk_Hero_Pro_Team::init();
			Helpdesk_Hero_Pro_Team::broadcast_branding();
		} elseif ( 'check' === $op ) {
			Helpdesk_Hero_Pro_License::check();
		} elseif ( 'deactivate' === $op ) {
			Helpdesk_Hero_Pro_License::deactivate();
			remove_all_filters( 'helpdesk_hero_hub_ratings_available' );
			remove_all_filters( 'helpdesk_hero_hub_branding' );
			Helpdesk_Hero_Pro_Team::broadcast_branding();
		}
		return self::settings();
	}

	/**
	 * Ticket or 404.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	private static function ticket( WP_REST_Request $request ) {
		$ticket = Helpdesk_Hero_Hub::ticket( (int) $request['id'] );
		return $ticket ? $ticket : new WP_Error( 'helpdesk_hero_pro_ticket', __( 'Ticket not found.', 'helpdesk-hero-pro' ), array( 'status' => 404 ) );
	}

	/**
	 * Triage brief for a ticket.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function triage( WP_REST_Request $request ) {
		$ticket = self::ticket( $request );
		if ( is_wp_error( $ticket ) ) {
			return $ticket;
		}
		return array(
			'brief'   => Helpdesk_Hero_Pro_Triage::brief( $ticket ),
			'queued'  => (bool) wp_next_scheduled( Helpdesk_Hero_Pro_Triage::CRON, array( (int) $ticket['id'] ) ),
			'ai'      => Helpdesk_Hero_Hub_AI::available(),
		);
	}

	/**
	 * Write the brief again.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function regenerate( WP_REST_Request $request ) {
		$ticket = self::ticket( $request );
		if ( is_wp_error( $ticket ) ) {
			return $ticket;
		}
		$brief = Helpdesk_Hero_Pro_Triage::generate( $ticket );
		if ( is_wp_error( $brief ) ) {
			$brief->add_data( array( 'status' => 400 ) );
			return $brief;
		}
		return self::triage( $request );
	}

	/**
	 * Draft a reply.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function draft( WP_REST_Request $request ) {
		$ticket = self::ticket( $request );
		if ( is_wp_error( $ticket ) ) {
			return $ticket;
		}
		$draft = Helpdesk_Hero_Pro_Triage::draft( $ticket, sanitize_text_field( (string) $request->get_param( 'hint' ) ) );
		if ( is_wp_error( $draft ) ) {
			$draft->add_data( array( 'status' => 400 ) );
			return $draft;
		}
		return array( 'draft' => $draft );
	}

	/**
	 * Message every connected site.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function broadcast( WP_REST_Request $request ) {
		$title = sanitize_text_field( (string) $request->get_param( 'title' ) );
		if ( '' === $title ) {
			return new WP_Error( 'helpdesk_hero_pro_title', __( 'Give the message a title.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
		}
		$sent = Helpdesk_Hero_Pro_Team::broadcast(
			array(
				'title'  => $title,
				'body'   => sanitize_textarea_field( (string) $request->get_param( 'body' ) ),
				'level'  => in_array( $request->get_param( 'level' ), array( 'info', 'success', 'warning', 'error' ), true ) ? $request->get_param( 'level' ) : 'info',
				'action' => array(
					'label' => sanitize_text_field( (string) $request->get_param( 'action_label' ) ),
					'url'   => sanitize_text_field( (string) $request->get_param( 'action_url' ) ),
				),
			)
		);
		return array( 'sent' => $sent );
	}

	/**
	 * Analytics report.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function analytics( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Analytics::report( (int) ( $request->get_param( 'days' ) ? $request->get_param( 'days' ) : 30 ), (int) $request->get_param( 'site' ) );
	}

	/**
	 * Help desk settings.
	 *
	 * @return array
	 */
	public static function helpdesk() {
		return Helpdesk_Hero_Pro_Helpdesks::state();
	}

	/**
	 * Save help desk settings.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_helpdesk( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Helpdesks::save( (array) $request->get_json_params() );
	}

	/**
	 * Test the help desk connection.
	 *
	 * @return array
	 */
	public static function test_helpdesk() {
		return Helpdesk_Hero_Pro_Helpdesks::test();
	}

	/**
	 * Supporters and the hub users who can be chosen.
	 *
	 * @return array
	 */
	public static function supporters() {
		return array(
			'supporters' => array_values( Helpdesk_Hero_Pro_Team::supporters() ),
			'users'      => Helpdesk_Hero_Pro_Team::candidates(),
		);
	}

	/**
	 * Save supporters.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_supporters( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Team::save_supporters( (array) $request->get_param( 'supporters' ) );
		return self::supporters();
	}
}
