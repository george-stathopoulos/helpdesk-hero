<?php
/**
 * REST API for the Pro pages and panels.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * License and settings (administrators), triage, drafts and broadcasts (hub agents).
 */
final class Helpdesk_Hero_Pro_REST {

	const NS = 'helpdesk-hero-pro/v1';

	/**
	 * Register routes.
	 */
	public static function register() {
		$admin    = static function () {
			return current_user_can( 'manage_options' );
		};
		$licensed = static function () {
			return current_user_can( 'helpdesk_hero_hub' ) && Helpdesk_Hero_Pro_License::is_active();
		};
		$licensed_admin = static function () {
			return current_user_can( 'manage_options' ) && Helpdesk_Hero_Pro_License::is_active();
		};
		// A module's endpoints work only while the module is on.
		$module = static function ( $id, $admin_only = false ) {
			return static function () use ( $id, $admin_only ) {
				return current_user_can( $admin_only ? 'manage_options' : 'helpdesk_hero_hub' ) && Helpdesk_Hero_Pro_Modules::on( $id );
			};
		};
		// Changes customers see: supporters only, as in the hub.
		$licensed_support = static function () {
			return current_user_can( 'helpdesk_hero_hub' ) && Helpdesk_Hero_Pro_Modules::on( 'merge' ) && Helpdesk_Hero_Hub::can_support();
		};
		$routes = array(
			array( '/settings', 'GET', 'settings', $admin ),
			array( '/settings', 'POST', 'save_settings', $admin ),
			array( '/license', 'POST', 'license', $admin ),
			array( '/triage/(?P<id>\d+)', 'GET', 'triage', $module( 'triage' ) ),
			array( '/triage/(?P<id>\d+)', 'POST', 'regenerate', $module( 'triage' ) ),
			array( '/draft/(?P<id>\d+)', 'POST', 'draft', $module( 'triage' ) ),
			array( '/broadcast', 'POST', 'broadcast', $module( 'broadcast' ) ),
			array( '/analytics', 'GET', 'analytics', $module( 'analytics' ) ),
			array( '/analytics/explore', 'GET', 'explore', $module( 'analytics' ) ),
			array( '/analytics/team', 'GET', 'team_kpis', $module( 'analytics' ) ),
			array( '/analytics/reports', 'GET', 'reports', $module( 'analytics' ) ),
			array( '/analytics/reports', 'POST', 'save_report', $module( 'analytics' ) ),
			array( '/analytics/reports/(?P<scope>shared|personal)/(?P<id>[a-z0-9_-]+)', 'DELETE', 'delete_report', $module( 'analytics' ) ),
			array( '/helpdesk', 'GET', 'helpdesk', $licensed_admin ),
			array( '/helpdesk', 'POST', 'save_helpdesk', $licensed_admin ),
			array( '/helpdesk/test', 'POST', 'test_helpdesk', $licensed_admin ),
			array( '/supporters', 'GET', 'supporters', $licensed_admin ),
			array( '/supporters', 'POST', 'save_supporters', $licensed_admin ),
			array( '/automations', 'GET', 'automations', $module( 'automations', true ) ),
			array( '/automations', 'POST', 'save_automations', $module( 'automations', true ) ),
			array( '/automations/manual', 'GET', 'manual_automations', $module( 'automations' ) ),
			array( '/automations/(?P<id>[a-z0-9_-]+)/run/(?P<ticket>\d+)', 'POST', 'run_automation', $module( 'automations' ) ),
			array( '/views', 'GET', 'views', $module( 'views' ) ),
			array( '/views', 'POST', 'save_view', $module( 'views' ) ),
			array( '/views/(?P<scope>shared|personal)/(?P<id>[a-z0-9_-]+)', 'DELETE', 'delete_view', $module( 'views' ) ),
			array( '/examples', 'GET', 'examples', $licensed_admin ),
			array( '/examples', 'POST', 'add_examples', $licensed_admin ),
			array( '/examples', 'DELETE', 'remove_examples', $licensed_admin ),
			array( '/modules', 'GET', 'modules', $admin ),
			array( '/modules', 'POST', 'save_modules', $licensed_admin ),
			array( '/macros', 'GET', 'macros', $module( 'replies' ) ),
			array( '/macros', 'POST', 'save_macros', $module( 'replies', true ) ),
			array( '/notify', 'GET', 'notify', $module( 'notify', true ) ),
			array( '/notify', 'POST', 'save_notify', $module( 'notify', true ) ),
			array( '/notify/test', 'POST', 'test_notify', $module( 'notify', true ) ),
			array( '/time/ticket/(?P<id>\d+)', 'GET', 'time_ticket', $module( 'time' ) ),
			array( '/time/ticket/(?P<id>\d+)', 'POST', 'time_add', $module( 'time' ) ),
			array( '/time/(?P<id>\d+)', 'DELETE', 'time_delete', $module( 'time' ) ),
			array( '/time/report', 'GET', 'time_report', $module( 'time' ) ),
			array( '/time/entries', 'GET', 'time_entries', $module( 'time' ) ),
			array( '/time/bulk', 'POST', 'time_bulk', $module( 'time', true ) ),
			array( '/time/(?P<id>\d+)', 'POST', 'time_update', $module( 'time' ) ),
			array( '/time/ticket/(?P<id>\d+)/sessions', 'GET', 'time_sessions', $module( 'time' ) ),
			array( '/ticket/(?P<id>\d+)/service', 'POST', 'ticket_service', $module( 'time' ) ),
			array( '/billing', 'GET', 'billing', $module( 'time' ) ),
			array( '/billing', 'POST', 'save_billing', $module( 'time', true ) ),
			array( '/billing/site/(?P<id>\d+)', 'GET', 'site_billing', $module( 'time' ) ),
			array( '/billing/site/(?P<id>\d+)', 'POST', 'save_site_billing', $module( 'time', true ) ),
			array( '/sla', 'GET', 'sla', $module( 'sla', true ) ),
			array( '/sla', 'POST', 'save_sla', $module( 'sla', true ) ),
			array( '/sla/site/(?P<id>\d+)', 'POST', 'save_site_sla', $module( 'sla', true ) ),
			array( '/statuses', 'GET', 'statuses', $module( 'statuses' ) ),
			array( '/statuses', 'POST', 'save_statuses', $module( 'statuses', true ) ),
			array( '/fields', 'GET', 'fields', $module( 'fields' ) ),
			array( '/fields', 'POST', 'save_fields', $module( 'fields', true ) ),
			array( '/attachments', 'GET', 'attachments', $module( 'attachments', true ) ),
			array( '/attachments', 'POST', 'save_attachments', $module( 'attachments', true ) ),
			array( '/merge/(?P<id>\d+)', 'POST', 'merge', $licensed_support ),
			array( '/merge/(?P<id>\d+)/candidates', 'GET', 'merge_candidates', $module( 'merge' ) ),
		);
		foreach ( $routes as $r ) {
			register_rest_route(
				self::NS,
				$r[0],
				array(
					'methods'             => $r[1],
					'callback'            => array( __CLASS__, $r[2] ),
					'permission_callback' => $r[3],
				)
			);
		}
	}

	/**
	 * License state and settings.
	 *
	 * @return array
	 */
	public static function settings() {
		return array(
			'license'  => Helpdesk_Hero_Pro_License::public_state(),
			'settings' => Helpdesk_Hero_Pro_Plugin::settings(),
			'ai'       => Helpdesk_Hero_Hub_AI::available(),
			'buy_url'  => (string) HELPDESK_HERO_PRO_BUY_URL,
		);
	}

	/**
	 * Save settings; branding goes to every connected site.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_settings( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Plugin::save_settings( (array) $request->get_json_params() );
		$sent = Helpdesk_Hero_Pro_License::is_active() ? Helpdesk_Hero_Pro_Team::broadcast_branding() : 0;
		return array_merge( self::settings(), array( 'sent' => $sent ) );
	}

	/**
	 * Activate, check or deactivate the license.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function license( WP_REST_Request $request ) {
		$op = sanitize_key( (string) $request->get_param( 'op' ) );
		if ( 'activate' === $op ) {
			$result = Helpdesk_Hero_Pro_License::activate( (string) $request->get_param( 'key' ) );
			if ( is_wp_error( $result ) ) {
				$result->add_data( array( 'status' => 400 ) );
				return $result;
			}
			Helpdesk_Hero_Pro_Team::add_role();
			// Ratings and branding now apply: send every site its policy again.
			Helpdesk_Hero_Pro_Analytics::init();
			Helpdesk_Hero_Pro_Team::init();
			Helpdesk_Hero_Pro_Team::broadcast_branding();
		} elseif ( 'check' === $op ) {
			Helpdesk_Hero_Pro_License::check();
		} elseif ( 'deactivate' === $op ) {
			Helpdesk_Hero_Pro_License::deactivate();
			remove_all_filters( 'helpdesk_hero_hub_ratings_available' );
			remove_all_filters( 'helpdesk_hero_hub_branding' );
			Helpdesk_Hero_Pro_Team::broadcast_branding();
		}
		return self::settings();
	}

	/**
	 * Ticket or 404.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	private static function ticket( WP_REST_Request $request ) {
		$ticket = Helpdesk_Hero_Hub::ticket( (int) $request['id'] );
		return $ticket ? $ticket : new WP_Error( 'helpdesk_hero_pro_ticket', __( 'Ticket not found.', 'helpdesk-hero-pro' ), array( 'status' => 404 ) );
	}

	/**
	 * Triage brief for a ticket.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function triage( WP_REST_Request $request ) {
		$ticket = self::ticket( $request );
		if ( is_wp_error( $ticket ) ) {
			return $ticket;
		}
		return array(
			'brief'   => Helpdesk_Hero_Pro_Triage::brief( $ticket ),
			'queued'  => (bool) wp_next_scheduled( Helpdesk_Hero_Pro_Triage::CRON, array( (int) $ticket['id'] ) ),
			'ai'      => Helpdesk_Hero_Hub_AI::available(),
		);
	}

	/**
	 * Write the brief again.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function regenerate( WP_REST_Request $request ) {
		$ticket = self::ticket( $request );
		if ( is_wp_error( $ticket ) ) {
			return $ticket;
		}
		$brief = Helpdesk_Hero_Pro_Triage::generate( $ticket );
		if ( is_wp_error( $brief ) ) {
			$brief->add_data( array( 'status' => 400 ) );
			return $brief;
		}
		return self::triage( $request );
	}

	/**
	 * Draft a reply.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function draft( WP_REST_Request $request ) {
		$ticket = self::ticket( $request );
		if ( is_wp_error( $ticket ) ) {
			return $ticket;
		}
		$draft = Helpdesk_Hero_Pro_Triage::draft( $ticket, sanitize_text_field( (string) $request->get_param( 'hint' ) ) );
		if ( is_wp_error( $draft ) ) {
			$draft->add_data( array( 'status' => 400 ) );
			return $draft;
		}
		return array( 'draft' => $draft );
	}

	/**
	 * Message every connected site.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function broadcast( WP_REST_Request $request ) {
		$title = sanitize_text_field( (string) $request->get_param( 'title' ) );
		if ( '' === $title ) {
			return new WP_Error( 'helpdesk_hero_pro_title', __( 'Give the message a title.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
		}
		$sent = Helpdesk_Hero_Pro_Team::broadcast(
			array(
				'title'  => $title,
				'body'   => sanitize_textarea_field( (string) $request->get_param( 'body' ) ),
				'level'  => in_array( $request->get_param( 'level' ), array( 'info', 'success', 'warning', 'error' ), true ) ? $request->get_param( 'level' ) : 'info',
				'action' => array(
					'label' => sanitize_text_field( (string) $request->get_param( 'action_label' ) ),
					'url'   => sanitize_text_field( (string) $request->get_param( 'action_url' ) ),
				),
			)
		);
		return array( 'sent' => $sent );
	}

	/**
	 * Analytics report.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function analytics( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Analytics::report( (int) ( $request->get_param( 'days' ) ? $request->get_param( 'days' ) : 30 ), (int) $request->get_param( 'site' ) );
	}

	/**
	 * Analytics explorer.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function explore( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Analytics::explore( (array) $request->get_query_params() );
	}

	/**
	 * Supporter KPIs.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function team_kpis( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Analytics::team( (string) $request->get_param( 'from' ), (string) $request->get_param( 'to' ) );
	}

	/**
	 * Saved reports.
	 *
	 * @return array
	 */
	public static function reports() {
		return Helpdesk_Hero_Pro_Views::reports();
	}

	/**
	 * Save a report.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function save_report( WP_REST_Request $request ) {
		$saved = Helpdesk_Hero_Pro_Views::save( array_merge( (array) $request->get_param( 'view' ), array( 'kind' => 'report' ) ), 'shared' === $request->get_param( 'scope' ) ? 'shared' : 'personal' );
		return is_wp_error( $saved ) ? $saved : array_merge( self::reports(), array( 'saved' => $saved['id'] ) );
	}

	/**
	 * Delete a report.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function delete_report( WP_REST_Request $request ) {
		$done = Helpdesk_Hero_Pro_Views::delete( (string) $request['id'], (string) $request['scope'] );
		return is_wp_error( $done ) ? $done : self::reports();
	}

	/**
	 * Help desk settings.
	 *
	 * @return array
	 */
	public static function helpdesk() {
		return Helpdesk_Hero_Pro_Helpdesks::state();
	}

	/**
	 * Save help desk settings.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_helpdesk( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Helpdesks::save( (array) $request->get_json_params() );
	}

	/**
	 * Test the help desk connection.
	 *
	 * @return array
	 */
	public static function test_helpdesk() {
		return Helpdesk_Hero_Pro_Helpdesks::test();
	}

	/**
	 * Supporters and the hub users who can be chosen.
	 *
	 * @return array
	 */
	public static function supporters() {
		return array(
			'supporters' => array_values( Helpdesk_Hero_Pro_Team::supporters() ),
			'users'      => Helpdesk_Hero_Pro_Team::candidates(),
		);
	}

	/**
	 * Save supporters.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_supporters( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Team::save_supporters( (array) $request->get_param( 'supporters' ) );
		return self::supporters();
	}

	/**
	 * Macros and the variables they can use.
	 *
	 * @return array
	 */
	public static function macros() {
		return array(
			'macros'    => Helpdesk_Hero_Pro_Macros::all(),
			'variables' => Helpdesk_Hero_Pro_Macros::variables(),
		);
	}

	/**
	 * Save macros.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_macros( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Macros::save( (array) $request->get_param( 'macros' ) );
		return self::macros();
	}

	/**
	 * Slack and webhook settings.
	 *
	 * @return array
	 */
	public static function notify() {
		return array(
			'settings' => Helpdesk_Hero_Pro_Notify::public_settings(),
			'events'   => Helpdesk_Hero_Pro_Notify::events(),
		);
	}

	/**
	 * Save Slack and webhook settings.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function save_notify( WP_REST_Request $request ) {
		$saved = Helpdesk_Hero_Pro_Notify::save( (array) $request->get_json_params() );
		return is_wp_error( $saved ) ? $saved : array(
			'settings' => $saved,
			'events'   => Helpdesk_Hero_Pro_Notify::events(),
		);
	}

	/**
	 * Send a test notification.
	 *
	 * @return array|WP_Error
	 */
	public static function test_notify() {
		$r = Helpdesk_Hero_Pro_Notify::test();
		return is_wp_error( $r ) ? $r : array( 'ok' => true );
	}

	/**
	 * A hub ticket or a 404.
	 *
	 * @param int $id Ticket.
	 * @return array|WP_Error
	 */
	private static function hub_ticket( $id ) {
		$t = Helpdesk_Hero_Hub::ticket( (int) $id );
		return $t ? $t : new WP_Error( 'helpdesk_hero_pro_ticket', __( 'Ticket not found.', 'helpdesk-hero-pro' ), array( 'status' => 404 ) );
	}

	/**
	 * Time entries for a ticket.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function time_ticket( WP_REST_Request $request ) {
		$t = self::hub_ticket( (int) $request['id'] );
		return is_wp_error( $t ) ? $t : Helpdesk_Hero_Pro_Time::for_ticket( (int) $t['id'] );
	}

	/**
	 * Add time to a ticket.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function time_add( WP_REST_Request $request ) {
		$t = self::hub_ticket( (int) $request['id'] );
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		$added = Helpdesk_Hero_Pro_Time::add( $t, (array) $request->get_json_params() );
		return is_wp_error( $added ) ? $added : Helpdesk_Hero_Pro_Time::for_ticket( (int) $t['id'] );
	}

	/**
	 * Delete a time entry.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function time_delete( WP_REST_Request $request ) {
		$done = Helpdesk_Hero_Pro_Time::delete( (int) $request['id'] );
		return is_wp_error( $done ) ? $done : array( 'deleted' => true );
	}

	/**
	 * Time report.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function time_report( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Time::report( (string) $request->get_param( 'from' ), (string) $request->get_param( 'to' ), (int) $request->get_param( 'site' ) );
	}

	/**
	 * SLA settings.
	 *
	 * @return array
	 */
	public static function sla() {
		$sites = array();
		foreach ( Helpdesk_Hero_Hub::sites() as $s ) {
			$sites[ (string) $s['id'] ] = $s['name'] ? $s['name'] : $s['label'];
		}
		return array(
			'settings' => Helpdesk_Hero_Pro_SLA::settings(),
			'timezone' => wp_timezone_string(),
			'tiers'    => Helpdesk_Hero_Hub_Tiers::all(),
			'services' => Helpdesk_Hero_Hub::services(),
			'sites'    => $sites,
		);
	}

	/**
	 * Set a site's own SLA policy.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_site_sla( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_SLA::set_site( (int) $request['id'], sanitize_key( (string) $request->get_param( 'policy' ) ) );
		return self::sla();
	}

	/**
	 * Save SLA settings (open tickets are recalculated).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_sla( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_SLA::save( (array) $request->get_json_params() );
		return self::sla();
	}

	/**
	 * Custom statuses.
	 *
	 * @return array
	 */
	public static function statuses() {
		return array( 'statuses' => Helpdesk_Hero_Pro_Statuses::all() );
	}

	/**
	 * Save custom statuses.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_statuses( WP_REST_Request $request ) {
		return array( 'statuses' => Helpdesk_Hero_Pro_Statuses::save( (array) $request->get_param( 'statuses' ) ) );
	}

	/**
	 * Custom fields.
	 *
	 * @return array
	 */
	public static function fields() {
		return array(
			'fields' => Helpdesk_Hero_Pro_Extras::fields(),
			'types'  => Helpdesk_Hero_Pro_Extras::types(),
		);
	}

	/**
	 * Save custom fields (sent to every site).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_fields( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Extras::save_fields( (array) $request->get_param( 'fields' ) );
		return self::fields();
	}

	/**
	 * Attachment settings.
	 *
	 * @return array
	 */
	public static function attachments() {
		return array(
			'settings' => Helpdesk_Hero_Pro_Extras::attachment_settings(),
			'types'    => array_keys( Helpdesk_Hero_Hub_Attachments::mimes() ),
			'server'   => (int) floor( wp_max_upload_size() / MB_IN_BYTES ),
		);
	}

	/**
	 * Save attachment settings (sent to every site).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_attachments( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Extras::save_attachments( (array) $request->get_json_params() );
		return self::attachments();
	}

	/**
	 * Merge a ticket into another one.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function merge( WP_REST_Request $request ) {
		$source = self::hub_ticket( (int) $request['id'] );
		$target = self::hub_ticket( (int) $request->get_param( 'into' ) );
		if ( is_wp_error( $source ) ) {
			return $source;
		}
		if ( is_wp_error( $target ) ) {
			return $target;
		}
		$done = Helpdesk_Hero_Hub::merge( $source, $target );
		return is_wp_error( $done ) ? $done : array( 'into' => (int) $target['id'] );
	}

	/**
	 * Tickets of the same site this one can be merged into.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function merge_candidates( WP_REST_Request $request ) {
		$t = self::hub_ticket( (int) $request['id'] );
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		$out = array();
		foreach ( Helpdesk_Hero_Hub::tickets(
			array(
				'site_id' => (int) $t['site_id'],
				'status'  => '',
				'limit'   => 50,
			)
		) as $row ) {
			if ( (int) $row['id'] !== (int) $t['id'] ) {
				$out[] = array(
					'id'      => (int) $row['id'],
					'subject' => $row['subject'],
					'status'  => $row['status'],
				);
			}
		}
		return array( 'tickets' => $out );
	}

	/**
	 * Pro modules and whether each is on.
	 *
	 * @return array
	 */
	public static function modules() {
		return array(
			'modules' => Helpdesk_Hero_Pro_Modules::all(),
			'states'  => Helpdesk_Hero_Pro_Modules::states(),
		);
	}

	/**
	 * Switch modules on or off.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_modules( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Modules::save( (array) $request->get_param( 'states' ) );
		return self::modules();
	}

	/**
	 * Edit a time entry.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function time_update( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Time::update( (int) $request['id'], (array) $request->get_json_params() );
	}

	/**
	 * Set the billing state of many entries.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function time_bulk( WP_REST_Request $request ) {
		return array(
			'updated' => Helpdesk_Hero_Pro_Time::bulk_state(
				(array) $request->get_param( 'ids' ),
				(string) $request->get_param( 'state' ),
				(string) $request->get_param( 'ref' ),
				(string) $request->get_param( 'note' )
			),
		);
	}

	/**
	 * Time entries with filters.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function time_entries( WP_REST_Request $request ) {
		return Helpdesk_Hero_Pro_Time::query( $request->get_params() );
	}

	/**
	 * Site sessions not logged yet, as suggestions.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function time_sessions( WP_REST_Request $request ) {
		$t = self::hub_ticket( (int) $request['id'] );
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		$sessions = Helpdesk_Hero_Pro_Billing::sessions( $t );
		return is_wp_error( $sessions ) ? $sessions : array( 'sessions' => $sessions );
	}

	/**
	 * Set a ticket's service.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function ticket_service( WP_REST_Request $request ) {
		$t = self::hub_ticket( (int) $request['id'] );
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		$done = Helpdesk_Hero_Pro_Billing::set_service( $t, sanitize_key( (string) $request->get_param( 'service' ) ) );
		return is_wp_error( $done ) ? $done : Helpdesk_Hero_Pro_Time::for_ticket( (int) $t['id'] );
	}

	/**
	 * Billing settings and services.
	 *
	 * @return array
	 */
	public static function billing() {
		return array(
			'settings' => Helpdesk_Hero_Pro_Billing::settings(),
			'services' => Helpdesk_Hero_Pro_Billing::services(),
			'tiers'    => Helpdesk_Hero_Hub_Tiers::all(),
			'categories' => self::categories(),
		);
	}

	/**
	 * Every ticket category in the team policy and templates.
	 *
	 * @return string[]
	 */
	private static function categories() {
		$all = (array) ( Helpdesk_Hero_Hub_Policy::team()['tickets']['categories'] ?? array() );
		foreach ( Helpdesk_Hero_Hub_Templates::all() as $tpl ) {
			$all = array_merge( $all, (array) ( $tpl['policy']['tickets']['categories'] ?? array() ) );
		}
		return array_values( array_unique( array_map( 'strval', $all ) ) );
	}

	/**
	 * Save billing settings and services.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_billing( WP_REST_Request $request ) {
		$p = (array) $request->get_json_params();
		if ( isset( $p['settings'] ) ) {
			Helpdesk_Hero_Pro_Billing::save_settings( (array) $p['settings'] );
		}
		if ( isset( $p['services'] ) ) {
			Helpdesk_Hero_Pro_Billing::save_services( (array) $p['services'] );
		}
		return self::billing();
	}

	/**
	 * A site's rate and retainer.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function site_billing( WP_REST_Request $request ) {
		$id = (int) $request['id'];
		return array_merge(
			Helpdesk_Hero_Pro_Billing::site( $id ),
			array(
				'effective_rate' => Helpdesk_Hero_Pro_Billing::rate( $id, '' ),
				'currency'       => Helpdesk_Hero_Pro_Billing::settings()['currency'],
				'usage'          => Helpdesk_Hero_Pro_Time::usage( $id ),
			)
		);
	}

	/**
	 * Save a site's rate and retainer.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_site_billing( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Billing::save_site( (int) $request['id'], (array) $request->get_json_params() );
		return self::site_billing( $request );
	}

	/**
	 * Automations, with what they can use.
	 *
	 * @return array
	 */
	public static function automations() {
		$tags = array();
		foreach ( Helpdesk_Hero_Hub_Tags::all() as $t ) {
			$tags[ $t['id'] ] = $t['name'];
		}
		$sites = array();
		foreach ( Helpdesk_Hero_Hub::sites() as $s ) {
			$sites[ (string) $s['id'] ] = $s['name'] ? $s['name'] : $s['label'];
		}
		$statuses = array(
			'open'    => __( 'Open', 'helpdesk-hero-pro' ),
			'pending' => __( 'Waiting on customer', 'helpdesk-hero-pro' ),
			'closed'  => __( 'Closed', 'helpdesk-hero-pro' ),
		);
		foreach ( Helpdesk_Hero_Hub::custom_statuses() as $c ) {
			$statuses[ 'custom:' . $c['id'] ] = $c['label'];
		}
		$team = array();
		foreach ( Helpdesk_Hero_Hub::team() as $u ) {
			$team[ (string) $u['id'] ] = $u['name'];
		}
		$replies = array();
		foreach ( Helpdesk_Hero_Pro_Macros::all() as $m ) {
			$replies[ $m['id'] ] = $m['name'];
		}
		$services = array();
		foreach ( Helpdesk_Hero_Hub::services() as $x ) {
			$services[ $x['id'] ] = $x['name'];
		}
		$tiers = array();
		foreach ( Helpdesk_Hero_Hub_Tiers::all() as $t ) {
			$tiers[ $t['id'] ] = $t['name'];
		}
		return array(
			'automations' => Helpdesk_Hero_Pro_Automations::all(),
			'triggers'    => Helpdesk_Hero_Pro_Automations::triggers(),
			'fields'      => Helpdesk_Hero_Pro_Automations::fields(),
			'actions'     => Helpdesk_Hero_Pro_Automations::actions(),
			'options'     => array(
				'tags'       => $tags,
				'sites'      => $sites,
				'statuses'   => $statuses,
				'team'       => $team,
				'replies'    => $replies,
				'services'   => $services,
				'tiers'      => $tiers,
				'priorities' => array(
					'low'    => __( 'Low', 'helpdesk-hero-pro' ),
					'normal' => __( 'Normal', 'helpdesk-hero-pro' ),
					'high'   => __( 'High', 'helpdesk-hero-pro' ),
					'urgent' => __( 'Urgent', 'helpdesk-hero-pro' ),
				),
			),
		);
	}

	/**
	 * Save automations.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	public static function save_automations( WP_REST_Request $request ) {
		Helpdesk_Hero_Pro_Automations::save( (array) $request->get_param( 'automations' ) );
		return self::automations();
	}

	/**
	 * Manual automations, for the buttons on tickets.
	 *
	 * @return array
	 */
	public static function manual_automations() {
		$out = array();
		foreach ( Helpdesk_Hero_Pro_Automations::all() as $a ) {
			if ( 'manual' === $a['trigger'] && $a['enabled'] ) {
				$out[] = array(
					'id'   => $a['id'],
					'name' => $a['name'],
				);
			}
		}
		return array( 'automations' => $out );
	}

	/**
	 * Run a manual automation on a ticket (supporters only: it may reply or change status).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function run_automation( WP_REST_Request $request ) {
		if ( ! Helpdesk_Hero_Hub::can_support() ) {
			return new WP_Error( 'helpdesk_hero_hub_not_supporter', __( 'Only the supporters your team has chosen can do this.', 'helpdesk-hero-pro' ), array( 'status' => 403 ) );
		}
		return Helpdesk_Hero_Pro_Automations::run_manual( (string) $request['id'], (int) $request['ticket'] );
	}

	/**
	 * Views with counts.
	 *
	 * @return array
	 */
	public static function views() {
		return Helpdesk_Hero_Pro_Views::with_counts();
	}

	/**
	 * Save a view.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function save_view( WP_REST_Request $request ) {
		$saved = Helpdesk_Hero_Pro_Views::save( (array) $request->get_param( 'view' ), 'shared' === $request->get_param( 'scope' ) ? 'shared' : 'personal' );
		return is_wp_error( $saved ) ? $saved : array_merge( self::views(), array( 'saved' => $saved['id'] ) );
	}

	/**
	 * Delete a view.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array|WP_Error
	 */
	public static function delete_view( WP_REST_Request $request ) {
		$done = Helpdesk_Hero_Pro_Views::delete( (string) $request['id'], (string) $request['scope'] );
		return is_wp_error( $done ) ? $done : self::views();
	}

	/**
	 * Whether starter examples are present.
	 *
	 * @return array
	 */
	public static function examples() {
		return array( 'present' => Helpdesk_Hero_Pro_Examples::present() );
	}

	/**
	 * Add the starter examples.
	 *
	 * @return array
	 */
	public static function add_examples() {
		Helpdesk_Hero_Pro_Examples::add();
		return self::examples();
	}

	/**
	 * Remove examples nobody changed.
	 *
	 * @return array
	 */
	public static function remove_examples() {
		return array_merge( self::examples(), array( 'removed' => Helpdesk_Hero_Pro_Examples::remove() ) );
	}
}
