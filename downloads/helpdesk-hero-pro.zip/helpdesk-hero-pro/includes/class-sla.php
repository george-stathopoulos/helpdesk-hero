<?php
/**
 * Service level agreements.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Targets for the first reply and for resolution, per customer tier (with a default for sites
 * without a tier), counted in business hours if the team sets them.
 *
 * - The clock starts when a ticket arrives.
 * - It pauses while a ticket waits on the customer, and the time paused is added back.
 * - A reopened ticket gets a fresh resolution target.
 * - An hour before a target, and when it's missed, the team is told (email to the assignee or
 *   the team, Slack, webhooks) once each.
 *
 * Deadlines are stored on the ticket (respond_due, resolve_due), so the inbox can sort by them.
 */
final class Helpdesk_Hero_Pro_SLA {

	const OPTION = 'helpdesk_hero_pro_sla';
	const CRON   = 'helpdesk_hero_pro_sla_check';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'helpdesk_hero_hub_tier', array( __CLASS__, 'clean_tier' ), 10, 2 );
		add_filter( 'helpdesk_hero_hub_sla_enabled', array( __CLASS__, 'enabled' ) );
		add_action( 'helpdesk_hero_hub_ticket_created', array( __CLASS__, 'on_created' ), 5 );
		add_action( 'helpdesk_hero_hub_status_changed', array( __CLASS__, 'on_status' ), 5, 2 );
		add_action( 'helpdesk_hero_hub_site_tier_changed', array( __CLASS__, 'on_site_tier' ), 10, 1 );
		add_action( 'helpdesk_hero_hub_tiers_saved', array( __CLASS__, 'recalculate_all' ) );
		add_action( 'helpdesk_hero_pro_service_changed', array( __CLASS__, 'on_service' ) );
		add_action( self::CRON, array( __CLASS__, 'check' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	/**
	 * Check deadlines every 5 minutes.
	 */
	public static function schedule() {
		if ( self::enabled( false ) && ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, 'helpdesk_hero_5min', self::CRON );
		} elseif ( ! self::enabled( false ) && wp_next_scheduled( self::CRON ) ) {
			wp_clear_scheduled_hook( self::CRON );
		}
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Settings.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Settings: business hours, named SLA policies, the default policy, and which policy each
	 * customer tier, service and site uses.
	 *
	 * @return array { hours, policies: [ { id, name, respond, resolve } ], default, tiers{}, services{}, sites{} }
	 */
	public static function settings() {
		$s = get_option( self::OPTION, array() );
		$s = is_array( $s ) ? $s : array();
		$h = (array) ( $s['hours'] ?? array() );
		if ( ! isset( $s['policies'] ) ) {
			$s = self::migrate( $s );
		}
		$policies = array();
		foreach ( (array) $s['policies'] as $p ) {
			if ( ! empty( $p['id'] ) ) {
				$policies[] = array(
					'id'      => (string) $p['id'],
					'name'    => (string) ( $p['name'] ?? '' ),
					'respond' => (int) ( $p['respond'] ?? 0 ),
					'resolve' => (int) ( $p['resolve'] ?? 0 ),
				);
			}
		}
		return array(
			'hours'    => array(
				'enabled' => ! empty( $h['enabled'] ),
				'days'    => array_values( array_map( 'intval', (array) ( $h['days'] ?? array( 1, 2, 3, 4, 5 ) ) ) ),
				'start'   => (string) ( $h['start'] ?? '09:00' ),
				'end'     => (string) ( $h['end'] ?? '17:00' ),
			),
			'policies' => $policies,
			'default'  => (string) ( $s['default'] ?? '' ),
			'tiers'    => (array) ( $s['tiers'] ?? array() ),
			'services' => (array) ( $s['services'] ?? array() ),
			'sites'    => (array) ( $s['sites'] ?? array() ),
		);
	}

	/**
	 * Settings from before named policies: the default targets become "Standard", and each
	 * tier's own targets become a policy named after the tier.
	 *
	 * @param array $s Old settings.
	 * @return array
	 */
	private static function migrate( array $s ) {
		$policies = array();
		$tiers    = array();
		$default  = '';
		$d        = (array) ( $s['default'] ?? array() );
		if ( ! empty( $d['respond'] ) || ! empty( $d['resolve'] ) ) {
			$policies[] = array(
				'id'      => 'standard',
				'name'    => __( 'Standard', 'helpdesk-hero-pro' ),
				'respond' => (int) ( $d['respond'] ?? 0 ),
				'resolve' => (int) ( $d['resolve'] ?? 0 ),
			);
			$default    = 'standard';
		}
		foreach ( Helpdesk_Hero_Hub_Tiers::all() as $tier ) {
			if ( ! empty( $tier['sla']['respond'] ) || ! empty( $tier['sla']['resolve'] ) ) {
				$id                   = 'tier-' . $tier['id'];
				$policies[]           = array(
					'id'      => $id,
					'name'    => $tier['name'],
					'respond' => (int) ( $tier['sla']['respond'] ?? 0 ),
					'resolve' => (int) ( $tier['sla']['resolve'] ?? 0 ),
				);
				$tiers[ $tier['id'] ] = $id;
			}
		}
		return array_merge(
			$s,
			array(
				'policies' => $policies,
				'default'  => $default,
				'tiers'    => $tiers,
				'services' => array(),
				'sites'    => array(),
			)
		);
	}

	/**
	 * Save settings and recalculate open tickets.
	 *
	 * @param array $in Values.
	 * @return array Settings.
	 */
	public static function save( array $in ) {
		$h     = (array) ( $in['hours'] ?? array() );
		$time  = static function ( $v, $fallback ) {
			return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', (string) $v ) ? (string) $v : $fallback;
		};
		$start = $time( $h['start'] ?? '', '09:00' );
		$end   = $time( $h['end'] ?? '', '17:00' );
		if ( strcmp( $end, $start ) <= 0 ) {
			$end = '17:00' > $start ? '17:00' : '23:59';
		}
		$policies = array();
		foreach ( array_slice( (array) ( $in['policies'] ?? array() ), 0, 30 ) as $p ) {
			$name = trim( sanitize_text_field( (string) ( $p['name'] ?? '' ) ) );
			if ( '' === $name ) {
				continue;
			}
			$id = sanitize_key( (string) ( $p['id'] ?? '' ) );
			$id = '' !== $id ? $id : substr( sanitize_title( $name ), 0, 40 );
			while ( '' === $id || isset( $policies[ $id ] ) ) {
				$id = 'sla-' . wp_rand( 100, 999 );
			}
			$policies[ $id ] = array_merge(
				array(
					'id'   => $id,
					'name' => substr( $name, 0, 60 ),
				),
				self::clean_targets( (array) $p )
			);
		}
		$known  = array_keys( $policies );
		$assign = static function ( $map ) use ( $known ) {
			$out = array();
			foreach ( (array) $map as $key => $policy ) {
				if ( in_array( (string) $policy, $known, true ) ) {
					$out[ sanitize_key( (string) $key ) ] = (string) $policy;
				}
			}
			return $out;
		};
		update_option(
			self::OPTION,
			array(
				'hours'    => array(
					'enabled' => ! empty( $h['enabled'] ),
					'days'    => array_values( array_unique( array_filter( array_map( 'intval', (array) ( $h['days'] ?? array() ) ), static fn( $d ) => $d >= 1 && $d <= 7 ) ) ),
					'start'   => $start,
					'end'     => $end,
				),
				'policies' => array_values( $policies ),
				'default'  => in_array( (string) ( $in['default'] ?? '' ), $known, true ) ? (string) $in['default'] : '',
				'tiers'    => $assign( $in['tiers'] ?? array() ),
				'services' => $assign( $in['services'] ?? array() ),
				'sites'    => $assign( $in['sites'] ?? array() ),
			),
			false
		);
		self::schedule();
		self::recalculate_all();
		return self::settings();
	}

	/**
	 * Set one site's SLA policy ('' = none of its own).
	 *
	 * @param int    $site_id Site.
	 * @param string $policy  Policy.
	 * @return array Settings.
	 */
	public static function set_site( $site_id, $policy ) {
		$s = self::settings();
		if ( '' === (string) $policy ) {
			unset( $s['sites'][ (string) (int) $site_id ] );
		} else {
			$s['sites'][ (string) (int) $site_id ] = (string) $policy;
		}
		return self::save( $s );
	}

	/**
	 * Targets in minutes (0 = none; at most 90 days).
	 *
	 * @param array $t { respond, resolve }.
	 * @return array
	 */
	private static function clean_targets( array $t ) {
		return array(
			'respond' => max( 0, min( 90 * 24 * 60, (int) ( $t['respond'] ?? 0 ) ) ),
			'resolve' => max( 0, min( 90 * 24 * 60, (int) ( $t['resolve'] ?? 0 ) ) ),
		);
	}

	/**
	 * Tiers saved: keep the SLA targets older versions stored on them (read once by migrate()).
	 *
	 * @param array $item Clean tier.
	 * @param array $raw  Tier as sent.
	 * @return array
	 */
	public static function clean_tier( $item, $raw ) {
		if ( isset( $raw['sla'] ) && is_array( $raw['sla'] ) ) {
			$item['sla'] = self::clean_targets( $raw['sla'] );
		}
		return $item;
	}

	/**
	 * Whether any SLA applies to anything.
	 *
	 * @param bool $enabled Value from the hub (ignored).
	 * @return bool
	 */
	public static function enabled( $enabled = false ) {
		unset( $enabled );
		$s = self::settings();
		return '' !== $s['default'] || $s['tiers'] || $s['services'] || $s['sites'];
	}

	/**
	 * A policy by ID.
	 *
	 * @param string $id ID.
	 * @return array|null
	 */
	public static function policy( $id ) {
		foreach ( self::settings()['policies'] as $p ) {
			if ( $p['id'] === $id ) {
				return $p;
			}
		}
		return null;
	}

	/**
	 * Targets for a ticket: the site's own policy; otherwise the strictest of its tier's and
	 * its service's; otherwise the default.
	 *
	 * @param array|null $site    Site.
	 * @param string     $service Ticket's service.
	 * @return array { respond, resolve, policy } minutes, policy name.
	 */
	public static function targets( $site, $service = '' ) {
		$s    = self::settings();
		$none = array(
			'respond' => 0,
			'resolve' => 0,
			'policy'  => '',
		);
		if ( $site && isset( $s['sites'][ (string) (int) $site['id'] ] ) ) {
			$p = self::policy( $s['sites'][ (string) (int) $site['id'] ] );
			if ( $p ) {
				return array_merge( $p, array( 'policy' => $p['name'] ) );
			}
		}
		$found = array();
		if ( $site && '' !== (string) $site['tier'] && isset( $s['tiers'][ $site['tier'] ] ) ) {
			$found[] = self::policy( $s['tiers'][ $site['tier'] ] );
		}
		if ( '' !== (string) $service && isset( $s['services'][ $service ] ) ) {
			$found[] = self::policy( $s['services'][ $service ] );
		}
		$found = array_filter( $found );
		if ( ! $found ) {
			$p = '' !== $s['default'] ? self::policy( $s['default'] ) : null;
			return $p ? array_merge( $p, array( 'policy' => $p['name'] ) ) : $none;
		}
		// The strictest target of each kind wins (0 means none).
		$pick = static function ( $key ) use ( $found ) {
			$values = array_filter( array_map( 'intval', array_column( $found, $key ) ) );
			return $values ? min( $values ) : 0;
		};
		return array(
			'respond' => $pick( 'respond' ),
			'resolve' => $pick( 'resolve' ),
			'policy'  => implode( ' + ', array_column( $found, 'name' ) ),
		);
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Business-hours arithmetic.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Today's working window in the site's timezone, or null on a day off.
	 *
	 * @param DateTimeImmutable $day Any moment of the day (site timezone).
	 * @param array             $h   Hours settings.
	 * @return DateTimeImmutable[]|null [ start, end ]
	 */
	private static function window( DateTimeImmutable $day, array $h ) {
		if ( ! in_array( (int) $day->format( 'N' ), $h['days'], true ) ) {
			return null;
		}
		list( $sh, $sm ) = array_map( 'intval', explode( ':', $h['start'] ) );
		list( $eh, $em ) = array_map( 'intval', explode( ':', $h['end'] ) );
		return array( $day->setTime( $sh, $sm ), $day->setTime( $eh, $em ) );
	}

	/**
	 * Whether a moment falls within business hours (always true without business hours).
	 *
	 * @param int $ts Unix time.
	 * @return bool
	 */
	public static function in_hours( $ts ) {
		$h = self::settings()['hours'];
		if ( ! $h['enabled'] || ! $h['days'] ) {
			return true;
		}
		$at = ( new DateTimeImmutable( '@' . (int) $ts ) )->setTimezone( wp_timezone() );
		$w  = self::window( $at, $h );
		return $w && $at >= $w[0] && $at < $w[1];
	}

	/**
	 * A moment plus working minutes.
	 *
	 * @param int $from    Unix time.
	 * @param int $minutes Minutes.
	 * @return int Unix time.
	 */
	public static function add_minutes( $from, $minutes ) {
		$h = self::settings()['hours'];
		if ( ! $h['enabled'] || ! $h['days'] ) {
			return $from + $minutes * MINUTE_IN_SECONDS;
		}
		$left = $minutes * MINUTE_IN_SECONDS;
		$at   = ( new DateTimeImmutable( '@' . $from ) )->setTimezone( wp_timezone() );
		for ( $guard = 0; $guard < 800; $guard++ ) {
			$w = self::window( $at, $h );
			if ( $w && $at < $w[1] ) {
				$start = $at > $w[0] ? $at : $w[0];
				$room  = $w[1]->getTimestamp() - $start->getTimestamp();
				if ( $left <= $room ) {
					return $start->getTimestamp() + $left;
				}
				$left -= $room;
			}
			$at = $at->modify( '+1 day' )->setTime( 0, 0 );
		}
		return $from + $minutes * MINUTE_IN_SECONDS;
	}

	/**
	 * Working seconds between two moments.
	 *
	 * @param int $from Unix time.
	 * @param int $to   Unix time.
	 * @return int Seconds.
	 */
	public static function between( $from, $to ) {
		if ( $to <= $from ) {
			return 0;
		}
		$h = self::settings()['hours'];
		if ( ! $h['enabled'] || ! $h['days'] ) {
			return $to - $from;
		}
		$total = 0;
		$at    = ( new DateTimeImmutable( '@' . $from ) )->setTimezone( wp_timezone() );
		$end   = ( new DateTimeImmutable( '@' . $to ) )->setTimezone( wp_timezone() );
		for ( $guard = 0; $guard < 800 && $at < $end; $guard++ ) {
			$w = self::window( $at, $h );
			if ( $w ) {
				$a = max( $at->getTimestamp(), $w[0]->getTimestamp() );
				$b = min( $end->getTimestamp(), $w[1]->getTimestamp() );
				if ( $b > $a ) {
					$total += $b - $a;
				}
			}
			$at = $at->modify( '+1 day' )->setTime( 0, 0 );
		}
		return $total;
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Deadlines.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * UTC MySQL time.
	 *
	 * @param int $ts Unix time.
	 * @return string
	 */
	private static function mysql( $ts ) {
		return gmdate( 'Y-m-d H:i:s', $ts );
	}

	/**
	 * Unix time from UTC MySQL.
	 *
	 * @param string $mysql Date.
	 * @return int
	 */
	private static function ts( $mysql ) {
		return (int) strtotime( $mysql . ' UTC' );
	}

	/**
	 * Set a ticket's deadlines from its site's targets, counting from when it arrived.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function apply( array $ticket ) {
		$targets = self::targets( Helpdesk_Hero_Hub::site( (int) $ticket['site_id'] ), (string) $ticket['service'] );
		$start   = self::ts( $ticket['created_at'] );
		Helpdesk_Hero_Hub::update_ticket(
			(int) $ticket['id'],
			array(
				'respond_due'   => $targets['respond'] ? self::mysql( self::add_minutes( $start, $targets['respond'] ) ) : null,
				'resolve_due'   => $targets['resolve'] ? self::mysql( self::add_minutes( $start, $targets['resolve'] ) ) : null,
				'sla_paused_at' => 'pending' === $ticket['status'] && $targets['resolve'] ? ( $ticket['sla_paused_at'] ? $ticket['sla_paused_at'] : Helpdesk_Hero_Hub_DB::now() ) : null,
				'updated_at'    => $ticket['updated_at'],
			)
		);
	}

	/**
	 * New ticket.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_created( $ticket ) {
		if ( is_array( $ticket ) && self::enabled() ) {
			self::apply( $ticket );
		}
	}

	/**
	 * Status changes pause, resume and restart the clock.
	 *
	 * @param array  $ticket Ticket before the change.
	 * @param string $status New status.
	 */
	public static function on_status( $ticket, $status ) {
		$fresh = Helpdesk_Hero_Hub::ticket( (int) $ticket['id'] );
		if ( ! $fresh || ( empty( $fresh['resolve_due'] ) && empty( $fresh['respond_due'] ) ) ) {
			return;
		}
		$data = array( 'updated_at' => $fresh['updated_at'] );
		if ( 'pending' === $status ) {
			$data['sla_paused_at'] = Helpdesk_Hero_Hub_DB::now();
		} elseif ( ! empty( $fresh['sla_paused_at'] ) && ! empty( $fresh['resolve_due'] ) ) {
			// Add the paused working time back to the resolution target.
			$paused                = self::between( self::ts( $fresh['sla_paused_at'] ), time() );
			$due                   = self::ts( $fresh['resolve_due'] );
			$data['resolve_due']   = self::mysql( self::add_minutes( $due, (int) ceil( $paused / MINUTE_IN_SECONDS ) ) );
			$data['sla_paused_at'] = null;
		}
		if ( 'closed' === $ticket['status'] && 'open' === $status ) {
			// Reopened: a fresh resolution target from now.
			$targets = self::targets( Helpdesk_Hero_Hub::site( (int) $fresh['site_id'] ), (string) $fresh['service'] );
			if ( $targets['resolve'] ) {
				$data['resolve_due'] = self::mysql( self::add_minutes( time(), $targets['resolve'] ) );
			}
		}
		Helpdesk_Hero_Hub::update_ticket( (int) $fresh['id'], $data );
	}

	/**
	 * A site's tier changed: new targets for its open tickets.
	 *
	 * @param int $site_id Site.
	 */
	public static function on_site_tier( $site_id ) {
		foreach ( Helpdesk_Hero_Hub::tickets(
			array(
				'site_id' => (int) $site_id,
				'status'  => 'active',
				'limit'   => 500,
			)
		) as $row ) {
			$t = Helpdesk_Hero_Hub::ticket( (int) $row['id'] );
			if ( $t ) {
				self::apply( $t );
			}
		}
	}

	/**
	 * A ticket's service changed: new targets.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_service( $ticket ) {
		$fresh = Helpdesk_Hero_Hub::ticket( (int) $ticket['id'] );
		if ( $fresh && 'closed' !== $fresh['status'] ) {
			self::apply( $fresh );
		}
	}

	/**
	 * Targets changed: recalculate every open ticket (up to 2,000).
	 */
	public static function recalculate_all() {
		foreach ( Helpdesk_Hero_Hub::tickets(
			array(
				'status' => 'active',
				'limit'  => 2000,
			)
		) as $row ) {
			$t = Helpdesk_Hero_Hub::ticket( (int) $row['id'] );
			if ( $t ) {
				self::apply( $t );
			}
		}
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Alerts.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Warn about deadlines within the hour, and missed ones, once each.
	 */
	public static function check() {
		global $wpdb;
		$soon = Helpdesk_Hero_Hub_DB::now( HOUR_IN_SECONDS );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE status <> 'closed' AND merged_into = 0 AND ( ( first_response_at IS NULL AND respond_due IS NOT NULL AND respond_due < %s ) OR ( sla_paused_at IS NULL AND resolve_due IS NOT NULL AND resolve_due < %s ) ) LIMIT 200", Helpdesk_Hero_Hub_DB::table( 'tickets' ), $soon, $soon ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		foreach ( $rows as $row ) {
			$ticket = Helpdesk_Hero_Hub::ticket( (int) $row['id'] );
			$state  = $ticket ? Helpdesk_Hero_Hub::sla_state( $ticket ) : null;
			if ( ! $state || ! in_array( $state['state'], array( 'soon', 'breached' ), true ) ) {
				continue;
			}
			$kind = 'breached' === $state['state'] ? 'breached' : 'warning';
			$key  = $kind . '|' . $state['stage'] . '|' . $state['due'];
			foreach ( Helpdesk_Hero_Hub::history( (int) $ticket['id'] ) as $event ) {
				if ( 'sla_alert' === $event['type'] && ( $event['payload']['key'] ?? '' ) === $key ) {
					continue 2;
				}
			}
			Helpdesk_Hero_Hub::log(
				$ticket,
				'sla_alert',
				array(
					'kind'  => $kind,
					'stage' => $state['stage'],
					'key'   => $key,
				)
			);
			self::email( $ticket, $kind, $state );
			/**
			 * Fires when a ticket's SLA is about to be missed (warning) or was missed (breached).
			 *
			 * @param array  $ticket Ticket.
			 * @param string $kind   warning | breached.
			 */
			do_action( 'helpdesk_hero_pro_sla_alert', $ticket, $kind );
		}
	}

	/**
	 * Email the assignee, or the team when nobody is assigned.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $kind   warning | breached.
	 * @param array  $state  SLA state.
	 */
	private static function email( array $ticket, $kind, array $state ) {
		$user = (int) $ticket['assignee_id'] ? get_userdata( (int) $ticket['assignee_id'] ) : false;
		$to   = $user ? $user->user_email : Helpdesk_Hero_Hub_Settings::notify_email();
		if ( ! $to ) {
			return;
		}
		$what = 'respond' === $state['stage'] ? __( 'first reply', 'helpdesk-hero-pro' ) : __( 'resolution', 'helpdesk-hero-pro' );
		wp_mail(
			$to,
			'breached' === $kind
				/* translators: %s: ticket subject */
				? sprintf( __( '[SLA missed] %s', 'helpdesk-hero-pro' ), $ticket['subject'] )
				/* translators: %s: ticket subject */
				: sprintf( __( '[SLA due soon] %s', 'helpdesk-hero-pro' ), $ticket['subject'] ),
			sprintf(
				/* translators: 1: "first reply" or "resolution", 2: date, 3: link */
				'breached' === $kind ? __( "The %1\$s target for this ticket was %2\$s.\n\n%3\$s", 'helpdesk-hero-pro' ) : __( "The %1\$s target for this ticket is %2\$s.\n\n%3\$s", 'helpdesk-hero-pro' ),
				$what,
				wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $state['due'] ) ),
				Helpdesk_Hero_Hub::ticket_url( (int) $ticket['id'] )
			)
		);
	}
}
