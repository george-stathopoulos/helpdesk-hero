<?php
/**
 * Help Scout and Zendesk for the hub.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the Help Scout and Zendesk connectors with the hub and stores their settings.
 * Keys are never autoloaded or sent to the browser.
 */
final class Helpdesk_Hero_Pro_Helpdesks {

	const OPTION  = 'helpdesk_hero_pro_helpdesk';
	const SECRETS = 'helpdesk_hero_pro_helpdesk_secrets';

	/**
	 * Register hooks (licensed hubs only).
	 */
	public static function init() {
		if ( ! self::ready() ) {
			return;
		}
		add_filter(
			'helpdesk_hero_hub_helpdesks',
			static function ( $connectors ) {
				return array_merge(
					$connectors,
					array(
						'helpscout' => 'Helpdesk_Hero_Pro_HelpScout',
						'zendesk'   => 'Helpdesk_Hero_Pro_Zendesk',
					)
				);
			}
		);
	}

	/**
	 * Whether the Help Scout and Zendesk connections are available. They are switched off (shown as
	 * coming soon) until they have been verified against real accounts.
	 *
	 * @return bool
	 */
	public static function ready() {
		/**
		 * Filters whether the Help Scout and Zendesk connections are available.
		 *
		 * @param bool $ready Ready.
		 */
		return (bool) apply_filters( 'helpdesk_hero_pro_helpdesks_ready', false );
	}

	/**
	 * Defaults.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'helpscout_app_id'  => '',
			'helpscout_mailbox' => '',
			'zendesk_subdomain' => '',
			'zendesk_email'     => '',
		);
	}

	/**
	 * One setting.
	 *
	 * @param string $key Key.
	 * @return string
	 */
	public static function get( $key ) {
		$stored = get_option( self::OPTION, array() );
		$all    = array_merge( self::defaults(), is_array( $stored ) ? $stored : array() );
		return (string) ( $all[ $key ] ?? '' );
	}

	/**
	 * A secret.
	 *
	 * @param string $key helpscout_app_secret | zendesk_token.
	 * @return string
	 */
	public static function secret( $key ) {
		$stored = get_option( self::SECRETS, array() );
		return is_array( $stored ) && isset( $stored[ $key ] ) ? (string) $stored[ $key ] : '';
	}

	/**
	 * Settings for the dashboard (secrets only as "is set").
	 *
	 * @return array
	 */
	public static function state() {
		$settings = array();
		foreach ( array_keys( self::defaults() ) as $key ) {
			$settings[ $key ] = self::get( $key );
		}
		$settings['helpdesk'] = (string) Helpdesk_Hero_Hub_Settings::get( 'helpdesk' );
		return array(
			'ready'    => self::ready(),
			'settings' => $settings,
			'secrets'  => array(
				'helpscout_app_secret' => '' !== self::secret( 'helpscout_app_secret' ),
				'zendesk_token'        => '' !== self::secret( 'zendesk_token' ),
			),
		);
	}

	/**
	 * Save settings; secrets change only when a new value is sent.
	 *
	 * @param array $p Values.
	 * @return array State.
	 */
	public static function save( array $p ) {
		if ( ! self::ready() ) {
			Helpdesk_Hero_Hub_Settings::update( array( 'helpdesk' => 'none' ) );
			return self::state();
		}
		$helpdesk = sanitize_key( (string) ( $p['helpdesk'] ?? 'none' ) );
		Helpdesk_Hero_Hub_Settings::update( array( 'helpdesk' => in_array( $helpdesk, array( 'helpscout', 'zendesk' ), true ) ? $helpdesk : 'none' ) );
		update_option(
			self::OPTION,
			array(
				'helpscout_app_id'  => sanitize_text_field( (string) ( $p['helpscout_app_id'] ?? '' ) ),
				'helpscout_mailbox' => preg_replace( '/\D/', '', (string) ( $p['helpscout_mailbox'] ?? '' ) ),
				'zendesk_subdomain' => sanitize_text_field( (string) ( $p['zendesk_subdomain'] ?? '' ) ),
				'zendesk_email'     => sanitize_email( (string) ( $p['zendesk_email'] ?? '' ) ),
			),
			false
		);
		$secrets = get_option( self::SECRETS, array() );
		$secrets = is_array( $secrets ) ? $secrets : array();
		foreach ( array( 'helpscout_app_secret', 'zendesk_token' ) as $key ) {
			$value = trim( sanitize_text_field( (string) ( $p[ $key ] ?? '' ) ) );
			if ( '' !== $value ) {
				$secrets[ $key ] = $value;
			}
		}
		update_option( self::SECRETS, $secrets, false );
		delete_transient( Helpdesk_Hero_Pro_HelpScout::TOKEN );
		return self::state();
	}

	/**
	 * Test the chosen help desk.
	 *
	 * @return array { ok, message, mailboxes? }
	 */
	public static function test() {
		if ( ! self::ready() ) {
			return array(
				'ok'      => false,
				'message' => __( 'Help Scout and Zendesk connections are coming soon.', 'helpdesk-hero-pro' ),
			);
		}
		$helpdesk = Helpdesk_Hero_Hub_Helpdesk::current();
		if ( ! $helpdesk ) {
			return array(
				'ok'      => false,
				'message' => __( 'Fill in the help desk details and save first.', 'helpdesk-hero-pro' ),
			);
		}
		$result = $helpdesk->test();
		$out    = array(
			'ok'      => ! is_wp_error( $result ),
			'message' => is_wp_error( $result ) ? $result->get_error_message() : $result,
		);
		if ( $helpdesk instanceof Helpdesk_Hero_Pro_HelpScout ) {
			$boxes = $helpdesk->mailboxes();
			if ( ! is_wp_error( $boxes ) ) {
				$out['mailboxes'] = array();
				foreach ( $boxes as $id => $name ) {
					$out['mailboxes'][] = array(
						'id'   => (string) $id,
						'name' => $name,
					);
				}
			}
		}
		return $out;
	}
}
