<?php
/**
 * Starter examples.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * A starter set the team can add with one click, to see Pro working before setting it up:
 * customer tiers, SLA policies, tags, categories, custom statuses, views and automations.
 *
 * - Nothing is added unless someone asks.
 * - Automations are added switched off, so they never act on real tickets by surprise.
 * - Each example is remembered with a fingerprint. "Remove examples" deletes only the ones
 *   nobody has changed; edited ones are kept as the team's own.
 */
final class Helpdesk_Hero_Pro_Examples {

	const OPTION = 'helpdesk_hero_pro_examples';

	/**
	 * Fingerprint of an item, to tell whether it was changed.
	 *
	 * @param mixed $item Item.
	 * @return string
	 */
	private static function fingerprint( $item ) {
		if ( is_array( $item ) ) {
			unset( $item['count'] );
			ksort( $item );
		}
		return md5( (string) wp_json_encode( $item ) );
	}

	/**
	 * Examples added so far: kind => [ id => fingerprint ].
	 *
	 * @return array
	 */
	public static function added() {
		$a = get_option( self::OPTION, array() );
		return is_array( $a ) ? $a : array();
	}

	/**
	 * Whether examples are present.
	 *
	 * @return bool
	 */
	public static function present() {
		foreach ( self::added() as $items ) {
			if ( $items ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Add the starter set (items that already exist are left alone).
	 *
	 * @return array What was added, per kind.
	 */
	public static function add() {
		$added = self::added();
		$note  = static function ( $kind, $id, $item ) use ( &$added ) {
			$added[ $kind ][ $id ] = self::fingerprint( $item );
		};

		// Customer tiers.
		$tiers = Helpdesk_Hero_Hub_Tiers::all();
		$ids   = wp_list_pluck( $tiers, 'id' );
		foreach (
			array(
				array( 'vip', __( 'VIP', 'helpdesk-hero-pro' ), '#eda100', __( 'Our most important customers: fastest replies.', 'helpdesk-hero-pro' ) ),
				array( 'care-plan', __( 'Care plan', 'helpdesk-hero-pro' ), '#2a78d6', __( 'Customers on a monthly maintenance plan.', 'helpdesk-hero-pro' ) ),
			) as $t
		) {
			if ( ! in_array( $t[0], $ids, true ) ) {
				$tiers[] = array(
					'id'          => $t[0],
					'name'        => $t[1],
					'color'       => $t[2],
					'description' => $t[3],
				);
			}
		}
		$tiers = Helpdesk_Hero_Hub_Tiers::save( $tiers );
		foreach ( $tiers as $t ) {
			if ( in_array( $t['id'], array( 'vip', 'care-plan' ), true ) && ! in_array( $t['id'], $ids, true ) ) {
				$note( 'tiers', $t['id'], $t );
			}
		}

		// SLA policies (VIP's goes to the VIP tier).
		$sla      = Helpdesk_Hero_Pro_SLA::settings();
		$existing = wp_list_pluck( $sla['policies'], 'id' );
		$new      = array(
			array( 'standard', __( 'Standard', 'helpdesk-hero-pro' ), 8 * 60, 48 * 60 ),
			array( 'priority', __( 'Priority', 'helpdesk-hero-pro' ), 2 * 60, 24 * 60 ),
			array( 'vip', __( 'VIP', 'helpdesk-hero-pro' ), 60, 8 * 60 ),
		);
		foreach ( $new as $p ) {
			if ( ! in_array( $p[0], $existing, true ) ) {
				$sla['policies'][] = array(
					'id'      => $p[0],
					'name'    => $p[1],
					'respond' => $p[2],
					'resolve' => $p[3],
				);
			}
		}
		if ( '' === $sla['default'] ) {
			$sla['default'] = 'standard';
		}
		if ( empty( $sla['tiers']['vip'] ) ) {
			$sla['tiers']['vip'] = 'vip';
		}
		$saved = Helpdesk_Hero_Pro_SLA::save( $sla );
		foreach ( $saved['policies'] as $p ) {
			if ( in_array( $p['id'], array( 'standard', 'priority', 'vip' ), true ) && ! in_array( $p['id'], $existing, true ) ) {
				$note( 'sla', $p['id'], $p );
			}
		}

		// Tags.
		$tags  = Helpdesk_Hero_Hub_Tags::all();
		$have  = wp_list_pluck( $tags, 'id' );
		$extra = array(
			array( 'security', __( 'Security', 'helpdesk-hero-pro' ), '#e34948' ),
			array( 'performance', __( 'Performance', 'helpdesk-hero-pro' ), '#eda100' ),
			array( 'feature-request', __( 'Feature request', 'helpdesk-hero-pro' ), '#4a3aa7' ),
			array( 'billing', __( 'Billing', 'helpdesk-hero-pro' ), '#1baf7a' ),
			array( 'follow-up', __( 'Follow up', 'helpdesk-hero-pro' ), '#e87ba4' ),
		);
		foreach ( $extra as $t ) {
			if ( ! in_array( $t[0], $have, true ) ) {
				$tags[] = array(
					'id'    => $t[0],
					'name'  => $t[1],
					'color' => $t[2],
				);
				$note( 'tags', $t[0], array( 'id' => $t[0], 'name' => $t[1], 'color' => $t[2] ) );
			}
		}
		Helpdesk_Hero_Hub_Tags::save( $tags );

		// Categories in the team's default policy.
		$policy  = Helpdesk_Hero_Hub_Policy::team();
		$cats    = (array) $policy['tickets']['categories'];
		$starter = array(
			__( 'Something is broken', 'helpdesk-hero-pro' ),
			__( 'Plugin or theme conflict', 'helpdesk-hero-pro' ),
			__( 'Slow site', 'helpdesk-hero-pro' ),
			__( 'Security', 'helpdesk-hero-pro' ),
			__( 'Billing question', 'helpdesk-hero-pro' ),
			__( 'How do I…?', 'helpdesk-hero-pro' ),
			__( 'Change request', 'helpdesk-hero-pro' ),
		);
		foreach ( $starter as $c ) {
			if ( ! in_array( $c, $cats, true ) ) {
				$cats[] = $c;
				$note( 'categories', $c, $c );
			}
		}
		$policy['tickets']['categories'] = array_slice( $cats, 0, 20 );
		Helpdesk_Hero_Hub_Policy::save_team( $policy );

		// Custom statuses.
		$statuses = Helpdesk_Hero_Pro_Statuses::all();
		$have     = wp_list_pluck( $statuses, 'id' );
		foreach (
			array(
				array( 'in-progress', __( 'In progress', 'helpdesk-hero-pro' ), '#2a78d6', 'open', true ),
				array( 'waiting-third-party', __( 'Waiting on a third party', 'helpdesk-hero-pro' ), '#eda100', 'pending', false ),
			) as $st
		) {
			if ( ! in_array( $st[0], $have, true ) ) {
				$statuses[] = array(
					'id'     => $st[0],
					'label'  => $st[1],
					'color'  => $st[2],
					'base'   => $st[3],
					'public' => $st[4],
				);
			}
		}
		foreach ( Helpdesk_Hero_Pro_Statuses::save( $statuses ) as $st ) {
			if ( in_array( $st['id'], array( 'in-progress', 'waiting-third-party' ), true ) && ! in_array( $st['id'], $have, true ) ) {
				$note( 'statuses', $st['id'], $st );
			}
		}

		// Shared views.
		$views = wp_list_pluck( Helpdesk_Hero_Pro_Views::shared(), 'id' );
		foreach (
			array(
				array( 'my-tickets', __( 'My tickets', 'helpdesk-hero-pro' ), array( 'status' => 'active', 'assignee' => 'me' ) ),
				array( 'unassigned', __( 'Unassigned', 'helpdesk-hero-pro' ), array( 'status' => 'active', 'assignee' => '0' ) ),
				array( 'sla-overdue', __( 'SLA overdue', 'helpdesk-hero-pro' ), array( 'status' => 'active', 'sla' => 'overdue' ) ),
				array( 'vip-low-ratings', __( 'VIP, 3 stars or fewer', 'helpdesk-hero-pro' ), array( 'status' => 'all', 'tier' => 'vip', 'rating_max' => '3' ) ),
			) as $v
		) {
			if ( ! in_array( $v[0], $views, true ) ) {
				$saved = Helpdesk_Hero_Pro_Views::save(
					array(
						'id'      => $v[0],
						'name'    => $v[1],
						'filters' => $v[2],
						'sort'    => array(
							'by'    => 'sla-overdue' === $v[0] ? 'due' : 'updated',
							'order' => 'sla-overdue' === $v[0] ? 'asc' : 'desc',
						),
					),
					'shared'
				);
				if ( ! is_wp_error( $saved ) ) {
					$note( 'views', $saved['id'], $saved );
				}
			}
		}

		// Automations, switched off.
		$autos = Helpdesk_Hero_Pro_Automations::all();
		$have  = wp_list_pluck( $autos, 'id' );
		foreach (
			array(
				array( 'ex-low-rating', __( 'Follow up on low ratings', 'helpdesk-hero-pro' ), 'rated', 24, array( array( 'field' => 'rating', 'op' => 'lte', 'value' => '3' ) ), array( array( 'type' => 'add_tag', 'value' => 'follow-up' ), array( 'type' => 'add_note', 'value' => __( 'Low rating: please follow up with {customer_first_name}.', 'helpdesk-hero-pro' ) ), array( 'type' => 'email', 'value' => 'team' ) ) ),
				array( 'ex-round-robin', __( 'Share new tickets round-robin', 'helpdesk-hero-pro' ), 'ticket_created', 24, array(), array( array( 'type' => 'assign', 'value' => 'round_robin' ) ) ),
				array( 'ex-vip-urgent', __( 'VIP tickets are high priority', 'helpdesk-hero-pro' ), 'ticket_created', 24, array( array( 'field' => 'tier', 'op' => 'is', 'value' => 'vip' ) ), array( array( 'type' => 'set_priority', 'value' => 'high' ), array( 'type' => 'slack', 'value' => __( 'VIP ticket: {ticket_subject} ({site_name})', 'helpdesk-hero-pro' ) ) ) ),
				array( 'ex-close-waiting', __( 'Close tickets waiting 7 days', 'helpdesk-hero-pro' ), 'waiting_customer', 168, array(), array( array( 'type' => 'set_status', 'value' => 'closed' ) ) ),
			) as $x
		) {
			if ( ! in_array( $x[0], $have, true ) ) {
				$autos[] = array(
					'id'         => $x[0],
					'name'       => $x[1],
					'enabled'    => false,
					'trigger'    => $x[2],
					'hours'      => $x[3],
					'match'      => 'all',
					'conditions' => $x[4],
					'actions'    => $x[5],
				);
			}
		}
		foreach ( Helpdesk_Hero_Pro_Automations::save( $autos ) as $a ) {
			if ( 0 === strpos( $a['id'], 'ex-' ) && ! in_array( $a['id'], $have, true ) ) {
				$note( 'automations', $a['id'], $a );
			}
		}

		update_option( self::OPTION, $added, false );
		return $added;
	}

	/**
	 * Remove examples nobody changed.
	 *
	 * @return int Items removed.
	 */
	public static function remove() {
		$added   = self::added();
		$removed = 0;
		$keep    = static function ( $kind, $item, $id ) use ( &$added, &$removed ) {
			if ( isset( $added[ $kind ][ $id ] ) && self::fingerprint( $item ) === $added[ $kind ][ $id ] ) {
				++$removed;
				return false;
			}
			return true;
		};

		$tiers = array_filter( Helpdesk_Hero_Hub_Tiers::all(), static fn( $t ) => $keep( 'tiers', $t, $t['id'] ) );
		Helpdesk_Hero_Hub_Tiers::save( array_values( $tiers ) );

		$sla             = Helpdesk_Hero_Pro_SLA::settings();
		$sla['policies'] = array_values( array_filter( $sla['policies'], static fn( $p ) => $keep( 'sla', $p, $p['id'] ) ) );
		Helpdesk_Hero_Pro_SLA::save( $sla );

		$tags = array_filter( Helpdesk_Hero_Hub_Tags::all(), static fn( $t ) => $keep( 'tags', array( 'id' => $t['id'], 'name' => $t['name'], 'color' => $t['color'] ), $t['id'] ) );
		Helpdesk_Hero_Hub_Tags::save( array_values( $tags ) );

		$policy                          = Helpdesk_Hero_Hub_Policy::team();
		$policy['tickets']['categories'] = array_values( array_filter( (array) $policy['tickets']['categories'], static fn( $c ) => $keep( 'categories', $c, $c ) ) );
		Helpdesk_Hero_Hub_Policy::save_team( $policy );

		Helpdesk_Hero_Pro_Statuses::save( array_values( array_filter( Helpdesk_Hero_Pro_Statuses::all(), static fn( $s ) => $keep( 'statuses', $s, $s['id'] ) ) ) );

		foreach ( Helpdesk_Hero_Pro_Views::shared() as $v ) {
			if ( ! $keep( 'views', $v, $v['id'] ) ) {
				Helpdesk_Hero_Pro_Views::delete( $v['id'], 'shared' );
			}
		}

		Helpdesk_Hero_Pro_Automations::save( array_values( array_filter( Helpdesk_Hero_Pro_Automations::all(), static fn( $a ) => $keep( 'automations', $a, $a['id'] ) ) ) );

		delete_option( self::OPTION );
		return $removed;
	}
}
