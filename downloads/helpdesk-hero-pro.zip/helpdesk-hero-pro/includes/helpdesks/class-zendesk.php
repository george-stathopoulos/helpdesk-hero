<?php
/**
 * Zendesk connector (Support API v2).
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Uses an API token: Zendesk Admin Center › Apps and integrations › Zendesk API.
 */
final class Helpdesk_Hero_Pro_Zendesk extends Helpdesk_Hero_Hub_Helpdesk {

	/**
	 * Key.
	 *
	 * @return string
	 */
	public function key() {
		return 'zendesk';
	}

	/**
	 * Label.
	 *
	 * @return string
	 */
	public function label() {
		return 'Zendesk';
	}

	/**
	 * Configured.
	 *
	 * @return bool
	 */
	public function configured() {
		return '' !== self::subdomain() && is_email( Helpdesk_Hero_Pro_Helpdesks::get( 'zendesk_email' ) ) && '' !== (string) Helpdesk_Hero_Pro_Helpdesks::secret( 'zendesk_token' );
	}

	/**
	 * Subdomain (letters, digits and dashes only).
	 *
	 * @return string
	 */
	private static function subdomain() {
		return preg_replace( '/[^a-z0-9\-]/', '', strtolower( (string) Helpdesk_Hero_Pro_Helpdesks::get( 'zendesk_subdomain' ) ) );
	}

	/**
	 * Authenticated request.
	 *
	 * @param string $method Method.
	 * @param string $path   Path under /api/v2/.
	 * @param mixed  $body   Body.
	 * @param array  $extra  Extra headers.
	 * @return array|WP_Error
	 */
	private function api( $method, $path, $body = null, array $extra = array() ) {
		$auth = base64_encode( Helpdesk_Hero_Pro_Helpdesks::get( 'zendesk_email' ) . '/token:' . Helpdesk_Hero_Pro_Helpdesks::secret( 'zendesk_token' ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic authentication.
		return self::http( $method, 'https://' . self::subdomain() . '.zendesk.com/api/v2/' . ltrim( $path, '/' ), array_merge( array( 'Authorization' => 'Basic ' . $auth ), $extra ), $body );
	}

	/**
	 * Test.
	 *
	 * @return string|WP_Error
	 */
	public function test() {
		$me = $this->api( 'GET', 'users/me.json' );
		if ( is_wp_error( $me ) ) {
			return $me;
		}
		if ( empty( $me['data']['user']['id'] ) || in_array( $me['data']['user']['role'] ?? '', array( 'end-user', '' ), true ) ) {
			return new WP_Error( 'helpdesk_hero_zendesk_auth', __( 'Zendesk did not accept the email and API token, or the user is not an agent.', 'helpdesk-hero-pro' ) );
		}
		/* translators: 1: user name, 2: subdomain */
		return sprintf( __( 'Connected to Zendesk as %1$s (%2$s.zendesk.com).', 'helpdesk-hero-pro' ), $me['data']['user']['name'], self::subdomain() );
	}

	/**
	 * Create a ticket.
	 *
	 * @param array $t Ticket.
	 * @return array|WP_Error
	 */
	public function create_ticket( array $t ) {
		$uploads = array();
		if ( ! empty( $t['attachment'] ) ) {
			$upload = $this->api( 'POST', 'uploads.json?filename=' . rawurlencode( $t['attachment']['name'] ), $t['attachment']['content'], array( 'Content-Type' => 'text/plain' ) );
			if ( ! is_wp_error( $upload ) && ! empty( $upload['data']['upload']['token'] ) ) {
				$uploads[] = $upload['data']['upload']['token'];
			}
		}
		$result = $this->api(
			'POST',
			'tickets.json',
			array(
				'ticket' => array(
					'subject'   => $t['subject'],
					'comment'   => array(
						'body'    => $t['body'],
						'uploads' => $uploads,
					),
					'requester' => array(
						'name'  => '' !== $t['name'] ? $t['name'] : $t['email'],
						'email' => $t['email'],
					),
					'priority'  => $t['priority'],
					'tags'      => array_values( (array) ( $t['tags'] ?? array() ) ),
				),
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$id = (string) ( $result['data']['ticket']['id'] ?? '' );
		if ( '' === $id ) {
			return new WP_Error( 'helpdesk_hero_zendesk', __( 'Zendesk did not return a ticket ID.', 'helpdesk-hero-pro' ) );
		}
		if ( ! empty( $t['note'] ) ) {
			$this->note( array( 'helpdesk_id' => $id ), $t['note'] );
		}
		return array(
			'id'         => $id,
			'number'     => $id,
			'thread_ids' => array(),
		);
	}

	/**
	 * Add a comment.
	 *
	 * @param string   $id        Ticket ID.
	 * @param string   $body      Text.
	 * @param bool     $is_public Public.
	 * @param int|null $author    Author user ID.
	 * @param string   $status    New status, or ''.
	 * @return string|WP_Error Comment ID (or '' if unknown).
	 */
	private function comment( $id, $body, $is_public, $author = null, $status = '' ) {
		$ticket = array(
			'comment' => array_filter(
				array(
					'body'      => $body,
					'public'    => (bool) $is_public,
					'author_id' => $author,
				),
				static function ( $v ) {
					return null !== $v;
				}
			),
		);
		if ( $status ) {
			$ticket['status'] = $status;
		}
		$result = $this->api( 'PUT', 'tickets/' . rawurlencode( $id ) . '.json', array( 'ticket' => $ticket ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return (string) ( $result['data']['audit']['events'][0]['id'] ?? '' );
	}

	/**
	 * Latest comment ID (to mark our own comments as seen).
	 *
	 * @param string $id Ticket ID.
	 * @return string
	 */
	private function last_comment_id( $id ) {
		$list = $this->api( 'GET', 'tickets/' . rawurlencode( $id ) . '/comments.json?sort_order=desc&per_page=1' );
		return is_wp_error( $list ) ? '' : (string) ( $list['data']['comments'][0]['id'] ?? '' );
	}

	/**
	 * Requester ID of a ticket.
	 *
	 * @param string $id Ticket ID.
	 * @return int|null
	 */
	private function requester( $id ) {
		$t = $this->api( 'GET', 'tickets/' . rawurlencode( $id ) . '.json' );
		return is_wp_error( $t ) ? null : (int) ( $t['data']['ticket']['requester_id'] ?? 0 );
	}

	/**
	 * Customer reply.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $body   Text.
	 * @return string|WP_Error
	 */
	public function customer_reply( array $ticket, $body ) {
		$result = $this->comment( $ticket['helpdesk_id'], $body, true, $this->requester( $ticket['helpdesk_id'] ), 'open' );
		return is_wp_error( $result ) ? $result : $this->last_comment_id( $ticket['helpdesk_id'] );
	}

	/**
	 * Agent reply.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $body   Text.
	 * @return string|WP_Error
	 */
	public function agent_reply( array $ticket, $body ) {
		$result = $this->comment( $ticket['helpdesk_id'], $body, true, null, 'pending' );
		return is_wp_error( $result ) ? $result : $this->last_comment_id( $ticket['helpdesk_id'] );
	}

	/**
	 * Internal note.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $body   Text.
	 * @return string|WP_Error
	 */
	public function note( array $ticket, $body ) {
		$result = $this->comment( $ticket['helpdesk_id'], $body, false );
		return is_wp_error( $result ) ? $result : $this->last_comment_id( $ticket['helpdesk_id'] );
	}

	/**
	 * Status.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $status Status.
	 * @return true|WP_Error
	 */
	public function set_status( array $ticket, $status ) {
		$map    = array(
			'open'    => 'open',
			'pending' => 'pending',
			'closed'  => 'solved',
		);
		$result = $this->api( 'PUT', 'tickets/' . rawurlencode( $ticket['helpdesk_id'] ) . '.json', array( 'ticket' => array( 'status' => $map[ $status ] ?? 'open' ) ) );
		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * Status and comments.
	 *
	 * @param array $ticket Ticket.
	 * @return array|WP_Error
	 */
	public function fetch( array $ticket ) {
		$t = $this->api( 'GET', 'tickets/' . rawurlencode( $ticket['helpdesk_id'] ) . '.json' );
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		$requester = (int) ( $t['data']['ticket']['requester_id'] ?? 0 );
		$list      = $this->api( 'GET', 'tickets/' . rawurlencode( $ticket['helpdesk_id'] ) . '/comments.json?include=users' );
		if ( is_wp_error( $list ) ) {
			return $list;
		}
		$users = array();
		foreach ( (array) ( $list['data']['users'] ?? array() ) as $u ) {
			$users[ (int) $u['id'] ] = (string) $u['name'];
		}
		$threads = array();
		foreach ( (array) ( $list['data']['comments'] ?? array() ) as $c ) {
			$author    = (int) ( $c['author_id'] ?? 0 );
			$threads[] = array(
				'id'         => (string) $c['id'],
				'type'       => $author === $requester ? 'customer' : ( empty( $c['public'] ) ? 'note' : 'agent' ),
				'public'     => ! empty( $c['public'] ),
				'author'     => $users[ $author ] ?? '',
				'body'       => (string) ( $c['plain_body'] ?? $c['body'] ?? '' ),
				'created_at' => (string) ( $c['created_at'] ?? '' ),
			);
		}
		$status_map = array(
			'new'     => 'open',
			'open'    => 'open',
			'hold'    => 'open',
			'pending' => 'pending',
			'solved'  => 'closed',
			'closed'  => 'closed',
		);
		return array(
			'status'  => $status_map[ $t['data']['ticket']['status'] ?? '' ] ?? '',
			'threads' => $threads,
		);
	}

	/**
	 * URL.
	 *
	 * @param array $ticket Ticket.
	 * @return string
	 */
	public function url( array $ticket ) {
		return 'https://' . self::subdomain() . '.zendesk.com/agent/tickets/' . rawurlencode( $ticket['helpdesk_id'] );
	}
}
