<?php
/**
 * Help Scout connector (Mailbox API 2.0).
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Uses a Help Scout "My App" (client credentials). Create one in Help Scout under
 * Your Profile › My Apps, then enter its App ID and App Secret on the hub.
 */
final class Helpdesk_Hero_Pro_HelpScout extends Helpdesk_Hero_Hub_Helpdesk {

	const API   = 'https://api.helpscout.net/v2/';
	const TOKEN = 'helpdesk_hero_pro_helpscout_token';

	/**
	 * Key.
	 *
	 * @return string
	 */
	public function key() {
		return 'helpscout';
	}

	/**
	 * Label.
	 *
	 * @return string
	 */
	public function label() {
		return 'Help Scout';
	}

	/**
	 * Configured.
	 *
	 * @return bool
	 */
	public function configured() {
		return '' !== (string) Helpdesk_Hero_Pro_Helpdesks::get( 'helpscout_app_id' ) && '' !== (string) Helpdesk_Hero_Pro_Helpdesks::secret( 'helpscout_app_secret' );
	}

	/**
	 * Access token (cached until shortly before it expires).
	 *
	 * @param bool $fresh Ignore the cache.
	 * @return string|WP_Error
	 */
	private function token( $fresh = false ) {
		$cached = $fresh ? false : get_transient( self::TOKEN );
		if ( $cached ) {
			return $cached;
		}
		$response = wp_remote_post(
			self::API . 'oauth2/token',
			array(
				'timeout' => 20,
				'body'    => array(
					'grant_type'    => 'client_credentials',
					'client_id'     => Helpdesk_Hero_Pro_Helpdesks::get( 'helpscout_app_id' ),
					'client_secret' => Helpdesk_Hero_Pro_Helpdesks::secret( 'helpscout_app_secret' ),
				),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['access_token'] ) ) {
			return new WP_Error( 'helpdesk_hero_helpscout_auth', __( 'Help Scout did not accept the App ID and App Secret.', 'helpdesk-hero-pro' ) );
		}
		set_transient( self::TOKEN, $data['access_token'], max( 60, (int) ( $data['expires_in'] ?? 7200 ) - 300 ) );
		return $data['access_token'];
	}

	/**
	 * Authenticated request.
	 *
	 * @param string $method Method.
	 * @param string $path   Path under /v2/.
	 * @param mixed  $body   Body.
	 * @return array|WP_Error
	 */
	private function api( $method, $path, $body = null ) {
		$token = $this->token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		$result = self::http( $method, self::API . ltrim( $path, '/' ), array( 'Authorization' => 'Bearer ' . $token ), $body );
		if ( is_wp_error( $result ) && false !== strpos( $result->get_error_message(), ' 401' ) ) {
			delete_transient( self::TOKEN );
		}
		return $result;
	}

	/**
	 * Mailboxes (for the settings screen).
	 *
	 * @return array|WP_Error ID => name.
	 */
	public function mailboxes() {
		$result = $this->api( 'GET', 'mailboxes' );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$out = array();
		foreach ( (array) ( $result['data']['_embedded']['mailboxes'] ?? array() ) as $box ) {
			$out[ (int) $box['id'] ] = (string) $box['name'];
		}
		return $out;
	}

	/**
	 * Test.
	 *
	 * @return string|WP_Error
	 */
	public function test() {
		delete_transient( self::TOKEN );
		$boxes = $this->mailboxes();
		if ( is_wp_error( $boxes ) ) {
			return $boxes;
		}
		$id = (int) Helpdesk_Hero_Pro_Helpdesks::get( 'helpscout_mailbox' );
		if ( ! $id || ! isset( $boxes[ $id ] ) ) {
			/* translators: %s: list of mailboxes */
			return new WP_Error( 'helpdesk_hero_helpscout_mailbox', sprintf( __( 'Connected, but choose a mailbox. Available: %s', 'helpdesk-hero-pro' ), implode( ', ', array_map( static function ( $name, $box_id ) { return $name . ' (' . $box_id . ')'; }, $boxes, array_keys( $boxes ) ) ) ) );
		}
		/* translators: %s: mailbox */
		return sprintf( __( 'Connected to Help Scout mailbox “%s”.', 'helpdesk-hero-pro' ), $boxes[ $id ] );
	}

	/**
	 * Split a full name.
	 *
	 * @param string $name Name.
	 * @return array
	 */
	private static function names( $name ) {
		$parts = preg_split( '/\s+/', trim( (string) $name ), 2 );
		return array_filter(
			array(
				'firstName' => substr( $parts[0] ?? '', 0, 40 ),
				'lastName'  => substr( $parts[1] ?? '', 0, 40 ),
			)
		);
	}

	/**
	 * Create a conversation.
	 *
	 * @param array $t Ticket.
	 * @return array|WP_Error
	 */
	public function create_ticket( array $t ) {
		$customer = array_merge( array( 'email' => $t['email'] ), self::names( $t['name'] ) );
		$thread   = array(
			'type'     => 'customer',
			'customer' => array( 'email' => $t['email'] ),
			'text'     => self::to_html( $t['body'] ),
		);
		if ( ! empty( $t['attachment'] ) ) {
			$thread['attachments'] = array(
				array(
					'fileName' => $t['attachment']['name'],
					'mimeType' => 'text/plain',
					'data'     => base64_encode( $t['attachment']['content'] ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Help Scout requires base64 attachment data.
				),
			);
		}
		$tags = (array) ( $t['tags'] ?? array() );
		if ( in_array( $t['priority'], array( 'high', 'urgent' ), true ) ) {
			$tags[] = 'priority-' . $t['priority'];
		}
		$result = $this->api(
			'POST',
			'conversations',
			array(
				'subject'   => $t['subject'],
				'customer'  => $customer,
				'mailboxId' => (int) Helpdesk_Hero_Pro_Helpdesks::get( 'helpscout_mailbox' ),
				'type'      => 'email',
				'status'    => 'active',
				'tags'      => array_values( array_unique( $tags ) ),
				'threads'   => array( $thread ),
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$id = (string) ( $result['headers']['resource-id'] ?? '' );
		if ( '' === $id ) {
			return new WP_Error( 'helpdesk_hero_helpscout', __( 'Help Scout did not return a conversation ID.', 'helpdesk-hero-pro' ) );
		}
		$number = '';
		$conv   = $this->api( 'GET', 'conversations/' . rawurlencode( $id ) );
		if ( ! is_wp_error( $conv ) ) {
			$number = (string) ( $conv['data']['number'] ?? '' );
		}
		$note_id = '';
		if ( ! empty( $t['note'] ) ) {
			$note = $this->api( 'POST', 'conversations/' . rawurlencode( $id ) . '/notes', array( 'text' => self::to_html( $t['note'] ) ) );
			if ( ! is_wp_error( $note ) ) {
				$note_id = (string) ( $note['headers']['resource-id'] ?? '' );
			}
		}
		return array(
			'id'         => $id,
			'number'     => $number,
			'thread_ids' => array_filter( array( $note_id ) ),
		);
	}

	/**
	 * Customer reply.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $body   Text.
	 * @return string|WP_Error
	 */
	public function customer_reply( array $ticket, $body ) {
		$result = $this->api(
			'POST',
			'conversations/' . rawurlencode( $ticket['helpdesk_id'] ) . '/customer',
			array(
				'customer' => array( 'email' => $ticket['customer_email'] ),
				'text'     => self::to_html( $body ),
			)
		);
		return is_wp_error( $result ) ? $result : (string) ( $result['headers']['resource-id'] ?? '' );
	}

	/**
	 * Agent reply.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $body   Text.
	 * @return string|WP_Error
	 */
	public function agent_reply( array $ticket, $body ) {
		$result = $this->api(
			'POST',
			'conversations/' . rawurlencode( $ticket['helpdesk_id'] ) . '/reply',
			array(
				'customer' => array( 'email' => $ticket['customer_email'] ),
				'text'     => self::to_html( $body ),
			)
		);
		return is_wp_error( $result ) ? $result : (string) ( $result['headers']['resource-id'] ?? '' );
	}

	/**
	 * Internal note.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $body   Text.
	 * @return string|WP_Error
	 */
	public function note( array $ticket, $body ) {
		$result = $this->api( 'POST', 'conversations/' . rawurlencode( $ticket['helpdesk_id'] ) . '/notes', array( 'text' => self::to_html( $body ) ) );
		return is_wp_error( $result ) ? $result : (string) ( $result['headers']['resource-id'] ?? '' );
	}

	/**
	 * Status.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $status Status.
	 * @return true|WP_Error
	 */
	public function set_status( array $ticket, $status ) {
		$map    = array(
			'open'    => 'active',
			'pending' => 'pending',
			'closed'  => 'closed',
		);
		$result = $this->api(
			'PATCH',
			'conversations/' . rawurlencode( $ticket['helpdesk_id'] ),
			array(
				'op'    => 'replace',
				'path'  => '/status',
				'value' => $map[ $status ] ?? 'active',
			)
		);
		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * Status and threads.
	 *
	 * @param array $ticket Ticket.
	 * @return array|WP_Error
	 */
	public function fetch( array $ticket ) {
		$conv = $this->api( 'GET', 'conversations/' . rawurlencode( $ticket['helpdesk_id'] ) . '?embed=threads' );
		if ( is_wp_error( $conv ) ) {
			return $conv;
		}
		$status_map = array(
			'active'  => 'open',
			'pending' => 'pending',
			'closed'  => 'closed',
			'spam'    => 'closed',
		);
		$threads    = array();
		foreach ( (array) ( $conv['data']['_embedded']['threads'] ?? array() ) as $th ) {
			$type = (string) ( $th['type'] ?? '' );
			if ( ! in_array( $type, array( 'reply', 'customer', 'note', 'message' ), true ) ) {
				continue;
			}
			$by        = (array) ( $th['createdBy'] ?? array() );
			$threads[] = array(
				'id'         => (string) $th['id'],
				'type'       => 'customer' === $type ? 'customer' : ( 'note' === $type ? 'note' : 'agent' ),
				'public'     => in_array( $type, array( 'reply', 'message', 'customer' ), true ),
				'author'     => trim( ( $by['first'] ?? '' ) . ' ' . ( $by['last'] ?? '' ) ),
				'body'       => self::to_text( (string) ( $th['body'] ?? '' ) ),
				'created_at' => (string) ( $th['createdAt'] ?? '' ),
			);
		}
		return array(
			'status'  => $status_map[ $conv['data']['status'] ?? '' ] ?? '',
			'threads' => $threads,
		);
	}

	/**
	 * URL.
	 *
	 * @param array $ticket Ticket.
	 * @return string
	 */
	public function url( array $ticket ) {
		return 'https://secure.helpscout.net/conversation/' . rawurlencode( $ticket['helpdesk_id'] ) . ( $ticket['helpdesk_number'] ? '/' . rawurlencode( $ticket['helpdesk_number'] ) : '' );
	}
}
