<?php
/**
 * Branding, broadcast messages, the Support Agent role and named supporters.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Team features for the hub.
 */
final class Helpdesk_Hero_Pro_Team {

	const ROLE       = 'helpdesk_hero_agent';
	const CAP        = 'helpdesk_hero_hub_access';
	const SUPPORTERS = 'helpdesk_hero_pro_supporters';

	/**
	 * Register hooks (licensed hubs only).
	 */
	public static function init() {
		add_filter( 'helpdesk_hero_hub_branding', array( __CLASS__, 'branding' ) );
		add_filter( 'helpdesk_hero_hub_capability', array( __CLASS__, 'capability' ) );
		add_filter( 'helpdesk_hero_hub_can_support', array( __CLASS__, 'can_support' ), 10, 2 );
		add_filter( 'helpdesk_hero_hub_supporter', array( __CLASS__, 'supporter' ), 10, 2 );
	}

	/**
	 * Named supporters: the hub users who reply to customers and log in to their sites, with the
	 * name customers see. Empty means everyone with hub access can support, under their own name.
	 *
	 * @return array[] { user_id, name }
	 */
	public static function supporters() {
		$list = get_option( self::SUPPORTERS, array() );
		$out  = array();
		foreach ( is_array( $list ) ? $list : array() as $row ) {
			$user = get_userdata( (int) ( $row['user_id'] ?? 0 ) );
			if ( $user && user_can( $user, self::hub_cap() ) ) {
				$out[ $user->ID ] = array(
					'user_id' => $user->ID,
					'name'    => '' !== (string) ( $row['name'] ?? '' ) ? (string) $row['name'] : $user->display_name,
				);
			}
		}
		return $out;
	}

	/**
	 * Save the supporters.
	 *
	 * @param array $rows { user_id, name }.
	 * @return array[] Saved.
	 */
	public static function save_supporters( array $rows ) {
		$clean = array();
		foreach ( $rows as $row ) {
			$user = get_userdata( (int) ( $row['user_id'] ?? 0 ) );
			if ( ! $user || ! user_can( $user, self::hub_cap() ) ) {
				continue;
			}
			$name                 = trim( sanitize_text_field( (string) ( $row['name'] ?? '' ) ) );
			$clean[ $user->ID ] = array(
				'user_id' => $user->ID,
				'name'    => substr( '' !== $name ? $name : $user->display_name, 0, 60 ),
			);
		}
		update_option( self::SUPPORTERS, array_values( $clean ), false );
		return self::supporters();
	}

	/**
	 * Hub users who could be supporters (everyone with hub access).
	 *
	 * @return array[] { user_id, name, email, role }
	 */
	public static function candidates() {
		$out = array();
		foreach ( get_users( array( 'role__in' => array( 'administrator', self::ROLE ), 'orderby' => 'display_name' ) ) as $user ) {
			if ( ! user_can( $user, self::hub_cap() ) ) {
				continue;
			}
			$out[] = array(
				'user_id' => $user->ID,
				'name'    => $user->display_name,
				'email'   => $user->user_email,
				'role'    => in_array( self::ROLE, (array) $user->roles, true ) ? __( 'Support Agent', 'helpdesk-hero-pro' ) : __( 'Administrator', 'helpdesk-hero-pro' ),
			);
		}
		return $out;
	}

	/**
	 * The capability that gives hub access (filtered by this class).
	 *
	 * @return string
	 */
	private static function hub_cap() {
		return self::CAP;
	}

	/**
	 * With named supporters, only they may act for the team.
	 *
	 * @param bool $can     Can support.
	 * @param int  $user_id User.
	 * @return bool
	 */
	public static function can_support( $can, $user_id ) {
		$list = self::supporters();
		return $list ? $can && isset( $list[ (int) $user_id ] ) : $can;
	}

	/**
	 * A named supporter's identity for customer sites.
	 *
	 * @param array|null $supporter Supporter.
	 * @param int        $user_id   User.
	 * @return array|null
	 */
	public static function supporter( $supporter, $user_id ) {
		$list = self::supporters();
		if ( ! isset( $list[ (int) $user_id ] ) ) {
			return $supporter;
		}
		return array(
			'id'   => 'u' . (int) $user_id,
			'name' => $list[ (int) $user_id ]['name'],
		);
	}

	/**
	 * Support Agent role, and the hub capability for administrators.
	 */
	public static function add_role() {
		if ( ! get_role( self::ROLE ) ) {
			add_role(
				self::ROLE,
				__( 'Support Agent', 'helpdesk-hero-pro' ),
				array(
					'read'    => true,
					self::CAP => true,
				)
			);
		}
		$admin = get_role( 'administrator' );
		if ( $admin && ! $admin->has_cap( self::CAP ) ) {
			$admin->add_cap( self::CAP );
		}
	}

	/**
	 * Remove the role (users keep their accounts).
	 */
	public static function remove_role() {
		remove_role( self::ROLE );
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->remove_cap( self::CAP );
		}
	}

	/**
	 * Hub access via the agent capability.
	 *
	 * @return string
	 */
	public static function capability() {
		return self::CAP;
	}

	/**
	 * Branding sent to sites.
	 *
	 * @param array $branding Branding.
	 * @return array
	 */
	public static function branding( $branding ) {
		$s = Helpdesk_Hero_Pro_Plugin::settings();
		return array_filter(
			array_merge(
				$branding,
				array(
					'center'  => $s['brand_name'],
					'logo'    => $s['brand_logo'],
					'color'   => $s['brand_color'],
					'intro'   => $s['brand_intro'],
					'url'     => $s['brand_url'],
					'contact' => $s['brand_contact'],
				)
			)
		);
	}

	/**
	 * Active site IDs.
	 *
	 * @return int[]
	 */
	public static function active_sites() {
		$ids = array();
		foreach ( Helpdesk_Hero_Hub::sites() as $site ) {
			if ( 'active' === $site['status'] ) {
				$ids[] = (int) $site['id'];
			}
		}
		return $ids;
	}

	/**
	 * Send the branding (with each site's policy) to every site.
	 *
	 * @return int Sites.
	 */
	public static function broadcast_branding() {
		$sites = self::active_sites();
		foreach ( $sites as $site_id ) {
			Helpdesk_Hero_Hub_Policy::push( $site_id );
		}
		return count( $sites );
	}

	/**
	 * Dashboard message to every connected site.
	 *
	 * @param array $payload Notice.
	 * @return int Sites.
	 */
	public static function broadcast( array $payload ) {
		$sites = self::active_sites();
		foreach ( $sites as $site_id ) {
			Helpdesk_Hero_Hub::enqueue( $site_id, 0, 'notice', $payload );
		}
		return count( $sites );
	}
}
