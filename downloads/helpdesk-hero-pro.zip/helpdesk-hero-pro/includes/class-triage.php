<?php
/**
 * AI triage briefs and reply drafts.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Uses the hub site's own AI provider (WordPress AI Client) to read a ticket with its
 * diagnostics and write a brief for the agent: summary, likely cause, suspects ranked by
 * evidence, first steps and a suggested priority. Briefs are written in the background so
 * customers never wait for AI when they send a ticket.
 */
final class Helpdesk_Hero_Pro_Triage {

	const CRON = 'helpdesk_hero_pro_triage';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'helpdesk_hero_hub_ticket_created', array( __CLASS__, 'queue' ) );
		add_action( self::CRON, array( __CLASS__, 'run' ) );
		add_filter( 'helpdesk_hero_hub_describe_event', array( __CLASS__, 'describe' ), 10, 2 );
	}

	/**
	 * Queue a brief for a new ticket.
	 *
	 * @param array $ticket Hub ticket.
	 */
	public static function queue( $ticket ) {
		// With the local WebLLM provider, the model runs in a browser: briefs are written when
		// someone opens the ticket instead of in the background.
		if ( Helpdesk_Hero_Pro_Plugin::settings()['auto_triage'] && Helpdesk_Hero_Hub_AI::available() && ! Helpdesk_Hero_Hub_AI::needs_browser() ) {
			wp_schedule_single_event( time(), self::CRON, array( (int) $ticket['id'] ) );
		}
	}

	/**
	 * Cron: write the brief and add it to the help desk.
	 *
	 * @param int $ticket_id Ticket.
	 */
	public static function run( $ticket_id ) {
		$ticket = Helpdesk_Hero_Hub::ticket( (int) $ticket_id );
		if ( ! $ticket || self::brief( $ticket ) || Helpdesk_Hero_Hub_AI::needs_browser() ) {
			return;
		}
		$brief = self::generate( $ticket );
		if ( is_wp_error( $brief ) ) {
			return;
		}
		if ( Helpdesk_Hero_Pro_Plugin::settings()['triage_note'] ) {
			$helpdesk = Helpdesk_Hero_Hub_Helpdesk::for_ticket( $ticket );
			if ( $helpdesk ) {
				$helpdesk->note( $ticket, self::as_text( $brief ) );
			}
		}
	}

	/**
	 * Ticket context for prompts (diagnostics are already redacted).
	 *
	 * @param array $ticket Ticket.
	 * @return string
	 */
	private static function context( array $ticket ) {
		$d     = $ticket['diagnostics'];
		$lines = array( 'Subject: ' . $ticket['subject'], 'Priority given by customer: ' . $ticket['priority'], '', 'Customer message:', $ticket['description'], '' );
		$lines[] = 'Health flags:';
		$lines[] = Helpdesk_Hero_Hub_AI::flags_text( $ticket['flags'] );
		if ( ! empty( $d['environment'] ) ) {
			$e       = $d['environment'];
			$lines[] = '';
			$lines[] = sprintf( 'Environment: WordPress %s, PHP %s, %s, memory %s, object cache %s, multisite %s', $e['wordpress'] ?? '?', $e['php'] ?? '?', $e['server'] ?? '?', $e['memory_limit'] ?? '?', ! empty( $e['object_cache'] ) ? 'yes' : 'no', ! empty( $e['multisite'] ) ? 'yes' : 'no' );
		}
		if ( ! empty( $d['extensions']['active_plugins'] ) ) {
			$lines[] = 'Active plugins: ' . implode( ', ', array_map( static function ( $p ) { return $p['name'] . ' ' . $p['version'] . ( ! empty( $p['update'] ) ? ' (update ' . $p['update'] . ')' : '' ); }, $d['extensions']['active_plugins'] ) );
			$lines[] = 'Theme: ' . ( $d['extensions']['theme']['name'] ?? '?' ) . ' ' . ( $d['extensions']['theme']['version'] ?? '' );
		}
		if ( ! empty( $d['errors'] ) ) {
			$lines[] = 'Recent errors:';
			foreach ( array_slice( $d['errors'], 0, 15 ) as $err ) {
				$lines[] = '- ' . $err['time'] . ' ' . $err['kind'] . ' in ' . $err['component'] . ': ' . $err['message'] . ( $err['file'] ? ' (' . $err['file'] . ')' : '' );
			}
		}
		if ( ! empty( $d['changes'] ) ) {
			$lines[] = 'Recent changes:';
			foreach ( array_slice( $d['changes'], 0, 20 ) as $c ) {
				$lines[] = '- ' . $c['time'] . ' ' . $c['event'];
			}
		}
		if ( ! empty( $d['debug_log']['lines'] ) ) {
			$lines[] = 'debug.log tail:';
			$lines   = array_merge( $lines, array_slice( $d['debug_log']['lines'], -25 ) );
		}
		return substr( implode( "\n", $lines ), 0, 24000 );
	}

	/**
	 * Generate and store a brief.
	 *
	 * @param array $ticket Ticket.
	 * @return array|WP_Error
	 */
	public static function generate( array $ticket ) {
		$system = 'You are a senior WordPress support engineer triaging a ticket for a colleague. Use only the evidence given. Be specific: name plugins, versions, files and timestamps. If the evidence is thin, say so and list what to ask the customer.';
		$prompt = self::context( $ticket ) . "\n\nReturn JSON: {\"summary\": string (1-2 sentences), \"likely_cause\": string, \"confidence\": \"low\"|\"medium\"|\"high\", \"suspects\": [{\"name\": string, \"reason\": string}] (max 3), \"first_steps\": string[] (max 4, concrete), \"ask_customer\": string[] (max 3), \"priority\": \"low\"|\"normal\"|\"high\"|\"urgent\"}";
		$data   = Helpdesk_Hero_Hub_AI::json( $prompt, $system );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$clean = static function ( $list ) {
			return array_slice( array_map( 'sanitize_text_field', array_filter( (array) $list, 'is_string' ) ), 0, 4 );
		};
		$brief = array(
			'summary'      => sanitize_text_field( (string) ( $data['summary'] ?? '' ) ),
			'likely_cause' => sanitize_text_field( (string) ( $data['likely_cause'] ?? '' ) ),
			'confidence'   => in_array( $data['confidence'] ?? '', array( 'low', 'medium', 'high' ), true ) ? $data['confidence'] : 'low',
			'suspects'     => array(),
			'first_steps'  => $clean( $data['first_steps'] ?? array() ),
			'ask_customer' => $clean( $data['ask_customer'] ?? array() ),
			'priority'     => in_array( $data['priority'] ?? '', array( 'low', 'normal', 'high', 'urgent' ), true ) ? $data['priority'] : $ticket['priority'],
			'created_at'   => gmdate( 'c' ),
		);
		foreach ( array_slice( (array) ( $data['suspects'] ?? array() ), 0, 3 ) as $s ) {
			if ( is_array( $s ) && ! empty( $s['name'] ) ) {
				$brief['suspects'][] = array(
					'name'   => sanitize_text_field( (string) $s['name'] ),
					'reason' => sanitize_text_field( (string) ( $s['reason'] ?? '' ) ),
				);
			}
		}
		Helpdesk_Hero_Hub::log( $ticket, 'ai_brief', $brief );
		return $brief;
	}

	/**
	 * Latest brief for a ticket.
	 *
	 * @param array $ticket Ticket.
	 * @return array|null
	 */
	public static function brief( array $ticket ) {
		$latest = null;
		foreach ( Helpdesk_Hero_Hub::history( (int) $ticket['id'] ) as $event ) {
			if ( 'ai_brief' === $event['type'] ) {
				$latest = $event['payload'];
			}
		}
		return $latest;
	}

	/**
	 * Brief as plain text (help desk note).
	 *
	 * @param array $b Brief.
	 * @return string
	 */
	public static function as_text( array $b ) {
		$out = array( 'AI triage (Helpdesk Hero Pro) — confidence: ' . $b['confidence'] . ', suggested priority: ' . $b['priority'], '', $b['summary'], '', 'Likely cause: ' . $b['likely_cause'] );
		if ( $b['suspects'] ) {
			$out[] = '';
			$out[] = 'Suspects:';
			foreach ( $b['suspects'] as $s ) {
				$out[] = '• ' . $s['name'] . ' — ' . $s['reason'];
			}
		}
		foreach ( array( 'first_steps' => 'First steps:', 'ask_customer' => 'Ask the customer:' ) as $key => $label ) {
			if ( $b[ $key ] ) {
				$out[] = '';
				$out[] = $label;
				foreach ( $b[ $key ] as $i => $line ) {
					$out[] = ( $i + 1 ) . '. ' . $line;
				}
			}
		}
		return implode( "\n", $out );
	}

	/**
	 * Draft the next reply to the customer.
	 *
	 * @param array  $ticket Ticket.
	 * @param string $hint   What the agent wants the reply to say (optional).
	 * @return string|WP_Error
	 */
	public static function draft( array $ticket, $hint = '' ) {
		$history = array();
		foreach ( Helpdesk_Hero_Hub::history( (int) $ticket['id'] ) as $event ) {
			if ( in_array( $event['type'], array( 'reply', 'customer_reply' ), true ) ) {
				$history[] = ( 'reply' === $event['type'] ? 'Support' : 'Customer' ) . ': ' . ( $event['payload']['body'] ?? '' );
			}
		}
		$brief  = self::brief( $ticket );
		$agent  = Helpdesk_Hero_Hub::agent_name();
		$system = 'You write replies from a WordPress support team to a customer. Be warm, brief and concrete. Plain text, no markdown headings. Never claim something was done unless the conversation says so. Give numbered steps when asking the customer to do something. Sign off with the agent\'s first name.';
		$prompt = self::context( $ticket ) . "\n\nConversation so far:\n" . ( $history ? implode( "\n\n", array_slice( $history, -8 ) ) : '(no replies yet)' ) . ( $brief ? "\n\nTriage brief:\n" . self::as_text( $brief ) : '' ) . "\n\nAgent name: {$agent}\nCustomer name: {$ticket['customer_name']}" . ( '' !== $hint ? "\nThe reply should: {$hint}" : '' ) . "\n\nWrite the next reply to the customer.";
		$draft  = Helpdesk_Hero_Hub_AI::text( $prompt, $system );
		return is_wp_error( $draft ) ? $draft : sanitize_textarea_field( $draft );
	}

	/**
	 * History line for briefs.
	 *
	 * @param string $text  Text.
	 * @param array  $event Event.
	 * @return string
	 */
	public static function describe( $text, $event ) {
		return 'ai_brief' === $event['type'] ? __( 'AI triage brief written', 'helpdesk-hero-pro' ) : $text;
	}
}
