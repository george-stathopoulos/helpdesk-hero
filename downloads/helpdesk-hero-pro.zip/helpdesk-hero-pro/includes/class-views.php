<?php
/**
 * Inbox views.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Saved Inbox filters and sort ("My tickets", "VIP with low ratings"…), shown as tabs above
 * the Inbox with live counts. Shared views are for the whole team (administrators manage
 * them); personal views belong to one person.
 */
final class Helpdesk_Hero_Pro_Views {

	const OPTION = 'helpdesk_hero_pro_views';
	const META   = 'helpdesk_hero_pro_views';

	/**
	 * Filter keys a view can hold.
	 *
	 * @return string[]
	 */
	public static function keys() {
		return array( 'status', 'custom_status', 'search', 'site', 'tier', 'service', 'priority', 'from', 'to', 'assignee', 'tag', 'rating_max', 'rating_min', 'access', 'unread', 'sla', 'category', 'bookmarked' );
	}

	/**
	 * Clean one view.
	 *
	 * @param array $v View.
	 * @return array|null
	 */
	private static function clean( array $v ) {
		$name = trim( sanitize_text_field( (string) ( $v['name'] ?? '' ) ) );
		if ( '' === $name ) {
			return null;
		}
		$filters = array();
		foreach ( self::keys() as $k ) {
			if ( isset( $v['filters'][ $k ] ) && '' !== (string) $v['filters'][ $k ] && is_scalar( $v['filters'][ $k ] ) ) {
				$filters[ $k ] = sanitize_text_field( (string) $v['filters'][ $k ] );
			}
		}
		$sort = (array) ( $v['sort'] ?? array() );
		$id   = sanitize_key( (string) ( $v['id'] ?? '' ) );
		$kind = 'report' === ( $v['kind'] ?? '' ) ? 'report' : 'inbox';
		return array(
			'id'      => '' !== $id ? $id : 'view-' . strtolower( wp_generate_password( 6, false ) ),
			'name'    => substr( $name, 0, 40 ),
			// Inbox views, or saved reports for the analytics explorer (with their grouping).
			'kind'    => $kind,
			'group'   => 'report' === $kind && isset( Helpdesk_Hero_Pro_Analytics::groups()[ $v['group'] ?? '' ] ) ? $v['group'] : '',
			'filters' => $filters,
			'sort'    => array(
				'by'    => in_array( $sort['by'] ?? '', Helpdesk_Hero_Hub::ticket_sorts(), true ) ? $sort['by'] : 'updated',
				'order' => 'asc' === ( $sort['order'] ?? '' ) ? 'asc' : 'desc',
			),
		);
	}

	/**
	 * Shared views.
	 *
	 * @return array[]
	 */
	public static function shared() {
		$list = get_option( self::OPTION, array() );
		return is_array( $list ) ? array_values( $list ) : array();
	}

	/**
	 * The current person's views.
	 *
	 * @return array[]
	 */
	public static function personal() {
		$list = get_user_meta( get_current_user_id(), self::META, true );
		return is_array( $list ) ? array_values( $list ) : array();
	}

	/**
	 * Save a view (new or changed).
	 *
	 * @param array  $view  View.
	 * @param string $scope shared | personal.
	 * @return array|WP_Error Saved view.
	 */
	public static function save( array $view, $scope ) {
		$clean = self::clean( $view );
		if ( ! $clean ) {
			return new WP_Error( 'helpdesk_hero_pro_view', __( 'Give the view a name.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
		}
		if ( 'shared' === $scope && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'helpdesk_hero_pro_view', __( 'Only administrators can change views shared with the team.', 'helpdesk-hero-pro' ), array( 'status' => 403 ) );
		}
		$list  = 'shared' === $scope ? self::shared() : self::personal();
		$found = false;
		foreach ( $list as &$v ) {
			if ( $v['id'] === $clean['id'] ) {
				$v     = $clean;
				$found = true;
			}
		}
		unset( $v );
		if ( ! $found ) {
			$list[] = $clean;
		}
		self::store( array_slice( $list, 0, 30 ), $scope );
		return $clean;
	}

	/**
	 * Delete a view.
	 *
	 * @param string $id    View.
	 * @param string $scope shared | personal.
	 * @return true|WP_Error
	 */
	public static function delete( $id, $scope ) {
		if ( 'shared' === $scope && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'helpdesk_hero_pro_view', __( 'Only administrators can change views shared with the team.', 'helpdesk-hero-pro' ), array( 'status' => 403 ) );
		}
		$list = array_values(
			array_filter(
				'shared' === $scope ? self::shared() : self::personal(),
				static function ( $v ) use ( $id ) {
					return $v['id'] !== $id;
				}
			)
		);
		self::store( $list, $scope );
		return true;
	}

	/**
	 * Store a list.
	 *
	 * @param array[] $list  Views.
	 * @param string  $scope shared | personal.
	 */
	private static function store( array $list, $scope ) {
		if ( 'shared' === $scope ) {
			update_option( self::OPTION, $list, false );
		} else {
			update_user_meta( get_current_user_id(), self::META, $list );
		}
	}

	/**
	 * Views with live counts.
	 *
	 * @return array { shared, personal } each [ { id, name, filters, sort, count } ]
	 */
	public static function with_counts() {
		$count = static function ( $v ) {
			$v['count'] = Helpdesk_Hero_Hub::count_tickets( Helpdesk_Hero_Hub_Admin_REST::inbox_args( $v['filters'] ) );
			return $v;
		};
		return array(
			'shared'   => array_map( $count, self::of_kind( self::shared(), 'inbox' ) ),
			'personal' => array_map( $count, self::of_kind( self::personal(), 'inbox' ) ),
		);
	}

	/**
	 * Saved reports for the analytics explorer.
	 *
	 * @return array { shared, personal }
	 */
	public static function reports() {
		return array(
			'shared'   => self::of_kind( self::shared(), 'report' ),
			'personal' => self::of_kind( self::personal(), 'report' ),
		);
	}

	/**
	 * Views of one kind (views saved before 2.1 are Inbox views).
	 *
	 * @param array[] $list Views.
	 * @param string  $kind inbox | report.
	 * @return array[]
	 */
	private static function of_kind( array $list, $kind ) {
		return array_values(
			array_filter(
				$list,
				static function ( $v ) use ( $kind ) {
					return ( $v['kind'] ?? 'inbox' ) === $kind;
				}
			)
		);
	}
}
