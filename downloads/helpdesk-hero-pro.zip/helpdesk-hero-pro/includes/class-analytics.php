<?php
/**
 * Advanced analytics and reviews.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Full analytics for any range, all sites or one site: ticket volume, categories, priorities,
 * tags, recurring issues, busiest sites, response and resolution times, and customer ratings.
 * Also switches on customer ratings ("reviews") in the support policy.
 */
final class Helpdesk_Hero_Pro_Analytics {

	/**
	 * Register hooks (licensed hubs only).
	 */
	public static function init() {
		add_filter( 'helpdesk_hero_hub_ratings_available', '__return_true' );
		add_action( 'helpdesk_hero_hub_ticket_rated', array( __CLASS__, 'note_rating' ), 10, 3 );
	}

	/**
	 * Add a customer's rating to the help desk as an internal note.
	 *
	 * @param array  $ticket  Ticket.
	 * @param int    $rating  Rating.
	 * @param string $comment Comment.
	 */
	public static function note_rating( $ticket, $rating, $comment ) {
		$helpdesk = Helpdesk_Hero_Hub_Helpdesk::for_ticket( $ticket );
		if ( $helpdesk ) {
			/* translators: 1: stars, 2: comment */
			$helpdesk->note( $ticket, sprintf( __( 'Customer rating: %1$s (%2$d/5)', 'helpdesk-hero-pro' ), str_repeat( '★', (int) $rating ) . str_repeat( '☆', 5 - (int) $rating ), (int) $rating ) . ( '' !== $comment ? "\n“" . $comment . '”' : '' ) );
		}
	}

	/**
	 * Analytics.
	 *
	 * @param int $days    Range in days (7–365).
	 * @param int $site_id Site (0 = all).
	 * @return array
	 */
	public static function report( $days, $site_id = 0 ) {
		$days  = max( 7, min( 365, (int) $days ) );
		$rows  = Helpdesk_Hero_Hub_Stats::rows( $days, $site_id );
		$sites = array();
		foreach ( Helpdesk_Hero_Hub::sites() as $s ) {
			$sites[ (int) $s['id'] ] = $s['name'] ? $s['name'] : $s['label'];
		}
		$tags = array_column( Helpdesk_Hero_Hub_Tags::all(), null, 'id' );

		$rated   = array_filter(
			$rows,
			static function ( $r ) {
				return (int) $r['rating'] > 0;
			}
		);
		$dist    = array_fill( 1, 5, 0 );
		foreach ( $rated as $r ) {
			++$dist[ (int) $r['rating'] ];
		}
		$average = $rated ? round( array_sum( array_column( $rated, 'rating' ) ) / count( $rated ), 2 ) : null;

		$priority_labels = array(
			'low'    => __( 'Low', 'helpdesk-hero-pro' ),
			'normal' => __( 'Normal', 'helpdesk-hero-pro' ),
			'high'   => __( 'High', 'helpdesk-hero-pro' ),
			'urgent' => __( 'Urgent', 'helpdesk-hero-pro' ),
		);

		return array(
			'days'        => $days,
			'site'        => $site_id ? array(
				'id'   => $site_id,
				'name' => $sites[ $site_id ] ?? '',
			) : null,
			'sites_list'  => array_map(
				static function ( $id, $name ) {
					return array(
						'id'   => $id,
						'name' => $name,
					);
				},
				array_keys( $sites ),
				$sites
			),
			'totals'      => array(
				'tickets'        => count( $rows ),
				'closed'         => count( array_filter( $rows, static function ( $r ) { return 'closed' === $r['status']; } ) ),
				'first_response' => Helpdesk_Hero_Hub_Stats::median_hours( $rows, 'first_response_at' ),
				'resolution'     => Helpdesk_Hero_Hub_Stats::median_hours( $rows, 'closed_at' ),
				'rating'         => $average,
				'ratings'        => count( $rated ),
			),
			'series'      => Helpdesk_Hero_Hub_Stats::series( $rows, $days ),
			'categories'  => Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) { return '' !== $r['category'] ? $r['category'] : __( 'No category', 'helpdesk-hero-pro' ); }, 8 ),
			'priorities'  => Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) use ( $priority_labels ) { return $priority_labels[ $r['priority'] ] ?? $r['priority']; }, 4 ),
			'tags'        => Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) use ( $tags ) { return array_map( static function ( $id ) use ( $tags ) { return $tags[ $id ]['name'] ?? ''; }, $r['tags'] ); }, 10 ),
			'channels'    => Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) { return 'email' === $r['channel'] ? __( 'Emailed by the customer', 'helpdesk-hero-pro' ) : __( 'Sent from the dashboard', 'helpdesk-hero-pro' ); }, 2 ),
			'issues'      => Helpdesk_Hero_Hub_Stats::recurring_issues( $rows, 10 ),
			'top_sites'   => $site_id ? array() : Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) use ( $sites ) { return $sites[ (int) $r['site_id'] ] ?? ''; }, 10 ),
			'ratings'     => array(
				'distribution' => array_values( $dist ),
				'recent'       => self::recent_reviews( $site_id ),
			),
			'tag_colors'  => array_column( Helpdesk_Hero_Hub_Tags::all(), 'color', 'name' ),
			'generated'   => gmdate( 'c' ),
		);
	}

	/**
	 * Latest ratings with comments.
	 *
	 * @param int $site_id Site (0 = all).
	 * @return array[]
	 */
	private static function recent_reviews( $site_id ) {
		global $wpdb;
		$table = Helpdesk_Hero_Hub_DB::table( 'tickets' );
		$sites = Helpdesk_Hero_Hub_DB::table( 'sites' );
		if ( $site_id ) {
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT t.id, t.subject, t.rating, t.rating_comment, t.rated_at, s.name AS site FROM %i t LEFT JOIN %i s ON s.id = t.site_id WHERE t.rating > 0 AND t.site_id = %d ORDER BY t.rated_at DESC LIMIT 8', $table, $sites, $site_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		} else {
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT t.id, t.subject, t.rating, t.rating_comment, t.rated_at, s.name AS site FROM %i t LEFT JOIN %i s ON s.id = t.site_id WHERE t.rating > 0 ORDER BY t.rated_at DESC LIMIT 8', $table, $sites ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}
		return array_map(
			static function ( $r ) {
				return array(
					'id'      => (int) $r['id'],
					'subject' => $r['subject'],
					'rating'  => (int) $r['rating'],
					'comment' => (string) $r['rating_comment'],
					'site'    => (string) $r['site'],
					'time'    => $r['rated_at'] ? gmdate( 'c', strtotime( $r['rated_at'] . ' UTC' ) ) : null,
				);
			},
			$rows
		);
	}

	/**
	 * The analytics explorer: the Inbox filters, a date range and a "group by", returning KPIs,
	 * a daily series, breakdowns and the group table. Every number can be clicked in the hub to
	 * narrow the filters further.
	 *
	 * @param array $params Request parameters (Inbox filters plus from, to, group).
	 * @return array
	 */
	public static function explore( array $params ) {
		$from = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $params['from'] ?? '' ) ) ? $params['from'] : gmdate( 'Y-m-d', time() - 29 * DAY_IN_SECONDS );
		$to   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $params['to'] ?? '' ) ) ? $params['to'] : gmdate( 'Y-m-d' );
		if ( $from > $to ) {
			list( $from, $to ) = array( $to, $from );
		}
		$params['from']   = $from;
		$params['to']     = $to;
		$params['status'] = '' !== (string) ( $params['status'] ?? '' ) ? $params['status'] : 'all';
		$args             = Helpdesk_Hero_Hub_Admin_REST::inbox_args( $params );
		$rows             = Helpdesk_Hero_Hub::tickets( array_merge( $args, array( 'limit' => 5000, 'orderby' => 'created', 'order' => 'asc' ) ) );
		$group            = in_array( $params['group'] ?? '', array_keys( self::groups() ), true ) ? $params['group'] : 'site';
		$time             = self::time_for( wp_list_pluck( $rows, 'id' ) );

		// Daily series between the two dates (at most a year of days).
		$dates = array();
		for ( $d = strtotime( $from . ' UTC' ), $end = strtotime( $to . ' UTC' ), $n = 0; $d <= $end && $n < 366; $d += DAY_IN_SECONDS, $n++ ) {
			$dates[] = gmdate( 'Y-m-d', $d );
		}
		$index  = array_flip( $dates );
		$opened = array_fill( 0, count( $dates ), 0 );
		$closed = array_fill( 0, count( $dates ), 0 );
		foreach ( $rows as $r ) {
			$day = substr( (string) $r['created_at'], 0, 10 );
			if ( isset( $index[ $day ] ) ) {
				++$opened[ $index[ $day ] ];
			}
			$day = $r['closed_at'] ? substr( (string) $r['closed_at'], 0, 10 ) : '';
			if ( isset( $index[ $day ] ) ) {
				++$closed[ $index[ $day ] ];
			}
		}

		$breakdown = static function ( $key ) use ( $rows ) {
			$buckets = array();
			foreach ( $rows as $r ) {
				foreach ( self::keys_for( $r, $key ) as $k ) {
					$buckets[ $k ] = ( $buckets[ $k ] ?? 0 ) + 1;
				}
			}
			arsort( $buckets );
			$out = array();
			foreach ( array_slice( $buckets, 0, 12, true ) as $k => $count ) {
				$out[] = array(
					'value' => (string) $k,
					'label' => self::label( $key, (string) $k ),
					'count' => $count,
				);
			}
			return $out;
		};

		// The group table: every KPI per group.
		$by = array();
		foreach ( $rows as $r ) {
			foreach ( self::keys_for( $r, $group ) as $k ) {
				$by[ $k ][] = $r;
			}
		}
		$table = array();
		foreach ( $by as $k => $list ) {
			$table[] = array_merge(
				array(
					'value' => (string) $k,
					'label' => self::label( $group, (string) $k ),
				),
				self::kpis( $list, $time )
			);
		}
		usort(
			$table,
			static function ( $a, $b ) {
				return $b['tickets'] <=> $a['tickets'];
			}
		);

		return array(
			'from'       => $from,
			'to'         => $to,
			'group'      => $group,
			'groups'     => self::groups(),
			'kpis'       => self::kpis( $rows, $time ),
			'series'     => compact( 'dates', 'opened', 'closed' ),
			'breakdowns' => array(
				'status'   => $breakdown( 'status' ),
				'priority' => $breakdown( 'priority' ),
				'category' => $breakdown( 'category' ),
				'tag'      => $breakdown( 'tag' ),
				'site'     => $breakdown( 'site' ),
				'rating'   => $breakdown( 'rating' ),
			),
			'table'      => $table,
			'capped'     => count( $rows ) >= 5000,
			'currency'   => class_exists( 'Helpdesk_Hero_Pro_Billing' ) ? (string) ( Helpdesk_Hero_Pro_Billing::settings()['currency'] ?? '' ) : '',
		);
	}

	/**
	 * What the explorer can group by.
	 *
	 * @return array Key => label.
	 */
	public static function groups() {
		return array(
			'site'     => __( 'Site', 'helpdesk-hero-pro' ),
			'category' => __( 'Category', 'helpdesk-hero-pro' ),
			'service'  => __( 'Service', 'helpdesk-hero-pro' ),
			'assignee' => __( 'Assigned to', 'helpdesk-hero-pro' ),
			'tier'     => __( 'Customer tier', 'helpdesk-hero-pro' ),
			'priority' => __( 'Priority', 'helpdesk-hero-pro' ),
			'tag'      => __( 'Tag', 'helpdesk-hero-pro' ),
			'status'   => __( 'Status', 'helpdesk-hero-pro' ),
		);
	}

	/**
	 * A ticket's keys for a grouping. The keys are the Inbox filter values, so a click in the
	 * hub can filter by them ("none" for empty, a ticket can have several tags).
	 *
	 * @param array  $r   Ticket row.
	 * @param string $key Grouping.
	 * @return string[]
	 */
	private static function keys_for( array $r, $key ) {
		switch ( $key ) {
			case 'site':
				return array( (string) (int) $r['site_id'] );
			case 'category':
				return array( '' !== (string) $r['category'] ? (string) $r['category'] : 'none' );
			case 'service':
				return array( '' !== (string) $r['service'] ? (string) $r['service'] : 'none' );
			case 'assignee':
				return array( (string) (int) $r['assignee_id'] );
			case 'tier':
				return array( (string) $r['site_tier'] );
			case 'tag':
				return $r['tags'] ? array_map( 'strval', $r['tags'] ) : array();
			case 'rating':
				return (int) $r['rating'] ? array( (string) (int) $r['rating'] ) : array();
			default:
				return array( (string) ( $r[ $key ] ?? '' ) );
		}
	}

	/**
	 * Readable label for a group key.
	 *
	 * @param string $key   Grouping.
	 * @param string $value Value.
	 * @return string
	 */
	private static function label( $key, $value ) {
		static $sites = null, $tags = null, $services = null;
		switch ( $key ) {
			case 'site':
				if ( null === $sites ) {
					$sites = array();
					foreach ( Helpdesk_Hero_Hub::sites() as $s ) {
						$sites[ (int) $s['id'] ] = $s['name'] ? $s['name'] : $s['label'];
					}
				}
				return $sites[ (int) $value ] ?? __( 'Removed site', 'helpdesk-hero-pro' );
			case 'category':
				return 'none' === $value ? __( 'No category', 'helpdesk-hero-pro' ) : $value;
			case 'service':
				if ( null === $services ) {
					$services = array_column( Helpdesk_Hero_Hub::services(), 'name', 'id' );
				}
				return 'none' === $value ? __( 'No service', 'helpdesk-hero-pro' ) : ( $services[ $value ] ?? $value );
			case 'assignee':
				$user = (int) $value ? get_userdata( (int) $value ) : null;
				return (int) $value ? ( $user ? $user->display_name : __( 'Former team member', 'helpdesk-hero-pro' ) ) : __( 'Nobody', 'helpdesk-hero-pro' );
			case 'tier':
				$tier = Helpdesk_Hero_Hub_Tiers::badge( $value );
				return $tier ? $tier['name'] : __( 'No tier', 'helpdesk-hero-pro' );
			case 'tag':
				if ( null === $tags ) {
					$tags = array_column( Helpdesk_Hero_Hub_Tags::all(), 'name', 'id' );
				}
				return $tags[ $value ] ?? $value;
			case 'priority':
				$labels = array(
					'low'    => __( 'Low', 'helpdesk-hero-pro' ),
					'normal' => __( 'Normal', 'helpdesk-hero-pro' ),
					'high'   => __( 'High', 'helpdesk-hero-pro' ),
					'urgent' => __( 'Urgent', 'helpdesk-hero-pro' ),
				);
				return $labels[ $value ] ?? $value;
			case 'status':
				$labels = array(
					'open'    => __( 'Open', 'helpdesk-hero-pro' ),
					'pending' => __( 'Waiting on customer', 'helpdesk-hero-pro' ),
					'closed'  => __( 'Closed', 'helpdesk-hero-pro' ),
				);
				return $labels[ $value ] ?? $value;
			case 'rating':
				/* translators: %d: stars */
				return sprintf( _n( '%d star', '%d stars', (int) $value, 'helpdesk-hero-pro' ), (int) $value );
		}
		return $value;
	}

	/**
	 * KPIs for a set of tickets.
	 *
	 * @param array[] $rows Tickets.
	 * @param array   $time Time per ticket ID { minutes, billable, amount }.
	 * @return array
	 */
	private static function kpis( array $rows, array $time ) {
		$sla_total = 0;
		$sla_met   = 0;
		$now       = time();
		$ratings   = array();
		$minutes   = 0;
		$billable  = 0;
		$amount    = 0.0;
		foreach ( $rows as $r ) {
			// A target counts once it is decided: answered or closed, or its deadline has passed.
			foreach ( array( array( 'respond_due', 'first_response_at' ), array( 'resolve_due', 'closed_at' ) ) as list( $due, $done ) ) {
				if ( empty( $r[ $due ] ) ) {
					continue;
				}
				$deadline = strtotime( $r[ $due ] . ' UTC' );
				if ( ! empty( $r[ $done ] ) ) {
					++$sla_total;
					if ( strtotime( $r[ $done ] . ' UTC' ) <= $deadline ) {
						++$sla_met;
					}
				} elseif ( $deadline < $now ) {
					++$sla_total;
				}
			}
			if ( (int) $r['rating'] ) {
				$ratings[] = (int) $r['rating'];
			}
			if ( isset( $time[ (int) $r['id'] ] ) ) {
				$minutes  += $time[ (int) $r['id'] ]['minutes'];
				$billable += $time[ (int) $r['id'] ]['billable'];
				$amount   += $time[ (int) $r['id'] ]['amount'];
			}
		}
		return array(
			'tickets'        => count( $rows ),
			'closed'         => count( array_filter( array_column( $rows, 'status' ), static function ( $s ) { return 'closed' === $s; } ) ),
			'first_response' => Helpdesk_Hero_Hub_Stats::median_hours( $rows, 'first_response_at' ),
			'resolution'     => Helpdesk_Hero_Hub_Stats::median_hours( $rows, 'closed_at' ),
			'sla_met'        => $sla_total ? (int) round( 100 * $sla_met / $sla_total ) : null,
			'rating'         => $ratings ? round( array_sum( $ratings ) / count( $ratings ), 2 ) : null,
			'ratings'        => count( $ratings ),
			'hours'          => round( $minutes / 60, 1 ),
			'billable_hours' => round( $billable / 60, 1 ),
			'amount'         => round( $amount, 2 ),
		);
	}

	/**
	 * Time logged on tickets (all dates), when the time module is on.
	 *
	 * @param int[] $ids Ticket IDs.
	 * @return array Ticket ID => { minutes, billable, amount }.
	 */
	private static function time_for( array $ids ) {
		global $wpdb;
		$ids = array_filter( array_map( 'intval', $ids ) );
		if ( ! $ids || ! class_exists( 'Helpdesk_Hero_Pro_Time' ) || ! Helpdesk_Hero_Pro_Modules::on( 'time' ) ) {
			return array();
		}
		$out = array();
		foreach ( array_chunk( $ids, 500 ) as $chunk ) {
			$in   = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ticket_id, SUM(minutes) AS minutes, SUM(CASE WHEN billable = 1 THEN minutes ELSE 0 END) AS billable, SUM(amount) AS amount FROM %i WHERE ticket_id IN ($in) GROUP BY ticket_id", array_merge( array( Helpdesk_Hero_Pro_Time::table() ), $chunk ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			foreach ( $rows as $row ) {
				$out[ (int) $row['ticket_id'] ] = array(
					'minutes'  => (int) $row['minutes'],
					'billable' => (int) $row['billable'],
					'amount'   => (float) $row['amount'],
				);
			}
		}
		return $out;
	}

	/**
	 * Supporter KPIs for a period: per team member (and "Nobody" for unassigned tickets), from
	 * tickets opened in the period and assigned to them, and their own replies, notes and logged
	 * time in the period.
	 *
	 * @param string $from Start date (Y-m-d).
	 * @param string $to   End date (Y-m-d).
	 * @return array { from, to, rows[], total, time }
	 */
	public static function team( $from, $to ) {
		global $wpdb;
		$from = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $from ) ? $from : gmdate( 'Y-m-d', time() - 29 * DAY_IN_SECONDS );
		$to   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $to ) ? $to : gmdate( 'Y-m-d' );
		if ( $from > $to ) {
			list( $from, $to ) = array( $to, $from );
		}
		$rows = Helpdesk_Hero_Hub::tickets(
			array(
				'status' => '',
				'from'   => $from,
				'to'     => $to,
				'limit'  => 5000,
			)
		);
		$time = self::time_for( wp_list_pluck( $rows, 'id' ) );

		// Replies and notes written in the period, by who wrote them.
		$outbox = Helpdesk_Hero_Hub_DB::table( 'outbox' );
		$start  = $from . ' 00:00:00';
		$end    = $to . ' 23:59:59';
		$writes = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT created_by, type, COUNT(*) AS n FROM %i WHERE type IN ('reply','internal_note') AND created_by > 0 AND created_at BETWEEN %s AND %s GROUP BY created_by, type", $outbox, $start, $end ), ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$writes[ (int) $r['created_by'] ][ $r['type'] ] = (int) $r['n'];
		}

		// Replies each closed ticket needed (by anyone), for "replies to resolve".
		$closed     = array_map( 'intval', wp_list_pluck( array_filter( $rows, static function ( $r ) { return 'closed' === $r['status']; } ), 'id' ) );
		$per_ticket = array();
		if ( $closed ) {
			foreach ( array_chunk( $closed, 500 ) as $chunk ) {
				$in = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );
				foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT hub_ticket_id, COUNT(*) AS n FROM %i WHERE type = 'reply' AND hub_ticket_id IN ($in) GROUP BY hub_ticket_id", array_merge( array( $outbox ), $chunk ) ), ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$per_ticket[ (int) $r['hub_ticket_id'] ] = (int) $r['n'];
				}
			}
		}

		// Time each person logged in the period (handling time), when time tracking is on.
		$logged = array();
		$timeon = class_exists( 'Helpdesk_Hero_Pro_Time' ) && Helpdesk_Hero_Pro_Modules::on( 'time' ) && get_option( Helpdesk_Hero_Pro_Time::DB_OPTION ) === Helpdesk_Hero_Pro_Time::DB_VERSION;
		if ( $timeon ) {
			foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT user_id, SUM(minutes) AS m FROM %i WHERE kind = 'time' AND worked_on BETWEEN %s AND %s GROUP BY user_id", Helpdesk_Hero_Pro_Time::table(), $from, $to ), ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$logged[ (int) $r['user_id'] ] = (int) $r['m'];
			}
		}

		$by = array();
		foreach ( $rows as $r ) {
			$by[ (int) $r['assignee_id'] ][] = $r;
		}
		$people = array();
		foreach ( Helpdesk_Hero_Hub::team() as $m ) {
			$people[ (int) $m['id'] ] = $m['name'];
		}
		// People who did work but have left the team still count.
		foreach ( array_keys( $by + $writes + $logged ) as $id ) {
			if ( $id && ! isset( $people[ $id ] ) ) {
				$user          = get_userdata( $id );
				$people[ $id ] = $user ? $user->display_name : __( 'Former team member', 'helpdesk-hero-pro' );
			}
		}
		$people[0] = __( 'Nobody (unassigned)', 'helpdesk-hero-pro' );

		$out = array();
		foreach ( $people as $id => $name ) {
			$list = $by[ $id ] ?? array();
			$k    = self::kpis( $list, $time );
			$mine = array_filter( $list, static function ( $r ) { return 'closed' === $r['status']; } );
			$need = array_map(
				static function ( $r ) use ( $per_ticket ) {
					return $per_ticket[ (int) $r['id'] ] ?? 0;
				},
				$mine
			);
			$row = array(
				'id'                => (int) $id,
				'name'              => $name,
				'assigned'          => $k['tickets'],
				'resolved'          => $k['closed'],
				'replies'           => (int) ( $writes[ $id ]['reply'] ?? 0 ),
				'notes'             => (int) ( $writes[ $id ]['internal_note'] ?? 0 ),
				'replies_to_resolve' => $need ? round( array_sum( $need ) / count( $need ), 1 ) : null,
				'first_response'    => $k['first_response'],
				'resolution'        => $k['resolution'],
				'sla_met'           => $k['sla_met'],
				'rating'            => $k['rating'],
				'ratings'           => $k['ratings'],
				'hours'             => $timeon ? round( ( $logged[ $id ] ?? 0 ) / 60, 1 ) : null,
			);
			// Skip people with nothing in the period.
			if ( $row['assigned'] || $row['replies'] || $row['notes'] || $row['hours'] ) {
				$out[] = $row;
			}
		}
		$all = self::kpis( $rows, $time );
		return array(
			'from'  => $from,
			'to'    => $to,
			'time'  => $timeon,
			'rows'  => $out,
			'total' => array(
				'assigned'       => $all['tickets'],
				'resolved'       => $all['closed'],
				'replies'        => array_sum( array_map( static function ( $w ) { return (int) ( $w['reply'] ?? 0 ); }, $writes ) ),
				'first_response' => $all['first_response'],
				'resolution'     => $all['resolution'],
				'sla_met'        => $all['sla_met'],
				'rating'         => $all['rating'],
				'ratings'        => $all['ratings'],
				'hours'          => $timeon ? round( array_sum( $logged ) / 60, 1 ) : null,
			),
		);
	}
}
