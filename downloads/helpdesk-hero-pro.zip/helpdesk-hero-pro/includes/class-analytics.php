<?php
/**
 * Advanced analytics and reviews.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Full analytics for any range, all sites or one site: ticket volume, categories, priorities,
 * tags, recurring issues, busiest sites, response and resolution times, and customer ratings.
 * Also switches on customer ratings ("reviews") in the support policy.
 */
final class Helpdesk_Hero_Pro_Analytics {

	/**
	 * Register hooks (licensed hubs only).
	 */
	public static function init() {
		add_filter( 'helpdesk_hero_hub_ratings_available', '__return_true' );
		add_action( 'helpdesk_hero_hub_ticket_rated', array( __CLASS__, 'note_rating' ), 10, 3 );
	}

	/**
	 * Add a customer's rating to the help desk as an internal note.
	 *
	 * @param array  $ticket  Ticket.
	 * @param int    $rating  Rating.
	 * @param string $comment Comment.
	 */
	public static function note_rating( $ticket, $rating, $comment ) {
		$helpdesk = Helpdesk_Hero_Hub_Helpdesk::for_ticket( $ticket );
		if ( $helpdesk ) {
			/* translators: 1: stars, 2: comment */
			$helpdesk->note( $ticket, sprintf( __( 'Customer rating: %1$s (%2$d/5)', 'helpdesk-hero-pro' ), str_repeat( '★', (int) $rating ) . str_repeat( '☆', 5 - (int) $rating ), (int) $rating ) . ( '' !== $comment ? "\n“" . $comment . '”' : '' ) );
		}
	}

	/**
	 * Analytics.
	 *
	 * @param int $days    Range in days (7–365).
	 * @param int $site_id Site (0 = all).
	 * @return array
	 */
	public static function report( $days, $site_id = 0 ) {
		$days  = max( 7, min( 365, (int) $days ) );
		$rows  = Helpdesk_Hero_Hub_Stats::rows( $days, $site_id );
		$sites = array();
		foreach ( Helpdesk_Hero_Hub::sites() as $s ) {
			$sites[ (int) $s['id'] ] = $s['name'] ? $s['name'] : $s['label'];
		}
		$tags = array_column( Helpdesk_Hero_Hub_Tags::all(), null, 'id' );

		$rated   = array_filter(
			$rows,
			static function ( $r ) {
				return (int) $r['rating'] > 0;
			}
		);
		$dist    = array_fill( 1, 5, 0 );
		foreach ( $rated as $r ) {
			++$dist[ (int) $r['rating'] ];
		}
		$average = $rated ? round( array_sum( array_column( $rated, 'rating' ) ) / count( $rated ), 2 ) : null;

		$priority_labels = array(
			'low'    => __( 'Low', 'helpdesk-hero-pro' ),
			'normal' => __( 'Normal', 'helpdesk-hero-pro' ),
			'high'   => __( 'High', 'helpdesk-hero-pro' ),
			'urgent' => __( 'Urgent', 'helpdesk-hero-pro' ),
		);

		return array(
			'days'        => $days,
			'site'        => $site_id ? array(
				'id'   => $site_id,
				'name' => $sites[ $site_id ] ?? '',
			) : null,
			'sites_list'  => array_map(
				static function ( $id, $name ) {
					return array(
						'id'   => $id,
						'name' => $name,
					);
				},
				array_keys( $sites ),
				$sites
			),
			'totals'      => array(
				'tickets'        => count( $rows ),
				'closed'         => count( array_filter( $rows, static function ( $r ) { return 'closed' === $r['status']; } ) ),
				'first_response' => Helpdesk_Hero_Hub_Stats::median_hours( $rows, 'first_response_at' ),
				'resolution'     => Helpdesk_Hero_Hub_Stats::median_hours( $rows, 'closed_at' ),
				'rating'         => $average,
				'ratings'        => count( $rated ),
			),
			'series'      => Helpdesk_Hero_Hub_Stats::series( $rows, $days ),
			'categories'  => Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) { return '' !== $r['category'] ? $r['category'] : __( 'No category', 'helpdesk-hero-pro' ); }, 8 ),
			'priorities'  => Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) use ( $priority_labels ) { return $priority_labels[ $r['priority'] ] ?? $r['priority']; }, 4 ),
			'tags'        => Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) use ( $tags ) { return array_map( static function ( $id ) use ( $tags ) { return $tags[ $id ]['name'] ?? ''; }, $r['tags'] ); }, 10 ),
			'channels'    => Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) { return 'email' === $r['channel'] ? __( 'Emailed by the customer', 'helpdesk-hero-pro' ) : __( 'Sent from the dashboard', 'helpdesk-hero-pro' ); }, 2 ),
			'issues'      => Helpdesk_Hero_Hub_Stats::recurring_issues( $rows, 10 ),
			'top_sites'   => $site_id ? array() : Helpdesk_Hero_Hub_Stats::count_by( $rows, static function ( $r ) use ( $sites ) { return $sites[ (int) $r['site_id'] ] ?? ''; }, 10 ),
			'ratings'     => array(
				'distribution' => array_values( $dist ),
				'recent'       => self::recent_reviews( $site_id ),
			),
			'tag_colors'  => array_column( Helpdesk_Hero_Hub_Tags::all(), 'color', 'name' ),
			'generated'   => gmdate( 'c' ),
		);
	}

	/**
	 * Latest ratings with comments.
	 *
	 * @param int $site_id Site (0 = all).
	 * @return array[]
	 */
	private static function recent_reviews( $site_id ) {
		global $wpdb;
		$table = Helpdesk_Hero_Hub_DB::table( 'tickets' );
		$sites = Helpdesk_Hero_Hub_DB::table( 'sites' );
		if ( $site_id ) {
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT t.id, t.subject, t.rating, t.rating_comment, t.rated_at, s.name AS site FROM %i t LEFT JOIN %i s ON s.id = t.site_id WHERE t.rating > 0 AND t.site_id = %d ORDER BY t.rated_at DESC LIMIT 8', $table, $sites, $site_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		} else {
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT t.id, t.subject, t.rating, t.rating_comment, t.rated_at, s.name AS site FROM %i t LEFT JOIN %i s ON s.id = t.site_id WHERE t.rating > 0 ORDER BY t.rated_at DESC LIMIT 8', $table, $sites ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}
		return array_map(
			static function ( $r ) {
				return array(
					'id'      => (int) $r['id'],
					'subject' => $r['subject'],
					'rating'  => (int) $r['rating'],
					'comment' => (string) $r['rating_comment'],
					'site'    => (string) $r['site'],
					'time'    => $r['rated_at'] ? gmdate( 'c', strtotime( $r['rated_at'] . ' UTC' ) ) : null,
				);
			},
			$rows
		);
	}
}
