<?php
/**
 * Custom ticket fields and attachments.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Turns on attachments and defines extra fields for new tickets. Both reach customer sites with
 * their policy (sites need Helpdesk Hero 2.1 or later to use them).
 */
final class Helpdesk_Hero_Pro_Extras {

	const FIELDS      = 'helpdesk_hero_pro_fields';
	const ATTACHMENTS = 'helpdesk_hero_pro_attachments';

	/**
	 * Register the custom fields hook.
	 */
	public static function init_fields() {
		add_filter( 'helpdesk_hero_hub_ticket_fields', array( __CLASS__, 'fields' ) );
	}

	/**
	 * Register the attachments hook.
	 */
	public static function init_attachments() {
		add_filter( 'helpdesk_hero_hub_attachments', array( __CLASS__, 'attachments' ) );
	}

	/**
	 * Field definitions.
	 *
	 * @return array[] { id, label, type, options[], required, help }
	 */
	public static function fields() {
		$list = get_option( self::FIELDS, array() );
		return is_array( $list ) ? array_values( $list ) : array();
	}

	/**
	 * Field types.
	 *
	 * @return array<string, string>
	 */
	public static function types() {
		return array(
			'text'     => __( 'Short text', 'helpdesk-hero-pro' ),
			'textarea' => __( 'Long text', 'helpdesk-hero-pro' ),
			'number'   => __( 'Number', 'helpdesk-hero-pro' ),
			'url'      => __( 'Web address', 'helpdesk-hero-pro' ),
			'select'   => __( 'Choice from a list', 'helpdesk-hero-pro' ),
			'checkbox' => __( 'Yes or no', 'helpdesk-hero-pro' ),
		);
	}

	/**
	 * Save field definitions and send them to every site.
	 *
	 * @param array $list Fields.
	 * @return array[]
	 */
	public static function save_fields( array $list ) {
		$clean = array();
		foreach ( array_slice( $list, 0, 20 ) as $f ) {
			$label = trim( sanitize_text_field( (string) ( $f['label'] ?? '' ) ) );
			$type  = (string) ( $f['type'] ?? 'text' );
			if ( '' === $label || ! isset( self::types()[ $type ] ) ) {
				continue;
			}
			$id = sanitize_key( (string) ( $f['id'] ?? '' ) );
			$id = substr( '' !== $id ? $id : str_replace( '-', '_', sanitize_title( $label ) ), 0, 40 );
			while ( '' === $id || isset( $clean[ $id ] ) ) {
				$id = 'field_' . wp_rand( 100, 999 );
			}
			$options = array();
			if ( 'select' === $type ) {
				$options = array_values( array_slice( array_unique( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', (array) ( $f['options'] ?? array() ) ) ) ) ), 0, 30 ) );
				if ( ! $options ) {
					continue;
				}
			}
			$clean[ $id ] = array(
				'id'       => $id,
				'label'    => substr( $label, 0, 80 ),
				'type'     => $type,
				'options'  => $options,
				'required' => ! empty( $f['required'] ) && 'checkbox' !== $type,
				'help'     => substr( sanitize_text_field( (string) ( $f['help'] ?? '' ) ), 0, 200 ),
			);
		}
		update_option( self::FIELDS, array_values( $clean ), false );
		Helpdesk_Hero_Hub_Policy::push_all();
		return self::fields();
	}

	/**
	 * Attachment settings.
	 *
	 * @return array { enabled, max_mb, max_files, types[] }
	 */
	public static function attachment_settings() {
		$s = get_option( self::ATTACHMENTS, array() );
		$s = is_array( $s ) ? $s : array();
		return array(
			'enabled'   => ! empty( $s['enabled'] ),
			'max_mb'    => (int) ( $s['max_mb'] ?? 5 ),
			'max_files' => (int) ( $s['max_files'] ?? 5 ),
			'types'     => isset( $s['types'] ) ? (array) $s['types'] : array( 'png', 'jpg', 'jpeg', 'gif', 'webp', 'pdf', 'txt', 'log', 'csv' ),
			// Delete files this many days after their ticket closes (0: keep them).
			'keep_days' => (int) ( $s['keep_days'] ?? 0 ),
		);
	}

	/**
	 * Hub filter: attachments as configured here.
	 *
	 * @param array $config Hub defaults.
	 * @return array
	 */
	public static function attachments( $config ) {
		return array_merge( (array) $config, self::attachment_settings() );
	}

	/**
	 * Save attachment settings and send them to every site.
	 *
	 * @param array $in Values.
	 * @return array
	 */
	public static function save_attachments( array $in ) {
		update_option(
			self::ATTACHMENTS,
			array(
				'enabled'   => ! empty( $in['enabled'] ),
				'max_mb'    => max( 1, min( 25, (int) ( $in['max_mb'] ?? 5 ) ) ),
				'max_files' => max( 1, min( 10, (int) ( $in['max_files'] ?? 5 ) ) ),
				'types'     => array_values( array_intersect( array_map( 'sanitize_key', (array) ( $in['types'] ?? array() ) ), array_keys( Helpdesk_Hero_Hub_Attachments::mimes() ) ) ),
				'keep_days' => max( 0, min( 3650, (int) ( $in['keep_days'] ?? 0 ) ) ),
			),
			false
		);
		Helpdesk_Hero_Hub_Policy::push_all();
		return self::attachment_settings();
	}
}
