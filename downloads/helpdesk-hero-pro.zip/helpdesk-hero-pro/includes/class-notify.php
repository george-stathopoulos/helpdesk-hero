<?php
/**
 * Slack and webhook notifications.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tells Slack (an incoming webhook) and other services (signed JSON webhooks: Microsoft Teams
 * workflows, Discord, Zapier, Make, your own code) when something happens in the hub.
 *
 * What's sent: the event, the ticket's number, subject, status, priority, the customer's name,
 * the site's name and address, and a link to the ticket in the hub. Never diagnostics, replies
 * or anything from the customer's site beyond that.
 */
final class Helpdesk_Hero_Pro_Notify {

	const OPTION = 'helpdesk_hero_pro_notify';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'helpdesk_hero_hub_ticket_created', array( __CLASS__, 'on_created' ), 20, 1 );
		add_action( 'helpdesk_hero_hub_customer_replied', array( __CLASS__, 'on_customer_reply' ), 20, 1 );
		add_action( 'helpdesk_hero_hub_status_changed', array( __CLASS__, 'on_status' ), 20, 2 );
		add_action( 'helpdesk_hero_hub_ticket_assigned', array( __CLASS__, 'on_assigned' ), 20, 2 );
		add_action( 'helpdesk_hero_hub_ticket_rated', array( __CLASS__, 'on_rated' ), 20, 2 );
		add_action( 'helpdesk_hero_pro_sla_alert', array( __CLASS__, 'on_sla' ), 20, 2 );
	}

	/**
	 * Events people can choose.
	 *
	 * @return array<string, string>
	 */
	public static function events() {
		return array(
			'ticket_created'   => __( 'New ticket', 'helpdesk-hero-pro' ),
			'customer_replied' => __( 'Customer replied', 'helpdesk-hero-pro' ),
			'ticket_assigned'  => __( 'Ticket assigned', 'helpdesk-hero-pro' ),
			'ticket_closed'    => __( 'Ticket closed', 'helpdesk-hero-pro' ),
			'ticket_rated'     => __( 'Customer rated a ticket', 'helpdesk-hero-pro' ),
			'sla_warning'      => __( 'SLA due within the hour', 'helpdesk-hero-pro' ),
			'sla_breached'     => __( 'SLA missed', 'helpdesk-hero-pro' ),
		);
	}

	/**
	 * Settings.
	 *
	 * @return array { slack_url, slack_events[], webhooks: [ { id, url, events[], secret } ] }
	 */
	public static function settings() {
		$s     = get_option( self::OPTION, array() );
		$s     = is_array( $s ) ? $s : array();
		$hooks = array_values( (array) ( $s['webhooks'] ?? array() ) );
		// The Slack address and webhook secrets are stored encrypted.
		foreach ( $hooks as &$hook ) {
			$hook['secret'] = (string) Helpdesk_Hero_Hub_Crypto::decrypt( (string) ( $hook['secret'] ?? '' ) );
		}
		return array(
			'slack_url'    => (string) Helpdesk_Hero_Hub_Crypto::decrypt( (string) ( $s['slack_url'] ?? '' ) ),
			'slack_events' => (array) ( $s['slack_events'] ?? array( 'ticket_created', 'customer_replied', 'sla_breached' ) ),
			'webhooks'     => $hooks,
		);
	}

	/**
	 * Settings for the dashboard: webhook secrets are shown once, then only their end.
	 *
	 * @return array
	 */
	public static function public_settings() {
		$s = self::settings();
		foreach ( $s['webhooks'] as &$hook ) {
			$hook['secret_hint'] = '…' . substr( (string) $hook['secret'], -4 );
			unset( $hook['secret'] );
		}
		$s['slack_set'] = '' !== $s['slack_url'];
		$s['slack_url'] = '' !== $s['slack_url'] ? substr( $s['slack_url'], 0, 34 ) . '…' : '';
		return $s;
	}

	/**
	 * Save settings.
	 *
	 * @param array $in Values. slack_url: a new URL, '' to remove it, or omitted to keep it.
	 * @return array|WP_Error Public settings.
	 */
	public static function save( array $in ) {
		$current = self::settings();
		$events  = array_keys( self::events() );
		$slack   = $current['slack_url'];
		if ( array_key_exists( 'slack_url', $in ) && false === strpos( (string) $in['slack_url'], '…' ) ) {
			$slack = trim( (string) $in['slack_url'] );
			if ( '' !== $slack && ! preg_match( '#^https://hooks\.slack\.com/(services|workflows|triggers)/[A-Za-z0-9/_-]+$#', $slack ) ) {
				return new WP_Error( 'helpdesk_hero_pro_slack', __( 'That isn’t a Slack incoming webhook address. It starts with https://hooks.slack.com/', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
			}
		}
		$old_hooks = array_column( $current['webhooks'], null, 'id' );
		$hooks     = array();
		foreach ( (array) ( $in['webhooks'] ?? array() ) as $hook ) {
			$url = esc_url_raw( trim( (string) ( $hook['url'] ?? '' ) ), array( 'https' ) );
			if ( '' === $url ) {
				continue;
			}
			if ( ! Helpdesk_Hero_Hub_Signer::secure_url( $url ) ) {
				return new WP_Error( 'helpdesk_hero_pro_webhook', __( 'Webhook addresses must use HTTPS.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
			}
			$id      = sanitize_key( (string) ( $hook['id'] ?? '' ) );
			$id      = '' !== $id && isset( $old_hooks[ $id ] ) ? $id : 'wh' . strtolower( wp_generate_password( 8, false ) );
			$hooks[] = array(
				'id'     => $id,
				'url'    => $url,
				'events' => array_values( array_intersect( (array) ( $hook['events'] ?? array() ), $events ) ),
				'secret' => isset( $old_hooks[ $id ] ) ? $old_hooks[ $id ]['secret'] : bin2hex( random_bytes( 24 ) ),
			);
		}
		$stored = $hooks;
		foreach ( $stored as &$hook ) {
			$hook['secret'] = Helpdesk_Hero_Hub_Crypto::encrypt( $hook['secret'] );
		}
		unset( $hook );
		update_option(
			self::OPTION,
			array(
				'slack_url'    => Helpdesk_Hero_Hub_Crypto::encrypt( $slack ),
				'slack_events' => array_values( array_intersect( (array) ( $in['slack_events'] ?? $current['slack_events'] ), $events ) ),
				'webhooks'     => $stored,
			),
			false
		);
		// New webhooks show their signing secret once.
		$public = self::public_settings();
		foreach ( $hooks as $i => $hook ) {
			if ( ! isset( $old_hooks[ $hook['id'] ] ) ) {
				$public['webhooks'][ $i ]['secret_new'] = $hook['secret'];
			}
		}
		return $public;
	}

	/* ---------------------------------------------------------------------------------------- */

	/**
	 * Ticket summary sent to Slack and webhooks.
	 *
	 * @param array $ticket Ticket.
	 * @return array
	 */
	private static function summary( array $ticket ) {
		$site = Helpdesk_Hero_Hub::site( (int) $ticket['site_id'] );
		$tier = $site ? Helpdesk_Hero_Hub_Tiers::badge( (string) $site['tier'] ) : null;
		return array(
			'id'       => (int) $ticket['id'],
			'subject'  => (string) $ticket['subject'],
			'status'   => (string) $ticket['status'],
			'priority' => (string) $ticket['priority'],
			'customer' => (string) ( $ticket['customer_name'] ? $ticket['customer_name'] : $ticket['customer_email'] ),
			'site'     => $site ? array(
				'name' => $site['name'] ? $site['name'] : $site['label'],
				'url'  => $site['url'],
				'tier' => $tier ? $tier['name'] : '',
			) : null,
			'url'      => Helpdesk_Hero_Hub::ticket_url( (int) $ticket['id'] ),
		);
	}

	/**
	 * Send an event to Slack and the webhooks that want it.
	 *
	 * @param string $event  Event.
	 * @param array  $ticket Ticket.
	 * @param string $text   One line for people.
	 * @param array  $extra  More fields for webhooks.
	 */
	public static function send( $event, array $ticket, $text, array $extra = array() ) {
		$s       = self::settings();
		$summary = self::summary( $ticket );
		if ( '' !== $s['slack_url'] && in_array( $event, $s['slack_events'], true ) ) {
			$site = $summary['site'] ? ' · ' . $summary['site']['name'] . ( $summary['site']['tier'] ? ' (' . $summary['site']['tier'] . ')' : '' ) : '';
			wp_remote_post(
				$s['slack_url'],
				array(
					'timeout'  => 3,
					'blocking' => false,
					'headers'  => array( 'Content-Type' => 'application/json' ),
					'body'     => wp_json_encode(
						array(
							'text' => self::slack_escape( $text ) . "\n<" . $summary['url'] . '|#' . $summary['id'] . ' ' . self::slack_escape( $summary['subject'] ) . '>' . self::slack_escape( $site ),
						)
					),
				)
			);
		}
		foreach ( $s['webhooks'] as $hook ) {
			if ( ! in_array( $event, (array) $hook['events'], true ) ) {
				continue;
			}
			$body = (string) wp_json_encode(
				array_merge(
					array(
						'event'  => $event,
						'text'   => $text,
						'time'   => gmdate( 'c' ),
						'ticket' => $summary,
						'hub'    => Helpdesk_Hero_Hub_Settings::team_name(),
					),
					$extra
				)
			);
			wp_remote_post(
				$hook['url'],
				array(
					'timeout'  => 3,
					'blocking' => false,
					'headers'  => array(
						'Content-Type'          => 'application/json',
						'X-Helpdesk-Hero-Event' => $event,
						// HMAC-SHA256 of the raw body with the webhook's secret, so receivers can check it came from your hub.
						'X-Helpdesk-Hero-Signature' => 'sha256=' . hash_hmac( 'sha256', $body, (string) $hook['secret'] ),
					),
					'body'     => $body,
				)
			);
		}
	}

	/**
	 * Escape text for Slack's message format.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function slack_escape( $text ) {
		return str_replace( array( '&', '<', '>' ), array( '&amp;', '&lt;', '&gt;' ), (string) $text );
	}

	/**
	 * Send a test message.
	 *
	 * @return true|WP_Error
	 */
	public static function test() {
		$s = self::settings();
		if ( '' === $s['slack_url'] && ! $s['webhooks'] ) {
			return new WP_Error( 'helpdesk_hero_pro_notify', __( 'Add a Slack address or a webhook first.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
		}
		$errors = array();
		if ( '' !== $s['slack_url'] ) {
			$r = wp_remote_post(
				$s['slack_url'],
				array(
					'timeout' => 10,
					'headers' => array( 'Content-Type' => 'application/json' ),
					'body'    => wp_json_encode( array( 'text' => __( 'Helpdesk Hero is connected. Ticket notifications will appear here.', 'helpdesk-hero-pro' ) ) ),
				)
			);
			if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
				/* translators: %s: error */
				$errors[] = sprintf( __( 'Slack: %s', 'helpdesk-hero-pro' ), is_wp_error( $r ) ? $r->get_error_message() : wp_remote_retrieve_body( $r ) );
			}
		}
		foreach ( $s['webhooks'] as $hook ) {
			$body = (string) wp_json_encode(
				array(
					'event' => 'test',
					'text'  => __( 'Test from Helpdesk Hero', 'helpdesk-hero-pro' ),
					'time'  => gmdate( 'c' ),
				)
			);
			$r    = wp_remote_post(
				$hook['url'],
				array(
					'timeout' => 10,
					'headers' => array(
						'Content-Type'              => 'application/json',
						'X-Helpdesk-Hero-Event'     => 'test',
						'X-Helpdesk-Hero-Signature' => 'sha256=' . hash_hmac( 'sha256', $body, (string) $hook['secret'] ),
					),
					'body'    => $body,
				)
			);
			$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
			if ( $code < 200 || $code >= 300 ) {
				/* translators: 1: webhook address, 2: error */
				$errors[] = sprintf( __( '%1$s: %2$s', 'helpdesk-hero-pro' ), wp_parse_url( $hook['url'], PHP_URL_HOST ), is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . $code );
			}
		}
		return $errors ? new WP_Error( 'helpdesk_hero_pro_notify', implode( ' · ', $errors ), array( 'status' => 502 ) ) : true;
	}

	/* ---------------------------------------------------------------------------------------- */

	/**
	 * New ticket.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_created( $ticket ) {
		/* translators: %s: customer */
		self::send( 'ticket_created', (array) $ticket, sprintf( __( 'New ticket from %s', 'helpdesk-hero-pro' ), $ticket['customer_name'] ? $ticket['customer_name'] : $ticket['customer_email'] ) );
	}

	/**
	 * Customer reply.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_customer_reply( $ticket ) {
		/* translators: %s: customer */
		self::send( 'customer_replied', (array) $ticket, sprintf( __( '%s replied', 'helpdesk-hero-pro' ), $ticket['customer_name'] ? $ticket['customer_name'] : $ticket['customer_email'] ) );
	}

	/**
	 * Status change (closing only).
	 *
	 * @param array  $ticket Ticket.
	 * @param string $status New status.
	 */
	public static function on_status( $ticket, $status ) {
		if ( 'closed' === $status ) {
			self::send( 'ticket_closed', array_merge( (array) $ticket, array( 'status' => 'closed' ) ), __( 'Ticket closed', 'helpdesk-hero-pro' ) );
		}
	}

	/**
	 * Assignment.
	 *
	 * @param array $ticket  Ticket.
	 * @param int   $user_id Assignee.
	 */
	public static function on_assigned( $ticket, $user_id ) {
		$user = $user_id ? get_userdata( (int) $user_id ) : false;
		if ( $user ) {
			/* translators: %s: person */
			self::send( 'ticket_assigned', (array) $ticket, sprintf( __( 'Assigned to %s', 'helpdesk-hero-pro' ), $user->display_name ), array( 'assignee' => $user->display_name ) );
		}
	}

	/**
	 * Rating.
	 *
	 * @param array $ticket Ticket.
	 * @param int   $rating Stars.
	 */
	public static function on_rated( $ticket, $rating ) {
		/* translators: %d: stars out of 5 */
		self::send( 'ticket_rated', (array) $ticket, sprintf( __( 'Rated %d/5', 'helpdesk-hero-pro' ), (int) $rating ), array( 'rating' => (int) $rating ) );
	}

	/**
	 * SLA warning or breach (from Helpdesk_Hero_Pro_SLA).
	 *
	 * @param array  $ticket Ticket.
	 * @param string $kind   warning | breached.
	 */
	public static function on_sla( $ticket, $kind ) {
		if ( 'breached' === $kind ) {
			self::send( 'sla_breached', (array) $ticket, __( 'SLA missed', 'helpdesk-hero-pro' ) );
		} else {
			self::send( 'sla_warning', (array) $ticket, __( 'SLA due within the hour', 'helpdesk-hero-pro' ) );
		}
	}
}
