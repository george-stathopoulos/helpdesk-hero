<?php
/**
 * Updates for licensed sites.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Offers new versions through the normal WordPress update screens.
 *
 * Reads a JSON manifest at HELPDESK_HERO_PRO_UPDATE_URL (any static file host works), for example:
 *
 *     {
 *       "version": "1.1.0",
 *       "download_url": "https://example.com/downloads/helpdesk-hero-pro-1.1.0.zip",
 *       "requires": "7.0",
 *       "tested": "7.1",
 *       "requires_php": "7.4",
 *       "changelog": "<h4>1.1.0</h4><ul><li>…</li></ul>"
 *     }
 *
 * The site's license key and domain are appended as query arguments, so a server can check the
 * license before handing out the zip. With HELPDESK_HERO_PRO_UPDATE_URL empty, this class does nothing.
 */
final class Helpdesk_Hero_Pro_Updater {

	const TRANSIENT = 'helpdesk_hero_pro_update_manifest';

	/**
	 * Register hooks.
	 */
	public static function init() {
		if ( '' === (string) HELPDESK_HERO_PRO_UPDATE_URL ) {
			return;
		}
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'details' ), 10, 3 );
	}

	/**
	 * Add Helpdesk Hero Pro to the update list when a newer version exists.
	 *
	 * @param object $transient Update transient.
	 * @return object
	 */
	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$manifest = self::manifest();
		$basename = plugin_basename( HELPDESK_HERO_PRO_FILE );
		if ( $manifest && version_compare( $manifest['version'], HELPDESK_HERO_PRO_VERSION, '>' ) ) {
			$transient->response[ $basename ] = (object) array(
				'slug'         => 'helpdesk-hero-pro',
				'plugin'       => $basename,
				'new_version'  => $manifest['version'],
				'package'      => Helpdesk_Hero_Pro_License::is_active() ? $manifest['download_url'] : '',
				'tested'       => $manifest['tested'] ?? '',
				'requires_php' => $manifest['requires_php'] ?? '',
				'url'          => (string) HELPDESK_HERO_PRO_BUY_URL,
			);
		}
		return $transient;
	}

	/**
	 * "View details" information.
	 *
	 * @param false|object $result Result.
	 * @param string       $action Action.
	 * @param object       $args   Args.
	 * @return false|object
	 */
	public static function details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! isset( $args->slug ) || 'helpdesk-hero-pro' !== $args->slug ) {
			return $result;
		}
		$manifest = self::manifest();
		if ( ! $manifest ) {
			return $result;
		}
		return (object) array(
			'name'          => 'Helpdesk Hero Pro',
			'slug'          => 'helpdesk-hero-pro',
			'version'       => $manifest['version'],
			'requires'      => $manifest['requires'] ?? '',
			'tested'        => $manifest['tested'] ?? '',
			'requires_php'  => $manifest['requires_php'] ?? '',
			'download_link' => Helpdesk_Hero_Pro_License::is_active() ? $manifest['download_url'] : '',
			'sections'      => array( 'changelog' => wp_kses_post( $manifest['changelog'] ?? '' ) ),
		);
	}

	/**
	 * Fetch the manifest (cached for 12 hours).
	 *
	 * @return array|null
	 */
	private static function manifest() {
		$cached = get_transient( self::TRANSIENT );
		if ( is_array( $cached ) ) {
			return $cached ? $cached : null;
		}
		$state = Helpdesk_Hero_Pro_License::state();
		$url   = add_query_arg(
			array(
				'license' => rawurlencode( $state['key'] ),
				'site'    => rawurlencode( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ),
				'version' => HELPDESK_HERO_PRO_VERSION,
			),
			HELPDESK_HERO_PRO_UPDATE_URL
		);
		$response = wp_remote_get( $url, array( 'timeout' => 10 ) );
		$data     = is_wp_error( $response ) ? null : json_decode( wp_remote_retrieve_body( $response ), true );
		$valid    = is_array( $data ) && ! empty( $data['version'] ) && ! empty( $data['download_url'] );
		set_transient( self::TRANSIENT, $valid ? $data : array(), 12 * HOUR_IN_SECONDS );
		return $valid ? $data : null;
	}
}
