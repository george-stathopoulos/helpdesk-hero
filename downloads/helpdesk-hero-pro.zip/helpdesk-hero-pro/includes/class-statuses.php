<?php
/**
 * Custom ticket statuses.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Statuses beyond Open, Waiting on customer and Closed, such as "In progress" or "Waiting on
 * a third party". Each belongs to one of those three, which still decides what happens:
 * closing ends access and asks for a rating, waiting pauses the SLA clock. Customers see the
 * base status, unless a status is marked to show to customers.
 */
final class Helpdesk_Hero_Pro_Statuses {

	const OPTION = 'helpdesk_hero_pro_statuses';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'helpdesk_hero_hub_custom_statuses', array( __CLASS__, 'all' ) );
	}

	/**
	 * All custom statuses.
	 *
	 * @return array[] { id, label, color, base }
	 */
	public static function all() {
		$list = get_option( self::OPTION, array() );
		return is_array( $list ) ? array_values( $list ) : array();
	}

	/**
	 * Save the list. Tickets with a removed status keep their base status.
	 *
	 * @param array $list Statuses.
	 * @return array[]
	 */
	public static function save( array $list ) {
		global $wpdb;
		$clean = array();
		foreach ( $list as $s ) {
			$label = trim( sanitize_text_field( (string) ( $s['label'] ?? '' ) ) );
			$base  = (string) ( $s['base'] ?? '' );
			if ( '' === $label || ! in_array( $base, array( 'open', 'pending', 'closed' ), true ) ) {
				continue;
			}
			$id = sanitize_key( (string) ( $s['id'] ?? '' ) );
			$id = substr( '' !== $id ? $id : sanitize_title( $label ), 0, 40 );
			while ( '' === $id || isset( $clean[ $id ] ) || in_array( $id, array( 'open', 'pending', 'closed', 'active', 'all' ), true ) ) {
				$id = 'status-' . wp_rand( 100, 999 );
			}
			$color        = sanitize_hex_color( (string) ( $s['color'] ?? '' ) );
			$clean[ $id ] = array(
				'id'    => $id,
				'label' => substr( $label, 0, 40 ),
				'color'  => $color ? $color : '#6b6963',
				'base'   => $base,
				'public' => ! empty( $s['public'] ),
			);
		}
		$removed = array_diff( wp_list_pluck( self::all(), 'id' ), array_keys( $clean ) );
		update_option( self::OPTION, array_values( $clean ), false );
		foreach ( $removed as $id ) {
			$wpdb->update( Helpdesk_Hero_Hub_DB::table( 'tickets' ), array( 'custom_status' => '' ), array( 'custom_status' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}
		return self::all();
	}
}
