<?php
/**
 * Services, rates and retainers.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * What the team charges for.
 *
 * - Services (Maintenance, Bug fix, Custom work…) are priced per hour, at a fixed price per
 *   ticket, or included (covered by a retainer, never charged on its own).
 * - Hourly rates can be set per service, and overridden per customer tier and per site.
 *   The most specific wins: site, then tier, then service, then the default rate.
 * - A retainer gives a site a number of hours each month. Time on hourly and included
 *   services uses them up first; anything beyond is charged at the usual rate.
 * - The team sets a ticket's service. The customer's category can choose it automatically.
 *
 * Helpdesk Hero doesn't make invoices or take payments: it works out what's due and keeps
 * track of what was invoiced and paid, with your references.
 */
final class Helpdesk_Hero_Pro_Billing {

	const SETTINGS = 'helpdesk_hero_pro_billing';
	const SERVICES = 'helpdesk_hero_pro_services';
	const SITES    = 'helpdesk_hero_pro_site_billing';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'helpdesk_hero_hub_services', array( __CLASS__, 'service_labels' ) );
		add_filter( 'helpdesk_hero_hub_tier', array( __CLASS__, 'clean_tier' ), 10, 2 );
		add_action( 'helpdesk_hero_hub_ticket_created', array( __CLASS__, 'on_created' ), 6 );
		add_filter( 'helpdesk_hero_hub_site_usage', array( __CLASS__, 'usage' ), 10, 2 );
	}

	/**
	 * Hub filter: usage for a customer's site, when the Usage module is on.
	 *
	 * @param array|null $usage Usage.
	 * @param array      $site  Site.
	 * @return array|null
	 */
	public static function usage( $usage, $site ) {
		return Helpdesk_Hero_Pro_Modules::on( 'usage' ) ? Helpdesk_Hero_Pro_Time::usage( (int) $site['id'] ) : $usage;
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Settings.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Billing settings.
	 *
	 * @return array { currency, default_rate, time_mode: manual|auto|sessions, idle_minutes, rounding }
	 */
	public static function settings() {
		$s = get_option( self::SETTINGS, array() );
		$s = is_array( $s ) ? $s : array();
		return array(
			'currency'     => (string) ( $s['currency'] ?? 'EUR' ),
			'default_rate' => (float) ( $s['default_rate'] ?? 0 ),
			'time_mode'    => in_array( $s['time_mode'] ?? '', array( 'manual', 'auto', 'sessions' ), true ) ? $s['time_mode'] : 'auto',
			'idle_minutes' => max( 1, min( 60, (int) ( $s['idle_minutes'] ?? 5 ) ) ),
			'rounding'     => in_array( (int) ( $s['rounding'] ?? 0 ), array( 0, 5, 6, 10, 15, 30 ), true ) ? (int) $s['rounding'] : 0,
		);
	}

	/**
	 * Save billing settings.
	 *
	 * @param array $in Values.
	 * @return array
	 */
	public static function save_settings( array $in ) {
		$currency = strtoupper( preg_replace( '/[^A-Za-z]/', '', (string) ( $in['currency'] ?? 'EUR' ) ) );
		update_option(
			self::SETTINGS,
			array(
				'currency'     => 3 === strlen( $currency ) ? $currency : 'EUR',
				'default_rate' => max( 0, round( (float) ( $in['default_rate'] ?? 0 ), 2 ) ),
				'time_mode'    => in_array( $in['time_mode'] ?? '', array( 'manual', 'auto', 'sessions' ), true ) ? $in['time_mode'] : 'auto',
				'idle_minutes' => max( 1, min( 60, (int) ( $in['idle_minutes'] ?? 5 ) ) ),
				'rounding'     => in_array( (int) ( $in['rounding'] ?? 0 ), array( 0, 5, 6, 10, 15, 30 ), true ) ? (int) $in['rounding'] : 0,
			),
			false
		);
		return self::settings();
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Services.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Services, with a starting set agencies commonly offer.
	 *
	 * @return array[] { id, name, color, pricing: hourly|fixed|included, rate, price, billable, categories[] }
	 */
	public static function services() {
		$list = get_option( self::SERVICES, null );
		if ( null === $list ) {
			$defaults = array(
				array( 'maintenance', __( 'Maintenance', 'helpdesk-hero-pro' ), '#2a78d6', 'included' ),
				array( 'updates', __( 'Plugin and core updates', 'helpdesk-hero-pro' ), '#1baf7a', 'included' ),
				array( 'bug-fix', __( 'Bug fix', 'helpdesk-hero-pro' ), '#e34948', 'hourly' ),
				array( 'security', __( 'Security fix', 'helpdesk-hero-pro' ), '#eb6834', 'hourly' ),
				array( 'content', __( 'Content changes', 'helpdesk-hero-pro' ), '#e87ba4', 'hourly' ),
				array( 'custom-work', __( 'Custom work', 'helpdesk-hero-pro' ), '#4a3aa7', 'hourly' ),
				array( 'consulting', __( 'Advice and consulting', 'helpdesk-hero-pro' ), '#eda100', 'hourly' ),
			);
			$list     = array();
			foreach ( $defaults as $d ) {
				$list[] = array(
					'id'         => $d[0],
					'name'       => $d[1],
					'color'      => $d[2],
					'pricing'    => $d[3],
					'rate'       => 0,
					'price'      => 0,
					'billable'   => 'included' !== $d[3],
					'categories' => array(),
				);
			}
		}
		return is_array( $list ) ? array_values( $list ) : array();
	}

	/**
	 * One service.
	 *
	 * @param string $id ID.
	 * @return array|null
	 */
	public static function get_service( $id ) {
		foreach ( self::services() as $s ) {
			if ( $s['id'] === $id ) {
				return $s;
			}
		}
		return null;
	}

	/**
	 * Save services.
	 *
	 * @param array $list Services.
	 * @return array[]
	 */
	public static function save_services( array $list ) {
		$clean = array();
		foreach ( array_slice( $list, 0, 50 ) as $s ) {
			$name = trim( sanitize_text_field( (string) ( $s['name'] ?? '' ) ) );
			if ( '' === $name ) {
				continue;
			}
			$id = sanitize_key( (string) ( $s['id'] ?? '' ) );
			$id = substr( '' !== $id ? $id : sanitize_title( $name ), 0, 40 );
			while ( '' === $id || isset( $clean[ $id ] ) || 'none' === $id ) {
				$id = 'service-' . wp_rand( 100, 999 );
			}
			$pricing      = in_array( $s['pricing'] ?? '', array( 'hourly', 'fixed', 'included' ), true ) ? $s['pricing'] : 'hourly';
			$color        = sanitize_hex_color( (string) ( $s['color'] ?? '' ) );
			$clean[ $id ] = array(
				'id'         => $id,
				'name'       => substr( $name, 0, 60 ),
				'color'      => $color ? $color : '#6b6963',
				'pricing'    => $pricing,
				'rate'       => max( 0, round( (float) ( $s['rate'] ?? 0 ), 2 ) ),
				'price'      => max( 0, round( (float) ( $s['price'] ?? 0 ), 2 ) ),
				'billable'   => 'included' === $pricing ? false : ! empty( $s['billable'] ),
				'categories' => array_values( array_slice( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', (array) ( $s['categories'] ?? array() ) ) ) ), 0, 20 ) ),
			);
		}
		update_option( self::SERVICES, array_values( $clean ), false );
		return self::services();
	}

	/**
	 * Hub filter: service labels for tickets.
	 *
	 * @param array $list From the hub.
	 * @return array[]
	 */
	public static function service_labels( $list ) {
		foreach ( self::services() as $s ) {
			$list[] = array(
				'id'    => $s['id'],
				'name'  => $s['name'],
				'color' => $s['color'],
			);
		}
		return $list;
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Rates and retainers.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Keep a tier's hourly rate when tiers are saved.
	 *
	 * @param array $item Clean tier.
	 * @param array $raw  Tier as sent.
	 * @return array
	 */
	public static function clean_tier( $item, $raw ) {
		if ( isset( $raw['rate'] ) && '' !== (string) $raw['rate'] ) {
			$item['rate'] = max( 0, round( (float) $raw['rate'], 2 ) );
		}
		return $item;
	}

	/**
	 * Billing for each site: { site_id: { rate, retainer_hours, note } }.
	 *
	 * @return array
	 */
	public static function sites() {
		$s = get_option( self::SITES, array() );
		return is_array( $s ) ? $s : array();
	}

	/**
	 * One site's billing.
	 *
	 * @param int $site_id Site.
	 * @return array { rate (null = not set), retainer_hours, note }
	 */
	public static function site( $site_id ) {
		$all = self::sites();
		$row = (array) ( $all[ (int) $site_id ] ?? array() );
		return array(
			'rate'           => isset( $row['rate'] ) && '' !== (string) $row['rate'] ? (float) $row['rate'] : null,
			'retainer_hours' => (float) ( $row['retainer_hours'] ?? 0 ),
			'note'           => (string) ( $row['note'] ?? '' ),
		);
	}

	/**
	 * Save one site's billing.
	 *
	 * @param int   $site_id Site.
	 * @param array $in      rate ('' to use the tier's or service's), retainer_hours, note.
	 * @return array
	 */
	public static function save_site( $site_id, array $in ) {
		$all                    = self::sites();
		$all[ (int) $site_id ] = array(
			'rate'           => isset( $in['rate'] ) && '' !== (string) $in['rate'] ? max( 0, round( (float) $in['rate'], 2 ) ) : '',
			'retainer_hours' => max( 0, min( 1000, round( (float) ( $in['retainer_hours'] ?? 0 ), 2 ) ) ),
			'note'           => substr( sanitize_text_field( (string) ( $in['note'] ?? '' ) ), 0, 200 ),
		);
		update_option( self::SITES, $all, false );
		return self::site( $site_id );
	}

	/**
	 * The hourly rate for work on a site under a service: site, then tier, then service, then default.
	 *
	 * @param int    $site_id Site.
	 * @param string $service Service ID.
	 * @return float
	 */
	public static function rate( $site_id, $service ) {
		$site = self::site( $site_id );
		if ( null !== $site['rate'] ) {
			return $site['rate'];
		}
		$row  = Helpdesk_Hero_Hub::site( (int) $site_id );
		$tier = $row ? Helpdesk_Hero_Hub_Tiers::get( (string) $row['tier'] ) : null;
		if ( $tier && isset( $tier['rate'] ) && '' !== (string) $tier['rate'] && (float) $tier['rate'] > 0 ) {
			return (float) $tier['rate'];
		}
		$s = self::get_service( (string) $service );
		if ( $s && $s['rate'] > 0 ) {
			return (float) $s['rate'];
		}
		return self::settings()['default_rate'];
	}

	/**
	 * Price of time: what it costs before any retainer, and whether it counts toward one.
	 *
	 * @param int    $site_id  Site.
	 * @param string $service  Service.
	 * @param int    $minutes  Minutes.
	 * @param bool   $billable Billable.
	 * @return array { rate, amount, retainer: bool }
	 */
	public static function price( $site_id, $service, $minutes, $billable ) {
		$s       = self::get_service( (string) $service );
		$pricing = $s ? $s['pricing'] : 'hourly';
		if ( 'fixed' === $pricing ) {
			// The ticket's fixed price covers the time.
			return array(
				'rate'     => 0,
				'amount'   => 0,
				'retainer' => false,
			);
		}
		$rate = self::rate( $site_id, (string) $service );
		return array(
			'rate'     => $rate,
			'amount'   => $billable && 'included' !== $pricing ? round( $rate * $minutes / 60, 2 ) : 0,
			'retainer' => 'included' === $pricing || $billable,
		);
	}

	/**
	 * Round minutes up to the team's increment.
	 *
	 * @param int $minutes Minutes.
	 * @return int
	 */
	public static function round_minutes( $minutes ) {
		$step = self::settings()['rounding'];
		return $step ? (int) ( ceil( $minutes / $step ) * $step ) : (int) $minutes;
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Ticket service.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * A new ticket gets the service its category maps to.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_created( $ticket ) {
		if ( ! is_array( $ticket ) || '' === (string) $ticket['category'] ) {
			return;
		}
		foreach ( self::services() as $s ) {
			if ( in_array( $ticket['category'], $s['categories'], true ) ) {
				self::set_service( $ticket, $s['id'] );
				return;
			}
		}
	}

	/**
	 * Set a ticket's service (the team only). A fixed-price service adds its charge once.
	 *
	 * @param array  $ticket  Ticket.
	 * @param string $service Service ID ('' for none).
	 * @return true|WP_Error
	 */
	public static function set_service( array $ticket, $service ) {
		$service = (string) $service;
		if ( '' !== $service && ! self::get_service( $service ) ) {
			return new WP_Error( 'helpdesk_hero_pro_service', __( 'Unknown service.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
		}
		Helpdesk_Hero_Hub::update_ticket(
			(int) $ticket['id'],
			array(
				'service'    => $service,
				'updated_at' => $ticket['updated_at'],
			)
		);
		Helpdesk_Hero_Pro_Time::sync_fixed_charge( Helpdesk_Hero_Hub::ticket( (int) $ticket['id'] ) );
		Helpdesk_Hero_Pro_Time::reprice_ticket( (int) $ticket['id'] );
		/**
		 * Fires after a ticket's service changes (SLA targets follow).
		 *
		 * @param array $ticket Ticket (before the change).
		 */
		do_action( 'helpdesk_hero_pro_service_changed', $ticket );
		$s = self::get_service( $service );
		Helpdesk_Hero_Hub::log( $ticket, 'service', array( 'name' => $s ? $s['name'] : '' ) );
		return true;
	}

	/* ---------------------------------------------------------------------------------------- *
	 * Site sessions.
	 * ---------------------------------------------------------------------------------------- */

	/**
	 * Time support spent logged in to the customer's site, from its activity log: from each
	 * login to the logout, or to the last thing they did (sessions without activity count 5
	 * minutes). Sessions already logged are left out.
	 *
	 * @param array $ticket Ticket.
	 * @return array[]|WP_Error { key, start, minutes, by }
	 */
	public static function sessions( array $ticket ) {
		$result = Helpdesk_Hero_Hub::activity( $ticket );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$entries  = (array) ( $result['entries'] ?? array() );
		$sessions = array();
		$open     = null;
		foreach ( $entries as $e ) {
			$action = (string) ( $e['action'] ?? '' );
			$time   = strtotime( (string) ( $e['time'] ?? '' ) . ' UTC' );
			if ( ! $time ) {
				continue;
			}
			if ( 'support_login' === $action ) {
				if ( $open ) {
					$sessions[] = $open;
				}
				$open = array(
					'start' => $time,
					'end'   => $time,
					'by'    => (string) ( $e['by'] ?? '' ),
				);
				continue;
			}
			if ( $open ) {
				// A long silence ends the session.
				if ( $time - $open['end'] > HOUR_IN_SECONDS ) {
					$sessions[] = $open;
					$open       = null;
					continue;
				}
				$open['end'] = $time;
				if ( '' === $open['by'] && ! empty( $e['by'] ) ) {
					$open['by'] = (string) $e['by'];
				}
				if ( in_array( $action, array( 'support_logout', 'access_revoked', 'access_expired', 'access_ended_support', 'access_ended_closed' ), true ) ) {
					$sessions[] = $open;
					$open       = null;
				}
			}
		}
		if ( $open && time() - $open['end'] > 15 * MINUTE_IN_SECONDS ) {
			// Still open but idle: count it; a session in progress waits until it ends.
			$sessions[] = $open;
		}
		$logged = Helpdesk_Hero_Pro_Time::source_refs( (int) $ticket['id'] );
		$out    = array();
		foreach ( $sessions as $s ) {
			$key = 'session-' . $s['start'];
			if ( in_array( $key, $logged, true ) ) {
				continue;
			}
			$out[] = array(
				'key'     => $key,
				'start'   => gmdate( 'c', $s['start'] ),
				'minutes' => max( 5, (int) ceil( ( $s['end'] - $s['start'] ) / MINUTE_IN_SECONDS ) ),
				'by'      => $s['by'],
			);
		}
		return $out;
	}
}
