<?php
/**
 * Macros: saved replies.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Saved replies the team inserts with one click. A macro's text can use variables such as
 * {customer_first_name}; a macro can also set the ticket's status and add tags when the reply
 * is sent.
 */
final class Helpdesk_Hero_Pro_Macros {

	const OPTION = 'helpdesk_hero_pro_macros';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'helpdesk_hero_hub_reply_sent', array( __CLASS__, 'after_reply' ), 10, 2 );
	}

	/**
	 * Variables a macro can use, with descriptions.
	 *
	 * @return array<string, string>
	 */
	public static function variables() {
		return array(
			'customer_name'       => __( 'Customer’s name', 'helpdesk-hero-pro' ),
			'customer_first_name' => __( 'Customer’s first name', 'helpdesk-hero-pro' ),
			'site_name'           => __( 'Site name', 'helpdesk-hero-pro' ),
			'site_url'            => __( 'Site address', 'helpdesk-hero-pro' ),
			'ticket_id'           => __( 'Ticket number', 'helpdesk-hero-pro' ),
			'ticket_subject'      => __( 'Ticket subject', 'helpdesk-hero-pro' ),
			'agent_name'          => __( 'Your name', 'helpdesk-hero-pro' ),
			'team_name'           => __( 'Team name', 'helpdesk-hero-pro' ),
		);
	}

	/**
	 * All macros.
	 *
	 * @return array[] { id, name, body, status, tags }
	 */
	public static function all() {
		$list = get_option( self::OPTION, null );
		if ( null === $list ) {
			$list = array(
				array(
					'id'     => 'thanks-solved',
					'name'   => __( 'Solved, thanks', 'helpdesk-hero-pro' ),
					'body'   => __( "Hi {customer_first_name},\n\nGood news: this is fixed now. Have a look and let us know if anything still isn't right.\n\nThanks,\n{agent_name}", 'helpdesk-hero-pro' ),
					'status' => 'closed',
					'tags'   => array(),
				),
				array(
					'id'     => 'need-access',
					'name'   => __( 'Ask for site access', 'helpdesk-hero-pro' ),
					'body'   => __( "Hi {customer_first_name},\n\nTo look into this we need to log in to {site_name}. Could you give us access from your dashboard (Get Help › this ticket › Give access)? Nothing is shared but a one-time login, and you can end it at any time.\n\nThanks,\n{agent_name}", 'helpdesk-hero-pro' ),
					'status' => 'pending',
					'tags'   => array(),
				),
			);
		}
		return is_array( $list ) ? array_values( $list ) : array();
	}

	/**
	 * Save all macros.
	 *
	 * @param array $list Macros.
	 * @return array[]
	 */
	public static function save( array $list ) {
		$clean = array();
		$tags  = wp_list_pluck( Helpdesk_Hero_Hub_Tags::all(), 'id' );
		foreach ( $list as $m ) {
			$name = trim( sanitize_text_field( (string) ( $m['name'] ?? '' ) ) );
			$body = trim( sanitize_textarea_field( (string) ( $m['body'] ?? '' ) ) );
			if ( '' === $name || '' === $body ) {
				continue;
			}
			$id = sanitize_key( (string) ( $m['id'] ?? '' ) );
			$id = substr( '' !== $id ? $id : sanitize_title( $name ), 0, 40 );
			while ( isset( $clean[ $id ] ) || '' === $id ) {
				$id = 'macro-' . wp_rand( 100, 999 );
			}
			$clean[ $id ] = array(
				'id'     => $id,
				'name'   => substr( $name, 0, 60 ),
				'body'   => substr( $body, 0, 10000 ),
				'status' => in_array( $m['status'] ?? '', array( 'open', 'pending', 'closed' ), true ) ? $m['status'] : '',
				'tags'   => array_values( array_intersect( array_map( 'sanitize_key', (array) ( $m['tags'] ?? array() ) ), $tags ) ),
			);
		}
		update_option( self::OPTION, array_values( $clean ), false );
		return self::all();
	}

	/**
	 * After a reply sent with a macro: set the macro's status and add its tags.
	 *
	 * @param array           $ticket  Ticket (before the reply).
	 * @param WP_REST_Request $request Request.
	 */
	public static function after_reply( $ticket, $request ) {
		$id = sanitize_key( (string) $request->get_param( 'macro' ) );
		if ( '' === $id ) {
			return;
		}
		$macro = null;
		foreach ( self::all() as $m ) {
			if ( $m['id'] === $id ) {
				$macro = $m;
			}
		}
		if ( ! $macro ) {
			return;
		}
		$fresh = Helpdesk_Hero_Hub::ticket( (int) $ticket['id'] );
		if ( $fresh && $macro['tags'] ) {
			Helpdesk_Hero_Hub::set_tags( $fresh, array_unique( array_merge( (array) $fresh['tags'], $macro['tags'] ) ) );
			$fresh = Helpdesk_Hero_Hub::ticket( (int) $ticket['id'] );
		}
		if ( $fresh && $macro['status'] ) {
			Helpdesk_Hero_Hub::set_status( $fresh, $macro['status'] );
		}
	}
}
