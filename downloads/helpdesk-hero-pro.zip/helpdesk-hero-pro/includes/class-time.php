<?php
/**
 * Time and charges.
 *
 * @package Helpdesk_Hero_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Entries of time the team spent on tickets, and fixed charges for fixed-price services. Each
 * has a service, its rate and amount at the time it was logged, and a billing state:
 * unbilled → invoiced (with a reference such as an invoice number) → paid.
 */
final class Helpdesk_Hero_Pro_Time {

	const DB_VERSION = '2';
	const DB_OPTION  = 'helpdesk_hero_pro_time_db';
	const STATES     = array( 'unbilled', 'invoiced', 'paid' );

	/**
	 * Table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'helpdesk_hero_pro_time';
	}

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'maybe_install' ), 2 );
		add_action( 'helpdesk_hero_hub_ticket_deleted', array( __CLASS__, 'on_ticket_deleted' ) );
		add_filter( 'helpdesk_hero_hub_ticket_rows', array( __CLASS__, 'billing_states' ) );
		add_action( 'helpdesk_hero_hub_ticket_merged', array( __CLASS__, 'on_merged' ), 10, 2 );
	}

	/**
	 * Merged tickets: their time and charges move to the ticket that's kept, so billing and
	 * reports see one ticket.
	 *
	 * @param array $source Merged ticket.
	 * @param array $target Kept ticket.
	 */
	public static function on_merged( $source, $target ) {
		global $wpdb;
		if ( get_option( self::DB_OPTION ) === self::DB_VERSION ) {
			$wpdb->update( self::table(), array( 'ticket_id' => (int) $target['id'] ), array( 'ticket_id' => (int) $source['id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}
	}

	/**
	 * Billing state of each ticket, from its time and charges: unbilled if anything is still
	 * unbilled, else invoiced if anything awaits payment, else paid. No entries: no state.
	 *
	 * @param array[] $rows Ticket rows with an id.
	 * @return array[]
	 */
	public static function billing_states( $rows ) {
		global $wpdb;
		$ids = array_map( 'intval', wp_list_pluck( (array) $rows, 'id' ) );
		if ( ! $ids || get_option( self::DB_OPTION ) !== self::DB_VERSION ) {
			return $rows;
		}
		$in     = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$states = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT ticket_id, state FROM %i WHERE ticket_id IN ($in) AND billable = 1 GROUP BY ticket_id, state", array_merge( array( self::table() ), $ids ) ), ARRAY_A ) as $r ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$states[ (int) $r['ticket_id'] ][] = $r['state'];
		}
		foreach ( $rows as &$row ) {
			$list = $states[ (int) $row['id'] ] ?? array();
			if ( in_array( 'unbilled', $list, true ) ) {
				$row['billing'] = 'unbilled';
			} elseif ( in_array( 'invoiced', $list, true ) ) {
				$row['billing'] = 'invoiced';
			} elseif ( $list ) {
				$row['billing'] = 'paid';
			}
		}
		unset( $row );
		return $rows;
	}

	/**
	 * A ticket was deleted: its unbilled time goes too. Invoiced and paid entries stay, for the
	 * books.
	 *
	 * @param array $ticket Ticket.
	 */
	public static function on_ticket_deleted( $ticket ) {
		global $wpdb;
		if ( get_option( self::DB_OPTION ) === self::DB_VERSION ) {
			$wpdb->delete( self::table(), array( 'ticket_id' => (int) $ticket['id'], 'state' => 'unbilled' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		}
	}

	/**
	 * Create or upgrade the table when needed.
	 */
	public static function maybe_install() {
		if ( get_option( self::DB_OPTION ) === self::DB_VERSION ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta(
			'CREATE TABLE ' . self::table() . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			ticket_id bigint(20) unsigned NOT NULL DEFAULT 0,
			site_id bigint(20) unsigned NOT NULL DEFAULT 0,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			kind varchar(10) NOT NULL DEFAULT 'time',
			service varchar(40) NOT NULL DEFAULT '',
			minutes int(11) unsigned NOT NULL DEFAULT 0,
			billable tinyint(1) unsigned NOT NULL DEFAULT 1,
			rate decimal(10,2) NOT NULL DEFAULT 0,
			amount decimal(12,2) NOT NULL DEFAULT 0,
			state varchar(10) NOT NULL DEFAULT 'unbilled',
			invoice_ref varchar(64) NOT NULL DEFAULT '',
			billing_note varchar(255) NOT NULL DEFAULT '',
			source varchar(10) NOT NULL DEFAULT 'manual',
			source_ref varchar(40) NOT NULL DEFAULT '',
			note varchar(255) NOT NULL DEFAULT '',
			worked_on date NOT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NULL,
			PRIMARY KEY  (id),
			KEY ticket_id (ticket_id),
			KEY site_day (site_id,worked_on),
			KEY state (state)
			) " . $wpdb->get_charset_collate() . ';'
		);
		update_option( self::DB_OPTION, self::DB_VERSION, false );
	}

	/**
	 * A row.
	 *
	 * @param int $id ID.
	 * @return array|null
	 */
	public static function get( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', self::table(), $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $row ? $row : null;
	}

	/**
	 * Entry for the dashboard.
	 *
	 * @param array $row Row.
	 * @return array
	 */
	public static function json( array $row ) {
		$user    = get_userdata( (int) $row['user_id'] );
		$service = Helpdesk_Hero_Pro_Billing::get_service( (string) $row['service'] );
		return array(
			'id'           => (int) $row['id'],
			'ticket_id'    => (int) $row['ticket_id'],
			'site_id'      => (int) $row['site_id'],
			'kind'         => (string) $row['kind'],
			'service'      => (string) $row['service'],
			'service_name' => $service ? $service['name'] : '',
			'minutes'      => (int) $row['minutes'],
			'billable'     => (bool) $row['billable'],
			'rate'         => (float) $row['rate'],
			'amount'       => (float) $row['amount'],
			'state'        => (string) $row['state'],
			'invoice_ref'  => (string) $row['invoice_ref'],
			'billing_note' => (string) $row['billing_note'],
			'source'       => (string) $row['source'],
			'note'         => (string) $row['note'],
			'worked_on'    => (string) $row['worked_on'],
			'user'         => $user ? $user->display_name : '',
			'mine'         => (int) $row['user_id'] === get_current_user_id(),
		);
	}

	/**
	 * Entries for a ticket, newest first, with totals.
	 *
	 * @param int $ticket_id Ticket.
	 * @return array { entries, total, billable, amount, service, settings }
	 */
	public static function for_ticket( $ticket_id ) {
		global $wpdb;
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE ticket_id = %d ORDER BY worked_on DESC, id DESC', self::table(), $ticket_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$ticket = Helpdesk_Hero_Hub::ticket( (int) $ticket_id );
		$out    = array(
			'entries'  => array_map( array( __CLASS__, 'json' ), $rows ),
			'total'    => 0,
			'billable' => 0,
			'amount'   => 0,
			'service'  => $ticket ? (string) $ticket['service'] : '',
			'rate'     => $ticket ? Helpdesk_Hero_Pro_Billing::rate( (int) $ticket['site_id'], (string) $ticket['service'] ) : 0,
			'settings' => Helpdesk_Hero_Pro_Billing::settings(),
		);
		foreach ( $rows as $row ) {
			$out['total'] += (int) $row['minutes'];
			if ( $row['billable'] ) {
				$out['billable'] += (int) $row['minutes'];
			}
			$out['amount'] += (float) $row['amount'];
		}
		$out['amount'] = round( $out['amount'], 2 );
		return $out;
	}

	/**
	 * Sources already logged for a ticket (site sessions), so they aren't suggested twice.
	 *
	 * @param int $ticket_id Ticket.
	 * @return string[]
	 */
	public static function source_refs( $ticket_id ) {
		global $wpdb;
		return $wpdb->get_col( $wpdb->prepare( "SELECT source_ref FROM %i WHERE ticket_id = %d AND source_ref <> ''", self::table(), $ticket_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Add time to a ticket.
	 *
	 * @param array $ticket Ticket.
	 * @param array $in     minutes, billable, note, worked_on (Y-m-d), service, source, source_ref.
	 * @return array|WP_Error Entry.
	 */
	public static function add( array $ticket, array $in ) {
		global $wpdb;
		$minutes = Helpdesk_Hero_Pro_Billing::round_minutes( (int) ( $in['minutes'] ?? 0 ) );
		if ( $minutes < 1 || $minutes > 24 * 60 ) {
			return new WP_Error( 'helpdesk_hero_pro_time', __( 'Enter between 1 minute and 24 hours.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
		}
		$day = (string) ( $in['worked_on'] ?? '' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $day ) ) {
			$day = current_time( 'Y-m-d' );
		}
		$service = isset( $in['service'] ) && Helpdesk_Hero_Pro_Billing::get_service( (string) $in['service'] ) ? (string) $in['service'] : (string) $ticket['service'];
		$def     = Helpdesk_Hero_Pro_Billing::get_service( $service );
		$billable = array_key_exists( 'billable', $in ) ? ! empty( $in['billable'] ) : ( $def ? $def['billable'] : true );
		$price    = Helpdesk_Hero_Pro_Billing::price( (int) $ticket['site_id'], $service, $minutes, $billable );
		$source   = in_array( $in['source'] ?? '', array( 'manual', 'timer', 'auto', 'session' ), true ) ? $in['source'] : 'manual';
		$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			self::table(),
			array(
				'ticket_id'  => (int) $ticket['id'],
				'site_id'    => (int) $ticket['site_id'],
				'user_id'    => get_current_user_id(),
				'kind'       => 'time',
				'service'    => $service,
				'minutes'    => $minutes,
				'billable'   => $billable ? 1 : 0,
				'rate'       => $price['rate'],
				'amount'     => $price['amount'],
				'source'     => $source,
				'source_ref' => substr( sanitize_key( (string) ( $in['source_ref'] ?? '' ) ), 0, 40 ),
				'note'       => substr( sanitize_text_field( (string) ( $in['note'] ?? '' ) ), 0, 255 ),
				'worked_on'  => $day,
				'created_at' => gmdate( 'Y-m-d H:i:s' ),
			)
		);
		$row = self::get( (int) $wpdb->insert_id );
		if ( ! $row ) {
			return new WP_Error( 'helpdesk_hero_pro_time', __( 'The entry could not be saved.', 'helpdesk-hero-pro' ) );
		}
		self::changed( (int) $ticket['site_id'] );
		return self::json( $row );
	}

	/**
	 * Edit an entry: time, service, billable, note, date, billing state and reference.
	 * Rates are worked out again while the entry is unbilled.
	 *
	 * @param int   $id Entry.
	 * @param array $in Fields.
	 * @return array|WP_Error Entry.
	 */
	public static function update( $id, array $in ) {
		global $wpdb;
		$row = self::get( $id );
		if ( ! $row ) {
			return new WP_Error( 'helpdesk_hero_pro_time', __( 'Entry not found.', 'helpdesk-hero-pro' ), array( 'status' => 404 ) );
		}
		if ( (int) $row['user_id'] !== get_current_user_id() && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'helpdesk_hero_pro_time', __( 'You can only change your own entries.', 'helpdesk-hero-pro' ), array( 'status' => 403 ) );
		}
		$data = array();
		if ( isset( $in['minutes'] ) && 'time' === $row['kind'] ) {
			$m = (int) $in['minutes'];
			if ( $m < 1 || $m > 24 * 60 ) {
				return new WP_Error( 'helpdesk_hero_pro_time', __( 'Enter between 1 minute and 24 hours.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
			}
			$data['minutes'] = $m;
		}
		if ( isset( $in['service'] ) && ( '' === $in['service'] || Helpdesk_Hero_Pro_Billing::get_service( (string) $in['service'] ) ) ) {
			$data['service'] = (string) $in['service'];
		}
		if ( isset( $in['billable'] ) ) {
			$data['billable'] = ! empty( $in['billable'] ) ? 1 : 0;
		}
		if ( isset( $in['note'] ) ) {
			$data['note'] = substr( sanitize_text_field( (string) $in['note'] ), 0, 255 );
		}
		if ( isset( $in['worked_on'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $in['worked_on'] ) ) {
			$data['worked_on'] = $in['worked_on'];
		}
		if ( isset( $in['amount'] ) && 'charge' === $row['kind'] ) {
			$data['amount'] = max( 0, round( (float) $in['amount'], 2 ) );
		}
		if ( isset( $in['state'] ) && in_array( $in['state'], self::STATES, true ) ) {
			$data['state'] = $in['state'];
		}
		if ( isset( $in['invoice_ref'] ) ) {
			$data['invoice_ref'] = substr( sanitize_text_field( (string) $in['invoice_ref'] ), 0, 64 );
		}
		if ( isset( $in['billing_note'] ) ) {
			$data['billing_note'] = substr( sanitize_text_field( (string) $in['billing_note'] ), 0, 255 );
		}
		$merged = array_merge( $row, $data );
		if ( 'time' === $row['kind'] && 'unbilled' === $merged['state'] ) {
			$price          = Helpdesk_Hero_Pro_Billing::price( (int) $row['site_id'], (string) $merged['service'], (int) $merged['minutes'], (bool) $merged['billable'] );
			$data['rate']   = $price['rate'];
			$data['amount'] = $price['amount'];
		}
		$data['updated_at'] = gmdate( 'Y-m-d H:i:s' );
		$wpdb->update( self::table(), $data, array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		self::changed( (int) $row['site_id'] );
		return self::json( self::get( $id ) );
	}

	/**
	 * Set the billing state of many entries (for example: invoiced, reference #4444).
	 *
	 * @param int[]  $ids   Entries.
	 * @param string $state unbilled | invoiced | paid.
	 * @param string $ref   Invoice reference ('' keeps the current one).
	 * @param string $note  Note ('' keeps the current one).
	 * @return int Updated.
	 */
	public static function bulk_state( array $ids, $state, $ref = '', $note = '' ) {
		if ( ! in_array( $state, self::STATES, true ) ) {
			return 0;
		}
		$count = 0;
		foreach ( array_slice( array_map( 'absint', $ids ), 0, 2000 ) as $id ) {
			$in = array( 'state' => $state );
			if ( '' !== (string) $ref ) {
				$in['invoice_ref'] = $ref;
			}
			if ( '' !== (string) $note ) {
				$in['billing_note'] = $note;
			}
			if ( ! is_wp_error( self::update( $id, $in ) ) ) {
				++$count;
			}
		}
		return $count;
	}

	/**
	 * Delete an entry (your own, or any as an administrator). Paid entries stay.
	 *
	 * @param int $id Entry.
	 * @return true|WP_Error
	 */
	public static function delete( $id ) {
		global $wpdb;
		$row = self::get( $id );
		if ( ! $row ) {
			return new WP_Error( 'helpdesk_hero_pro_time', __( 'Entry not found.', 'helpdesk-hero-pro' ), array( 'status' => 404 ) );
		}
		if ( (int) $row['user_id'] !== get_current_user_id() && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'helpdesk_hero_pro_time', __( 'You can only delete your own entries.', 'helpdesk-hero-pro' ), array( 'status' => 403 ) );
		}
		if ( 'unbilled' !== $row['state'] ) {
			return new WP_Error( 'helpdesk_hero_pro_time', __( 'This entry was invoiced. Mark it unbilled first if you really want to delete it.', 'helpdesk-hero-pro' ), array( 'status' => 400 ) );
		}
		$wpdb->delete( self::table(), array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		self::changed( (int) $row['site_id'] );
		return true;
	}

	/**
	 * A ticket with a fixed-price service has one charge for it; changing the service replaces
	 * an unbilled charge (an invoiced one stays).
	 *
	 * @param array|null $ticket Ticket.
	 */
	public static function sync_fixed_charge( $ticket ) {
		global $wpdb;
		if ( ! $ticket ) {
			return;
		}
		$service = Helpdesk_Hero_Pro_Billing::get_service( (string) $ticket['service'] );
		$charges = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE ticket_id = %d AND kind = 'charge'", self::table(), $ticket['id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$keep    = false;
		foreach ( $charges as $c ) {
			if ( $service && 'fixed' === $service['pricing'] && $c['service'] === $service['id'] ) {
				$keep = true;
				continue;
			}
			if ( 'unbilled' === $c['state'] ) {
				$wpdb->delete( self::table(), array( 'id' => (int) $c['id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			}
		}
		if ( $service && 'fixed' === $service['pricing'] && ! $keep ) {
			$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				self::table(),
				array(
					'ticket_id'  => (int) $ticket['id'],
					'site_id'    => (int) $ticket['site_id'],
					'user_id'    => get_current_user_id(),
					'kind'       => 'charge',
					'service'    => $service['id'],
					'minutes'    => 0,
					'billable'   => 1,
					'rate'       => 0,
					'amount'     => (float) $service['price'],
					'source'     => 'fixed',
					/* translators: %s: service */
					'note'       => sprintf( __( 'Fixed price: %s', 'helpdesk-hero-pro' ), $service['name'] ),
					'worked_on'  => current_time( 'Y-m-d' ),
					'created_at' => gmdate( 'Y-m-d H:i:s' ),
				)
			);
		}
		self::changed( (int) $ticket['site_id'] );
	}

	/**
	 * A ticket's service changed: its unbilled time moves to the new service and is repriced.
	 *
	 * @param int $ticket_id Ticket.
	 */
	public static function reprice_ticket( $ticket_id ) {
		global $wpdb;
		$ticket = Helpdesk_Hero_Hub::ticket( (int) $ticket_id );
		if ( ! $ticket ) {
			return;
		}
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM %i WHERE ticket_id = %d AND kind = 'time' AND state = 'unbilled'", self::table(), $ticket_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		foreach ( $ids as $id ) {
			$row   = self::get( (int) $id );
			$def   = Helpdesk_Hero_Pro_Billing::get_service( (string) $ticket['service'] );
			$price = Helpdesk_Hero_Pro_Billing::price( (int) $row['site_id'], (string) $ticket['service'], (int) $row['minutes'], (bool) $row['billable'] );
			$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				self::table(),
				array(
					'service'  => (string) $ticket['service'],
					'billable' => $def && 'included' === $def['pricing'] ? 0 : (int) $row['billable'],
					'rate'     => $price['rate'],
					'amount'   => $price['amount'],
				),
				array( 'id' => (int) $id )
			);
		}
	}

	/**
	 * Entries for the Time & billing page.
	 *
	 * @param array $f from, to, site, service, user, state (unbilled|invoiced|paid|nonbillable), kind, search, page, per_page.
	 * @return array { entries, total, sums: { minutes, billable_minutes, amount } }
	 */
	public static function query( array $f ) {
		global $wpdb;
		$where  = array( 'e.worked_on BETWEEN %s AND %s' );
		$params = array(
			preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $f['from'] ?? '' ) ) ? $f['from'] : gmdate( 'Y-m-01' ),
			preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $f['to'] ?? '' ) ) ? $f['to'] : gmdate( 'Y-m-d' ),
		);
		if ( ! empty( $f['site'] ) ) {
			$where[]  = 'e.site_id = %d';
			$params[] = (int) $f['site'];
		}
		if ( isset( $f['service'] ) && '' !== (string) $f['service'] ) {
			$where[]  = 'e.service = %s';
			$params[] = 'none' === $f['service'] ? '' : (string) $f['service'];
		}
		if ( ! empty( $f['user'] ) ) {
			$where[]  = 'e.user_id = %d';
			$params[] = (int) $f['user'];
		}
		if ( ! empty( $f['kind'] ) && in_array( $f['kind'], array( 'time', 'charge' ), true ) ) {
			$where[]  = 'e.kind = %s';
			$params[] = $f['kind'];
		}
		if ( ! empty( $f['state'] ) ) {
			if ( 'nonbillable' === $f['state'] ) {
				$where[] = 'e.billable = 0';
			} elseif ( in_array( $f['state'], self::STATES, true ) ) {
				$where[]  = 'e.billable = 1 AND e.state = %s';
				$params[] = $f['state'];
			}
		}
		if ( ! empty( $f['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( (string) $f['search'] ) . '%';
			$where[]  = '(e.note LIKE %s OR e.invoice_ref LIKE %s OR e.billing_note LIKE %s OR t.subject LIKE %s)';
			$params   = array_merge( $params, array( $like, $like, $like, $like ) );
		}
		$sql_where = implode( ' AND ', $where );
		$tables    = array( self::table(), Helpdesk_Hero_Hub_DB::table( 'tickets' ) );
		// The WHERE clause is built only from fixed strings and placeholders.
		$sums     = $wpdb->get_row( $wpdb->prepare( 'SELECT COUNT(*) AS n, COALESCE(SUM(e.minutes),0) AS minutes, COALESCE(SUM(IF(e.billable = 1, e.minutes, 0)),0) AS billable_minutes, COALESCE(SUM(e.amount),0) AS amount FROM %i e LEFT JOIN %i t ON t.id = e.ticket_id WHERE ' . $sql_where, array_merge( $tables, $params ) ), ARRAY_A ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$per_page = max( 1, min( 500, (int) ( $f['per_page'] ?? 50 ) ) );
		$page     = max( 1, (int) ( $f['page'] ?? 1 ) );
		$rows     = $wpdb->get_results( $wpdb->prepare( 'SELECT e.*, t.subject FROM %i e LEFT JOIN %i t ON t.id = e.ticket_id WHERE ' . $sql_where . ' ORDER BY e.worked_on DESC, e.id DESC LIMIT %d OFFSET %d', array_merge( $tables, $params, array( $per_page, ( $page - 1 ) * $per_page ) ) ), ARRAY_A ); // phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$names    = array();
		foreach ( Helpdesk_Hero_Hub::sites() as $s ) {
			$names[ (int) $s['id'] ] = $s['name'] ? $s['name'] : $s['label'];
		}
		$entries = array();
		foreach ( $rows as $row ) {
			$entries[] = array_merge(
				self::json( $row ),
				array(
					'subject' => (string) $row['subject'],
					'site'    => $names[ (int) $row['site_id'] ] ?? __( 'Disconnected site', 'helpdesk-hero-pro' ),
				)
			);
		}
		return array(
			'entries'  => $entries,
			'currency' => Helpdesk_Hero_Pro_Billing::settings()['currency'],
			'total'    => (int) $sums['n'],
			'page'     => $page,
			'per_page' => $per_page,
			'sums'     => array(
				'minutes'          => (int) $sums['minutes'],
				'billable_minutes' => (int) $sums['billable_minutes'],
				'amount'           => round( (float) $sums['amount'], 2 ),
			),
		);
	}

	/**
	 * Totals per site for a period, with retainers applied.
	 *
	 * Time on hourly and included services uses a site's monthly retainer hours first, in the
	 * order it was logged; only time beyond them is charged. Fixed-price charges are always due.
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 * @param int    $site Site (0 = all).
	 * @return array { sites: [ { site_id, name, minutes, billable, retainer_hours, retainer_used, charged, due, invoiced, paid } ], due, minutes }
	 */
	public static function report( $from, $to, $site = 0 ) {
		global $wpdb;
		$from = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $from ) ? $from : gmdate( 'Y-m-01' );
		$to   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $to ) ? $to : gmdate( 'Y-m-d' );
		$rows = $site
			? $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE worked_on BETWEEN %s AND %s AND site_id = %d ORDER BY worked_on ASC, id ASC', self::table(), $from, $to, (int) $site ), ARRAY_A ) // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			: $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE worked_on BETWEEN %s AND %s ORDER BY worked_on ASC, id ASC', self::table(), $from, $to ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$names = array();
		foreach ( Helpdesk_Hero_Hub::sites() as $s ) {
			$names[ (int) $s['id'] ] = $s['name'] ? $s['name'] : $s['label'];
		}
		// Retainer hours are per month: a period spanning months gets each month's hours.
		$months = max( 1, ( (int) substr( $to, 0, 4 ) - (int) substr( $from, 0, 4 ) ) * 12 + (int) substr( $to, 5, 2 ) - (int) substr( $from, 5, 2 ) + 1 );
		$sites  = array();
		foreach ( $rows as $row ) {
			$sid = (int) $row['site_id'];
			if ( ! isset( $sites[ $sid ] ) ) {
				$billing       = Helpdesk_Hero_Pro_Billing::site( $sid );
				$sites[ $sid ] = array(
					'site_id'        => $sid,
					'name'           => $names[ $sid ] ?? __( 'Disconnected site', 'helpdesk-hero-pro' ),
					'minutes'        => 0,
					'billable'       => 0,
					'retainer_hours' => $billing['retainer_hours'] * $months,
					'retainer_used'  => 0,
					'charged'        => 0,
					'due'            => 0,
					'invoiced'       => 0,
					'paid'           => 0,
					'left'           => $billing['retainer_hours'] * $months * 60,
				);
			}
			$s           = &$sites[ $sid ];
			$s['minutes'] += (int) $row['minutes'];
			$service      = Helpdesk_Hero_Pro_Billing::get_service( (string) $row['service'] );
			$counts       = 'time' === $row['kind'] && ( $row['billable'] || ( $service && 'included' === $service['pricing'] ) );
			$amount       = (float) $row['amount'];
			if ( $row['billable'] ) {
				$s['billable'] += (int) $row['minutes'];
			}
			if ( $counts && $s['left'] > 0 ) {
				$covered            = min( $s['left'], (int) $row['minutes'] );
				$s['left']         -= $covered;
				$s['retainer_used'] += $covered;
				// Only the part beyond the retainer is charged.
				$amount = (int) $row['minutes'] ? $amount * ( (int) $row['minutes'] - $covered ) / (int) $row['minutes'] : $amount;
			}
			$s['charged'] += $amount;
			if ( 'paid' === $row['state'] ) {
				$s['paid'] += $amount;
			} elseif ( 'invoiced' === $row['state'] ) {
				$s['invoiced'] += $amount;
			} else {
				$s['due'] += $amount;
			}
			unset( $s );
		}
		foreach ( $sites as &$s ) {
			unset( $s['left'] );
			foreach ( array( 'charged', 'due', 'invoiced', 'paid' ) as $k ) {
				$s[ $k ] = round( $s[ $k ], 2 );
			}
		}
		unset( $s );
		usort(
			$sites,
			static function ( $a, $b ) {
				return $b['charged'] <=> $a['charged'] ?: $b['minutes'] <=> $a['minutes']; // phpcs:ignore Universal.Operators.DisallowShortTernary.Found
			}
		);
		return array(
			'from'     => $from,
			'to'       => $to,
			'currency' => Helpdesk_Hero_Pro_Billing::settings()['currency'],
			'sites'    => array_values( $sites ),
			'minutes'  => array_sum( array_column( $sites, 'minutes' ) ),
			'charged'  => round( array_sum( array_column( $sites, 'charged' ) ), 2 ),
			'due'      => round( array_sum( array_column( $sites, 'due' ) ), 2 ),
		);
	}

	/**
	 * What a customer sees about their account (Usage for customers): this month's time and
	 * retainer, the last 6 months, and each ticket's time and cost by billing state. Amounts are
	 * after the retainer. Non-billable time shows as time without a cost.
	 *
	 * @param int $site_id Site.
	 * @return array
	 */
	public static function usage( $site_id ) {
		global $wpdb;
		$billing = Helpdesk_Hero_Pro_Billing::site( $site_id );
		$from    = gmdate( 'Y-m-01', strtotime( current_time( 'Y-m-01' ) . ' -5 months' ) );
		$rows    = $wpdb->get_results( $wpdb->prepare( 'SELECT e.*, t.subject FROM %i e LEFT JOIN %i t ON t.id = e.ticket_id WHERE e.site_id = %d AND e.worked_on >= %s ORDER BY e.worked_on ASC, e.id ASC', self::table(), Helpdesk_Hero_Hub_DB::table( 'tickets' ), $site_id, $from ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$months  = array();
		$items   = array();
		$tickets = array();
		foreach ( $rows as $row ) {
			$month = substr( (string) $row['worked_on'], 0, 7 );
			if ( ! isset( $months[ $month ] ) ) {
				$months[ $month ] = array(
					'month'          => $month,
					'minutes'        => 0,
					'retainer_hours' => $billing['retainer_hours'],
					'retainer_used'  => 0,
					'charged'        => 0,
					'due'            => 0,
					'invoiced'       => 0,
					'paid'           => 0,
					'left'           => $billing['retainer_hours'] * 60,
				);
			}
			$m        = &$months[ $month ];
			$service  = Helpdesk_Hero_Pro_Billing::get_service( (string) $row['service'] );
			$counts   = 'time' === $row['kind'] && ( $row['billable'] || ( $service && 'included' === $service['pricing'] ) );
			$amount   = (float) $row['amount'];
			$m['minutes'] += (int) $row['minutes'];
			if ( $counts && $m['left'] > 0 ) {
				$covered            = min( $m['left'], (int) $row['minutes'] );
				$m['left']         -= $covered;
				$m['retainer_used'] += $covered;
				$amount = (int) $row['minutes'] ? $amount * ( (int) $row['minutes'] - $covered ) / (int) $row['minutes'] : $amount;
			}
			$state = (string) $row['state'];
			$m['charged'] += $amount;
			$m[ 'unbilled' === $state ? 'due' : $state ] += $amount;
			unset( $m );

			$tid             = (int) $row['ticket_id'];
			$tickets[ $tid ] = ( $tickets[ $tid ] ?? 0 ) + (int) $row['minutes'];
			$key             = $tid . '|' . $month . '|' . $state . '|' . $row['service'] . '|' . $row['invoice_ref'];
			if ( ! isset( $items[ $key ] ) ) {
				$items[ $key ] = array(
					'hub_ticket_id' => $tid,
					'subject'       => (string) $row['subject'],
					'month'         => $month,
					'service'       => $service ? $service['name'] : '',
					'minutes'       => 0,
					'amount'        => 0,
					'state'         => $row['billable'] || 'charge' === $row['kind'] ? $state : 'free',
					'invoice_ref'   => (string) $row['invoice_ref'],
				);
			}
			$items[ $key ]['minutes'] += (int) $row['minutes'];
			$items[ $key ]['amount']  += $amount;
		}
		foreach ( $months as &$m ) {
			unset( $m['left'] );
			foreach ( array( 'charged', 'due', 'invoiced', 'paid' ) as $k ) {
				$m[ $k ] = round( $m[ $k ], 2 );
			}
		}
		unset( $m );
		foreach ( $items as &$i ) {
			$i['amount'] = round( $i['amount'], 2 );
		}
		unset( $i );
		$this_month = current_time( 'Y-m' );
		$current    = $months[ $this_month ] ?? array(
			'retainer_used' => 0,
			'minutes'       => 0,
		);
		return array(
			'currency'       => Helpdesk_Hero_Pro_Billing::settings()['currency'],
			'month'          => $this_month,
			'retainer_hours' => $billing['retainer_hours'],
			'used_minutes'   => (int) $current['retainer_used'],
			'month_minutes'  => (int) $current['minutes'],
			'tickets'        => (object) $tickets,
			'months'         => array_reverse( array_values( $months ) ),
			'items'          => array_slice( array_reverse( array_values( $items ) ), 0, 300 ),
			'due'            => round( array_sum( array_column( $months, 'due' ) ), 2 ),
			'invoiced'       => round( array_sum( array_column( $months, 'invoiced' ) ), 2 ),
		);
	}

	/**
	 * Something changed for a site: tell it its usage, if customers see usage. At most once a
	 * minute per site; the regular sync catches up.
	 *
	 * @param int $site_id Site.
	 */
	private static function changed( $site_id ) {
		if ( ! Helpdesk_Hero_Pro_Modules::on( 'usage' ) || get_transient( 'helpdesk_hero_pro_usage_' . $site_id ) ) {
			return;
		}
		set_transient( 'helpdesk_hero_pro_usage_' . $site_id, 1, MINUTE_IN_SECONDS );
		Helpdesk_Hero_Hub_Policy::push( (int) $site_id );
	}
}
