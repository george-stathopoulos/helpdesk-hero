/**
 * Saved replies (macros) and Slack and webhook notifications.
 */
import { __, sprintf } from '@wordpress/i18n';
import { useState, useEffect } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { useApi, send } from './ui/lib/hooks';
import {
	Card,
	Button,
	Loading,
	useToast,
} from './ui/components/ui';
import {
	TextField,
	TextArea,
	SelectField,
	Check,
	CopyBox,
	confirmAction,
} from './ui/components/kit';

const hub = window.hdhBoot || {};

/**
 * GET from the hub's own REST API (helpdesk-hero-hub/v1).
 *
 * @param {string} path Path.
 * @return {any} Data, or null while loading.
 */
export function useHubData( path ) {
	const [ data, setData ] = useState( null );
	useEffect( () => {
		apiFetch( { path: `/helpdesk-hero-hub/v1/${ path }` } )
			.then( setData )
			.catch( () => setData( null ) );
	}, [ path ] );
	return data;
}

export function errorText( e ) {
	return (
		( e && e.message ) || __( 'Something went wrong.', 'helpdesk-hero-pro' )
	);
}

const STATUS_OPTIONS = [
	{ value: '', label: __( 'Don’t change', 'helpdesk-hero-pro' ) },
	{ value: 'open', label: __( 'Open', 'helpdesk-hero-pro' ) },
	{
		value: 'pending',
		label: __( 'Waiting on customer', 'helpdesk-hero-pro' ),
	},
	{ value: 'closed', label: __( 'Closed', 'helpdesk-hero-pro' ) },
];

/* ------------------------------------------------------------------ Macros */

export function MacrosCard() {
	const { data, reload } = useApi( 'macros' );
	const tagData = useHubData( 'admin/tags' );
	const [ list, setList ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setList( data.macros );
		}
	}, [ data ] );
	if ( ! data || ! list ) {
		return <Loading />;
	}
	const hubTags = tagData ? tagData.tags : [];
	const dirty = JSON.stringify( list ) !== JSON.stringify( data.macros );
	const set = ( i, patch ) =>
		setList( list.map( ( m, n ) => ( n === i ? { ...m, ...patch } : m ) ) );
	const save = () => {
		setBusy( true );
		send( 'macros', 'POST', { macros: list } )
			.then( () => {
				toast( __( 'Saved replies saved', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	return (
		<Card
			title={ __( 'Saved replies', 'helpdesk-hero-pro' ) }
			sub={ __(
				'Replies your team inserts with one click. They can also change the status and add tags when the reply is sent.',
				'helpdesk-hero-pro'
			) }
		>
			<div className="hdh-stack" style={ { gap: 14 } }>
				<p className="hdh-muted" style={ { margin: 0 } }>
					{ __( 'Variables:', 'helpdesk-hero-pro' ) }{ ' ' }
					{ Object.keys( data.variables ).map( ( v ) => (
						<code
							key={ v }
							title={ data.variables[ v ] }
							style={ { marginRight: 6 } }
						>
							{ `{${ v }}` }
						</code>
					) ) }
				</p>
				{ list.map( ( m, i ) => (
					<details
						key={ m.id || `new-${ i }` }
						className="hdh-tier-edit"
						open={ ! m.id }
					>
						<summary style={ { cursor: 'pointer' } }>
							<strong>
								{ m.name || __( 'New saved reply', 'helpdesk-hero-pro' ) }
							</strong>
							{ m.status && (
								<span className="hdh-muted">
									{ ' · ' }
									{
										STATUS_OPTIONS.find(
											( o ) => o.value === m.status
										)?.label
									}
								</span>
							) }
						</summary>
						<div className="hdh-stack" style={ { marginTop: 10 } }>
							<TextField
								label={ __( 'Name', 'helpdesk-hero-pro' ) }
								value={ m.name }
								maxLength={ 60 }
								onChange={ ( v ) => set( i, { name: v } ) }
							/>
							<TextArea
								formatting
								label={ __( 'Reply', 'helpdesk-hero-pro' ) }
								value={ m.body }
								rows={ 6 }
								onChange={ ( v ) => set( i, { body: v } ) }
							/>
							<SelectField
								label={ __(
									'After sending, set the status to',
									'helpdesk-hero-pro'
								) }
								value={ m.status || '' }
								onChange={ ( v ) => set( i, { status: v } ) }
								options={ STATUS_OPTIONS }
							/>
							{ hubTags.length > 0 && (
								<fieldset className="hdh-field">
									<legend className="hdh-field__label">
										{ __( 'Add tags', 'helpdesk-hero-pro' ) }
									</legend>
									<div className="hdh-row" style={ { gap: 6 } }>
										{ hubTags.map( ( t ) => {
											const on = ( m.tags || [] ).includes(
												t.id
											);
											return (
												<button
													key={ t.id }
													type="button"
													className={ `hdh-tagpill is-toggle ${
														on ? 'is-on' : ''
													}` }
													style={ { '--tag': t.color } }
													aria-pressed={ on }
													onClick={ () =>
														set( i, {
															tags: on
																? m.tags.filter(
																		( x ) =>
																			x !== t.id
																  )
																: [
																		...( m.tags ||
																			[] ),
																		t.id,
																  ],
														} )
													}
												>
													{ t.name }
												</button>
											);
										} ) }
									</div>
								</fieldset>
							) }
							<div>
								<Button
									size="sm"
									variant="ghost"
									icon="trash"
									onClick={ () =>
										setList(
											list.filter( ( _, n ) => n !== i )
										)
									}
								>
									{ __( 'Delete saved reply', 'helpdesk-hero-pro' ) }
								</Button>
							</div>
						</div>
					</details>
				) ) }
				<div className="hdh-row">
					<Button
						size="sm"
						icon="plus"
						onClick={ () =>
							setList( [
								...list,
								{
									id: '',
									name: '',
									body: '',
									status: '',
									tags: [],
								},
							] )
						}
					>
						{ __( 'Add saved reply', 'helpdesk-hero-pro' ) }
					</Button>
					{ dirty && (
						<Button
							size="sm"
							variant="primary"
							disabled={ busy }
							onClick={ save }
						>
							{ __( 'Save replies', 'helpdesk-hero-pro' ) }
						</Button>
					) }
				</div>
			</div>
		</Card>
	);
}

/**
 * Fill a macro's variables for a ticket.
 *
 * @param {string} text   Macro text.
 * @param {Object} ticket Ticket from the hub.
 * @return {string} Text.
 */
function fill( text, ticket ) {
	const name = ( ticket.customer && ticket.customer.name ) || '';
	const values = {
		customer_name: name,
		customer_first_name: name.split( /\s+/ )[ 0 ] || name,
		site_name: ticket.site ? ticket.site.name : '',
		site_url: ticket.site ? ticket.site.url : '',
		ticket_id: String( ticket.id ),
		ticket_subject: ticket.subject,
		agent_name: hub.userName || '',
		team_name: hub.teamName || '',
	};
	return text.replace( /\{([a-z_]+)\}/g, ( all, key ) =>
		key in values ? values[ key ] : all
	);
}

/**
 * Reply tool: insert a macro.
 *
 * @param {Object} props Props from the hub's reply box.
 * @return {JSX.Element|null} Tool.
 */
export function MacroTool( { ticket, body, setBody, extra, setExtra } ) {
	const { data } = useApi( 'macros' );
	if ( ! data || ! data.macros.length ) {
		return null;
	}
	const current = extra && extra.macro;
	const chosen = data.macros.find( ( m ) => m.id === current );
	return (
		<div className="hdh-row">
			<select
				className="hdh-input hdh-select"
				aria-label={ __( 'Insert a saved reply', 'helpdesk-hero-pro' ) }
				value=""
				onChange={ async ( e ) => {
					const macro = data.macros.find(
						( m ) => m.id === e.target.value
					);
					if ( ! macro ) {
						return;
					}
					if (
						body.trim() &&
						! ( await confirmAction(
							__(
								'Replace what you’ve written with this saved reply?',
								'helpdesk-hero-pro'
							),
							{
								confirmText: __( 'Replace', 'helpdesk-hero-pro' ),
							}
						) )
					) {
						return;
					}
					setBody( fill( macro.body, ticket ) );
					setExtra( { ...extra, macro: macro.id } );
				} }
			>
				<option value="">
					{ __( 'Insert a saved reply…', 'helpdesk-hero-pro' ) }
				</option>
				{ data.macros.map( ( m ) => (
					<option key={ m.id } value={ m.id }>
						{ m.name }
					</option>
				) ) }
			</select>
			{ chosen && ( chosen.status || chosen.tags.length > 0 ) && (
				<span className="hdh-muted">
					{ sprintf(
						/* translators: %s: macro name */
						__(
							'“%s” also sets the status or tags when you send.',
							'helpdesk-hero-pro'
						),
						chosen.name
					) }{ ' ' }
					<button
						type="button"
						className="hdh-link-button"
						onClick={ () => {
							const next = { ...extra };
							delete next.macro;
							setExtra( next );
						} }
					>
						{ __( 'Don’t', 'helpdesk-hero-pro' ) }
					</button>
				</span>
			) }
		</div>
	);
}

/* ------------------------------------------------------------------ Notifications */

export function NotifyCard() {
	const { data, reload } = useApi( 'notify' );
	const [ draft, setDraft ] = useState( null );
	const [ slack, setSlack ] = useState( '' );
	const [ busy, setBusy ] = useState( '' );
	const [ secrets, setSecrets ] = useState( [] );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setDraft( data.settings );
			setSlack( '' );
		}
	}, [ data ] );
	if ( ! data || ! draft ) {
		return <Loading />;
	}
	const events = data.events;
	const toggleEvent = ( list, ev, on ) =>
		on ? [ ...list, ev ] : list.filter( ( x ) => x !== ev );
	const save = () => {
		setBusy( 'save' );
		const body = {
			slack_events: draft.slack_events,
			webhooks: draft.webhooks.map( ( w ) => ( {
				id: w.id,
				url: w.url,
				events: w.events,
			} ) ),
		};
		if ( slack.trim() || draft.slack_remove ) {
			body.slack_url = draft.slack_remove ? '' : slack.trim();
		}
		send( 'notify', 'POST', body )
			.then( ( r ) => {
				setSecrets(
					( r.settings.webhooks || [] )
						.filter( ( w ) => w.secret_new )
						.map( ( w ) => ( { url: w.url, secret: w.secret_new } ) )
				);
				toast( __( 'Notifications saved', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( '' ) );
	};
	const test = () => {
		setBusy( 'test' );
		send( 'notify/test', 'POST' )
			.then( () =>
				toast( __( 'Test sent', 'helpdesk-hero-pro' ) )
			)
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( '' ) );
	};
	return (
		<Card
			title={ __( 'Slack and webhooks', 'helpdesk-hero-pro' ) }
			sub={ __(
				'Tell your team’s chat or other tools when something happens. Only the ticket number, subject, status, priority, customer name, site and a link are sent; never diagnostics or messages.',
				'helpdesk-hero-pro'
			) }
		>
			<div className="hdh-stack" style={ { gap: 16 } }>
				<div className="hdh-stack" style={ { gap: 8 } }>
					<div className="hdh-section-title">Slack</div>
					{ draft.slack_set && ! draft.slack_remove ? (
						<div className="hdh-row">
							<code>{ draft.slack_url }</code>
							<Button
								size="sm"
								variant="ghost"
								onClick={ () =>
									setDraft( { ...draft, slack_remove: true } )
								}
							>
								{ __( 'Remove', 'helpdesk-hero-pro' ) }
							</Button>
						</div>
					) : (
						<TextField
							label={ __(
								'Incoming webhook address',
								'helpdesk-hero-pro'
							) }
							placeholder="https://hooks.slack.com/services/…"
							value={ slack }
							onChange={ ( v ) => {
								setSlack( v );
								setDraft( { ...draft, slack_remove: false } );
							} }
							help={ __(
								'In Slack: Apps › Incoming Webhooks › Add to a channel, then copy the address. It’s stored encrypted.',
								'helpdesk-hero-pro'
							) }
						/>
					) }
					<div className="hdh-row" style={ { gap: 12 } }>
						{ Object.keys( events ).map( ( ev ) => (
							<Check
								key={ ev }
								label={ events[ ev ] }
								checked={ draft.slack_events.includes( ev ) }
								onChange={ ( on ) =>
									setDraft( {
										...draft,
										slack_events: toggleEvent(
											draft.slack_events,
											ev,
											on
										),
									} )
								}
							/>
						) ) }
					</div>
				</div>

				<div className="hdh-stack" style={ { gap: 8 } }>
					<div className="hdh-section-title">
						{ __( 'Webhooks', 'helpdesk-hero-pro' ) }
					</div>
					<p className="hdh-muted" style={ { margin: 0 } }>
						{ __(
							'JSON sent to your address (HTTPS only) for Microsoft Teams workflows, Discord, Zapier, Make or your own code. Each request has an X-Helpdesk-Hero-Signature header: an HMAC-SHA256 of the body with the webhook’s secret.',
							'helpdesk-hero-pro'
						) }
					</p>
					{ draft.webhooks.map( ( w, i ) => (
						<div key={ w.id || `new-${ i }` } className="hdh-tier-edit">
							<div className="hdh-row">
								<input
									className="hdh-input"
									style={ { flex: 1 } }
									aria-label={ __(
										'Webhook address',
										'helpdesk-hero-pro'
									) }
									placeholder="https://…"
									value={ w.url }
									onChange={ ( e ) =>
										setDraft( {
											...draft,
											webhooks: draft.webhooks.map(
												( x, n ) =>
													n === i
														? { ...x, url: e.target.value }
														: x
											),
										} )
									}
								/>
								{ w.secret_hint && (
									<span className="hdh-muted">
										{ sprintf(
											/* translators: %s: last characters of the secret */
											__( 'Secret %s', 'helpdesk-hero-pro' ),
											w.secret_hint
										) }
									</span>
								) }
								<Button
									size="sm"
									variant="ghost"
									icon="trash"
									aria-label={ __(
										'Remove webhook',
										'helpdesk-hero-pro'
									) }
									onClick={ () =>
										setDraft( {
											...draft,
											webhooks: draft.webhooks.filter(
												( _, n ) => n !== i
											),
										} )
									}
								/>
							</div>
							<div className="hdh-row" style={ { gap: 12 } }>
								{ Object.keys( events ).map( ( ev ) => (
									<Check
										key={ ev }
										label={ events[ ev ] }
										checked={ ( w.events || [] ).includes( ev ) }
										onChange={ ( on ) =>
											setDraft( {
												...draft,
												webhooks: draft.webhooks.map(
													( x, n ) =>
														n === i
															? {
																	...x,
																	events: toggleEvent(
																		x.events || [],
																		ev,
																		on
																	),
															  }
															: x
												),
											} )
										}
									/>
								) ) }
							</div>
						</div>
					) ) }
					<div>
						<Button
							size="sm"
							icon="plus"
							onClick={ () =>
								setDraft( {
									...draft,
									webhooks: [
										...draft.webhooks,
										{
											id: '',
											url: '',
											events: Object.keys( events ),
										},
									],
								} )
							}
						>
							{ __( 'Add webhook', 'helpdesk-hero-pro' ) }
						</Button>
					</div>
				</div>

				{ secrets.map( ( s ) => (
					<div key={ s.url } className="hdh-stack" style={ { gap: 6 } }>
						<strong>
							{ sprintf(
								/* translators: %s: webhook address */
								__(
									'Signing secret for %s (shown once, copy it now):',
									'helpdesk-hero-pro'
								),
								s.url
							) }
						</strong>
						<CopyBox value={ s.secret } rows={ 1 } />
					</div>
				) ) }

				<div className="hdh-row">
					<Button
						variant="primary"
						disabled={ !! busy }
						onClick={ save }
					>
						{ __( 'Save notifications', 'helpdesk-hero-pro' ) }
					</Button>
					<Button disabled={ !! busy } onClick={ test }>
						{ __( 'Send a test', 'helpdesk-hero-pro' ) }
					</Button>
				</div>
			</div>
		</Card>
	);
}

