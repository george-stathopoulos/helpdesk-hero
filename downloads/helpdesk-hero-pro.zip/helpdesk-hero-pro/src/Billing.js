/**
 * Services and billing settings, a tier's hourly rate, and a site's rate and retainer.
 */
import { __, sprintf } from '@wordpress/i18n';
import { useState, useEffect } from '@wordpress/element';
import { useApi, send } from './ui/lib/hooks';
import { Card, Button, Loading, useToast } from './ui/components/ui';
import { TextField, SelectField, Check } from './ui/components/kit';
import { errorText } from './Workflow';

/**
 * Money in the team's currency.
 *
 * @param {number} amount   Amount.
 * @param {string} currency ISO code.
 * @return {string} Formatted.
 */
export function money( amount, currency ) {
	try {
		return new Intl.NumberFormat( undefined, {
			style: 'currency',
			currency: currency || 'EUR',
		} ).format( amount || 0 );
	} catch ( e ) {
		return `${ ( amount || 0 ).toFixed( 2 ) } ${ currency || '' }`;
	}
}

const MODES = [
	{
		value: 'auto',
		label: __( 'Automatic, with idle detection', 'helpdesk-hero-pro' ),
		desc: __(
			'The timer starts when you work on a ticket (typing a reply or note, logging in to the site) and pauses when the tab is hidden or you’re idle. When you leave, it asks you to log the time.',
			'helpdesk-hero-pro'
		),
	},
	{
		value: 'sessions',
		label: __( 'From site sessions', 'helpdesk-hero-pro' ),
		desc: __(
			'Each support login on the customer’s site becomes a suggested entry, from login to logout or the last thing done. You confirm each one.',
			'helpdesk-hero-pro'
		),
	},
	{
		value: 'manual',
		label: __( 'Manual', 'helpdesk-hero-pro' ),
		desc: __(
			'Add time yourself, or use the start/stop timer on the ticket.',
			'helpdesk-hero-pro'
		),
	},
];

const PRICING = [
	{ value: 'hourly', label: __( 'Per hour', 'helpdesk-hero-pro' ) },
	{ value: 'fixed', label: __( 'Fixed price per ticket', 'helpdesk-hero-pro' ) },
	{
		value: 'included',
		label: __( 'Included (retainer)', 'helpdesk-hero-pro' ),
	},
];

export function BillingSettings() {
	const { data, reload } = useApi( 'billing' );
	const [ draft, setDraft ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setDraft( { settings: data.settings, services: data.services } );
		}
	}, [ data ] );
	if ( ! data || ! draft ) {
		return <Loading />;
	}
	const s = draft.settings;
	const dirty =
		JSON.stringify( draft ) !==
		JSON.stringify( { settings: data.settings, services: data.services } );
	const setS = ( patch ) =>
		setDraft( { ...draft, settings: { ...s, ...patch } } );
	const setSvc = ( i, patch ) =>
		setDraft( {
			...draft,
			services: draft.services.map( ( x, n ) =>
				n === i ? { ...x, ...patch } : x
			),
		} );
	const save = () => {
		setBusy( true );
		send( 'billing', 'POST', draft )
			.then( () => {
				toast( __( 'Billing saved', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	return (
		<>
			<Card
				title={ __( 'Time tracking', 'helpdesk-hero-pro' ) }
				sub={ __(
					'How time is recorded. Nothing is logged without someone confirming it.',
					'helpdesk-hero-pro'
				) }
			>
				<div className="hdh-stack" style={ { gap: 10 } }>
					{ MODES.map( ( m ) => (
						<label key={ m.value } className="hdh-choice">
							<input
								type="radio"
								name="hdh-time-mode"
								checked={ s.time_mode === m.value }
								onChange={ () => setS( { time_mode: m.value } ) }
							/>
							<span>
								<strong>{ m.label }</strong>
								<span className="hdh-muted">{ m.desc }</span>
							</span>
						</label>
					) ) }
					<div className="hdh-row" style={ { gap: 16 } }>
						{ s.time_mode === 'auto' && (
							<label className="hdh-inline-field" htmlFor="hdh-idle">
								<span>
									{ __( 'Pause after', 'helpdesk-hero-pro' ) }
								</span>
								<input
									id="hdh-idle"
									type="number"
									min="1"
									max="60"
									className="hdh-input"
									style={ { width: 64 } }
									value={ s.idle_minutes }
									onChange={ ( e ) =>
										setS( {
											idle_minutes:
												parseInt( e.target.value, 10 ) || '',
										} )
									}
								/>
								<span>
									{ __( 'idle minutes', 'helpdesk-hero-pro' ) }
								</span>
							</label>
						) }
						<label className="hdh-inline-field" htmlFor="hdh-rounding">
							<span>{ __( 'Round entries up to', 'helpdesk-hero-pro' ) }</span>
							<select
								id="hdh-rounding"
								className="hdh-input hdh-select"
								value={ String( s.rounding ) }
								onChange={ ( e ) =>
									setS( { rounding: parseInt( e.target.value, 10 ) } )
								}
							>
								{ [ 0, 5, 6, 10, 15, 30 ].map( ( n ) => (
									<option key={ n } value={ String( n ) }>
										{ n
											? sprintf(
													/* translators: %d: minutes */
													__( '%d minutes', 'helpdesk-hero-pro' ),
													n
											  )
											: __( 'No rounding', 'helpdesk-hero-pro' ) }
									</option>
								) ) }
							</select>
						</label>
					</div>
				</div>
			</Card>

			<Card
				title={ __( 'Rates', 'helpdesk-hero-pro' ) }
				sub={ __(
					'The default hourly rate applies when a service, tier or site has none. Rates are taken when time is logged; later changes don’t alter logged time once it’s invoiced.',
					'helpdesk-hero-pro'
				) }
			>
				<div className="hdh-row" style={ { gap: 16 } }>
					<TextField
						label={ __( 'Currency', 'helpdesk-hero-pro' ) }
						value={ s.currency }
						maxLength={ 3 }
						onChange={ ( v ) => setS( { currency: v.toUpperCase() } ) }
						help={ __( 'For example EUR, USD, GBP.', 'helpdesk-hero-pro' ) }
					/>
					<TextField
						label={ __( 'Default hourly rate', 'helpdesk-hero-pro' ) }
						type="number"
						min="0"
						step="0.01"
						value={ s.default_rate }
						onChange={ ( v ) =>
							setS( { default_rate: parseFloat( v ) || 0 } )
						}
					/>
				</div>
			</Card>

			<Card
				title={ __( 'Services', 'helpdesk-hero-pro' ) }
				sub={ __(
					'What you do for customers. Your team chooses a ticket’s service; a customer’s category can choose it automatically.',
					'helpdesk-hero-pro'
				) }
			>
				<div className="hdh-stack" style={ { gap: 12 } }>
					{ draft.services.map( ( x, i ) => (
						<div key={ x.id || `new-${ i }` } className="hdh-tier-edit">
							<div className="hdh-row">
								<input
									type="color"
									aria-label={ __( 'Colour', 'helpdesk-hero-pro' ) }
									value={ x.color || '#6b6963' }
									onChange={ ( e ) =>
										setSvc( i, { color: e.target.value } )
									}
									style={ {
										width: 36,
										height: 30,
										border: 0,
										background: 'none',
									} }
								/>
								<input
									className="hdh-input"
									style={ { flex: 1, minWidth: 160 } }
									aria-label={ __(
										'Service name',
										'helpdesk-hero-pro'
									) }
									value={ x.name }
									maxLength={ 60 }
									onChange={ ( e ) =>
										setSvc( i, { name: e.target.value } )
									}
								/>
								<SelectField
									label={ __( 'Pricing', 'helpdesk-hero-pro' ) }
									hideLabel
									value={ x.pricing }
									onChange={ ( v ) => setSvc( i, { pricing: v } ) }
									options={ PRICING }
								/>
								{ x.pricing === 'hourly' && (
									<input
										className="hdh-input"
										type="number"
										min="0"
										step="0.01"
										style={ { width: 110 } }
										aria-label={ __(
											'Hourly rate',
											'helpdesk-hero-pro'
										) }
										placeholder={ __(
											'Rate / h',
											'helpdesk-hero-pro'
										) }
										value={ x.rate || '' }
										onChange={ ( e ) =>
											setSvc( i, {
												rate: parseFloat( e.target.value ) || 0,
											} )
										}
									/>
								) }
								{ x.pricing === 'fixed' && (
									<input
										className="hdh-input"
										type="number"
										min="0"
										step="0.01"
										style={ { width: 110 } }
										aria-label={ __( 'Price', 'helpdesk-hero-pro' ) }
										placeholder={ __( 'Price', 'helpdesk-hero-pro' ) }
										value={ x.price || '' }
										onChange={ ( e ) =>
											setSvc( i, {
												price: parseFloat( e.target.value ) || 0,
											} )
										}
									/>
								) }
								<Button
									size="sm"
									variant="ghost"
									icon="trash"
									aria-label={ __(
										'Delete service',
										'helpdesk-hero-pro'
									) }
									onClick={ () =>
										setDraft( {
											...draft,
											services: draft.services.filter(
												( _, n ) => n !== i
											),
										} )
									}
								/>
							</div>
							<div className="hdh-row" style={ { gap: 12 } }>
								{ x.pricing === 'hourly' && (
									<Check
										label={ __(
											'Billable by default',
											'helpdesk-hero-pro'
										) }
										checked={ !! x.billable }
										onChange={ ( on ) =>
											setSvc( i, { billable: on } )
										}
									/>
								) }
								{ data.categories.length > 0 && (
									<span className="hdh-row" style={ { gap: 6 } }>
										<span className="hdh-muted">
											{ __(
												'Used for categories:',
												'helpdesk-hero-pro'
											) }
										</span>
										{ data.categories.map( ( c ) => {
											const on = ( x.categories || [] ).includes(
												c
											);
											return (
												<button
													key={ c }
													type="button"
													className={ `hdh-tagpill is-toggle ${
														on ? 'is-on' : ''
													}` }
													aria-pressed={ on }
													onClick={ () =>
														setSvc( i, {
															categories: on
																? x.categories.filter(
																		( y ) => y !== c
																  )
																: [
																		...( x.categories ||
																			[] ),
																		c,
																  ],
														} )
													}
												>
													{ c }
												</button>
											);
										} ) }
									</span>
								) }
							</div>
						</div>
					) ) }
					<div>
						<Button
							size="sm"
							icon="plus"
							onClick={ () =>
								setDraft( {
									...draft,
									services: [
										...draft.services,
										{
											id: '',
											name: '',
											color: '#2a78d6',
											pricing: 'hourly',
											rate: 0,
											price: 0,
											billable: true,
											categories: [],
										},
									],
								} )
							}
						>
							{ __( 'Add service', 'helpdesk-hero-pro' ) }
						</Button>
					</div>
				</div>
			</Card>
			{ dirty && (
				<div>
					<Button variant="primary" disabled={ busy } onClick={ save }>
						{ __( 'Save billing', 'helpdesk-hero-pro' ) }
					</Button>
				</div>
			) }
		</>
	);
}

/**
 * Hourly rate on a customer tier (Settings › Customer tiers).
 *
 * @param {Object}   props          Props.
 * @param {Object}   props.tier     Tier.
 * @param {Function} props.onChange Patch.
 * @return {JSX.Element} Field.
 */
export function TierRateField( { tier, onChange } ) {
	return (
		<label className="hdh-inline-field" htmlFor={ `tier-rate-${ tier.id || 'new' }` }>
			<span>{ __( 'Hourly rate for this tier', 'helpdesk-hero-pro' ) }</span>
			<input
				id={ `tier-rate-${ tier.id || 'new' }` }
				className="hdh-input"
				type="number"
				min="0"
				step="0.01"
				style={ { width: 100 } }
				placeholder="—"
				value={ tier.rate ?? '' }
				onChange={ ( e ) =>
					onChange( {
						rate: e.target.value === '' ? '' : parseFloat( e.target.value ),
					} )
				}
			/>
		</label>
	);
}

/**
 * A site's hourly rate and monthly retainer (in the site drawer).
 *
 * @param {Object} props      Props.
 * @param {Object} props.site Site.
 * @return {JSX.Element|null} Card.
 */
export function SiteBillingPanel( { site } ) {
	const { data, reload } = useApi( `billing/site/${ site.id }` );
	const [ draft, setDraft ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setDraft( {
				rate: data.rate === null ? '' : data.rate,
				retainer_hours: data.retainer_hours,
				note: data.note,
			} );
		}
	}, [ data ] );
	if ( ! data || ! draft ) {
		return null;
	}
	const canManage = ( window.hdhBoot || {} ).canManage;
	const used = data.usage ? data.usage.used_minutes / 60 : 0;
	const save = () => {
		setBusy( true );
		send( `billing/site/${ site.id }`, 'POST', draft )
			.then( () => {
				toast( __( 'Billing saved', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	return (
		<div className="hdh-card hdh-stack" style={ { padding: 16 } }>
			<div className="hdh-section-title">
				{ __( 'Billing', 'helpdesk-hero-pro' ) }
			</div>
			{ data.retainer_hours > 0 && (
				<p style={ { margin: 0 } }>
					{ sprintf(
						/* translators: 1: hours used, 2: hours included */
						__(
							'This month: %1$s of %2$s retainer hours used.',
							'helpdesk-hero-pro'
						),
						used.toFixed( 1 ),
						data.retainer_hours
					) }
				</p>
			) }
			{ canManage ? (
				<>
					<div className="hdh-row" style={ { gap: 12 } }>
						<TextField
							label={ __( 'Hourly rate for this site', 'helpdesk-hero-pro' ) }
							type="number"
							min="0"
							step="0.01"
							value={ draft.rate }
							placeholder="—"
							onChange={ ( v ) => setDraft( { ...draft, rate: v } ) }
							help={ sprintf(
								/* translators: %s: rate */
								__(
									'Empty: the tier’s, service’s or default rate (now %s).',
									'helpdesk-hero-pro'
								),
								money( data.effective_rate, data.currency )
							) }
						/>
						<TextField
							label={ __( 'Retainer hours per month', 'helpdesk-hero-pro' ) }
							type="number"
							min="0"
							step="0.5"
							value={ draft.retainer_hours }
							onChange={ ( v ) =>
								setDraft( {
									...draft,
									retainer_hours: parseFloat( v ) || 0,
								} )
							}
							help={ __(
								'Time on hourly and included services uses these first.',
								'helpdesk-hero-pro'
							) }
						/>
					</div>
					<TextField
						label={ __( 'Billing note', 'helpdesk-hero-pro' ) }
						value={ draft.note }
						maxLength={ 200 }
						onChange={ ( v ) => setDraft( { ...draft, note: v } ) }
						placeholder={ __(
							'For example: invoice to accounts@…',
							'helpdesk-hero-pro'
						) }
					/>
					<div>
						<Button size="sm" variant="primary" disabled={ busy } onClick={ save }>
							{ __( 'Save billing', 'helpdesk-hero-pro' ) }
						</Button>
					</div>
				</>
			) : (
				data.note && <p className="hdh-muted">{ data.note }</p>
			) }
		</div>
	);
}
