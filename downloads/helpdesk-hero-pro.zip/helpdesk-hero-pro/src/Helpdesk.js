import { __ } from '@wordpress/i18n';
import { useState, useEffect } from '@wordpress/element';
import { useApi, send } from './ui/lib/hooks';
import {
	Card,
	PageHead,
	Button,
	ErrorNotice,
	Loading,
	useToast,
} from './ui/components/ui';
import { TextField, SelectField } from './ui/components/kit';
import { SaveBar } from './ui/lib/settings';
import Icon from './ui/components/Icon';

const CHOICES = [
	{
		key: 'none',
		icon: 'mail',
		title: __( 'Hub inbox and email', 'helpdesk-hero-pro' ),
		text: __(
			'New tickets and replies are emailed to your team; you answer here in the Inbox.',
			'helpdesk-hero-pro'
		),
	},
	{
		key: 'helpscout',
		icon: 'inbox',
		title: 'Help Scout',
		text: __(
			'Tickets become conversations in a mailbox; replies sync both ways.',
			'helpdesk-hero-pro'
		),
	},
	{
		key: 'zendesk',
		icon: 'inbox',
		title: 'Zendesk',
		text: __(
			'Tickets become Zendesk tickets; public replies sync both ways.',
			'helpdesk-hero-pro'
		),
	},
];

export default function Helpdesk() {
	const { data, error, reload } = useApi( 'helpdesk' );
	const [ draft, setDraft ] = useState( null );
	const [ secrets, setSecrets ] = useState( {
		helpscout_app_secret: '',
		zendesk_token: '',
	} );
	const [ saving, setSaving ] = useState( false );
	const [ test, setTest ] = useState( null );
	const [ testing, setTesting ] = useState( false );
	const toast = useToast();

	useEffect( () => {
		if ( data ) {
			setDraft( data.settings );
			setSecrets( { helpscout_app_secret: '', zendesk_token: '' } );
		}
	}, [ data ] );

	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ reload } />;
	}
	if ( ! data || ! draft ) {
		return <Loading />;
	}
	const set = ( k ) => ( v ) => setDraft( ( d ) => ( { ...d, [ k ]: v } ) );
	const dirty =
		JSON.stringify( draft ) !== JSON.stringify( data.settings ) ||
		secrets.helpscout_app_secret ||
		secrets.zendesk_token;

	const save = () => {
		setSaving( true );
		return send( 'helpdesk', 'POST', { ...draft, ...secrets } )
			.then( () => {
				toast( __( 'Help desk settings saved', 'helpdesk-hero-pro' ) );
				setTest( null );
				reload();
			} )
			.catch( ( e ) =>
				toast(
					( e && e.message ) ||
						__( 'Something went wrong.', 'helpdesk-hero-pro' ),
					'alert'
				)
			)
			.finally( () => setSaving( false ) );
	};

	const runTest = () => {
		setTesting( true );
		send( 'helpdesk/test', 'POST' )
			.then( setTest )
			.catch( ( e ) =>
				setTest( {
					ok: false,
					message:
						( e && e.message ) ||
						__( 'Something went wrong.', 'helpdesk-hero-pro' ),
				} )
			)
			.finally( () => setTesting( false ) );
	};

	const savedType = data.settings.helpdesk;

	return (
		<>
			<PageHead
				title={ __( 'Help desk', 'helpdesk-hero-pro' ) }
				lede={ __(
					'Where tickets go. Help desk keys stay on this site; customer sites never see them.',
					'helpdesk-hero-pro'
				) }
			/>
			<div className="hdh-choices" style={ { marginBottom: 18 } }>
				{ CHOICES.map( ( c ) => (
					<button
						key={ c.key }
						type="button"
						className={ `hdh-choice ${
							draft.helpdesk === c.key ? 'is-active' : ''
						}` }
						aria-pressed={ draft.helpdesk === c.key }
						onClick={ () => set( 'helpdesk' )( c.key ) }
					>
						<Icon name={ c.icon } size={ 22 } />
						<strong>{ c.title }</strong>
						<span>{ c.text }</span>
					</button>
				) ) }
			</div>

			{ draft.helpdesk === 'helpscout' && (
				<Card
					title="Help Scout"
					sub={ __(
						'Create an app in Help Scout under Your profile › My Apps › Create My App (any redirect URL works).',
						'helpdesk-hero-pro'
					) }
				>
					<div className="hdh-form-grid">
						<TextField
							label={ __( 'App ID', 'helpdesk-hero-pro' ) }
							value={ draft.helpscout_app_id }
							onChange={ set( 'helpscout_app_id' ) }
							autoComplete="off"
						/>
						<TextField
							label={ __( 'App Secret', 'helpdesk-hero-pro' ) }
							type="password"
							autoComplete="new-password"
							value={ secrets.helpscout_app_secret }
							placeholder={
								data.secrets.helpscout_app_secret
									? __(
											'Saved — leave empty to keep',
											'helpdesk-hero-pro'
									  )
									: ''
							}
							onChange={ ( v ) =>
								setSecrets( ( s ) => ( {
									...s,
									helpscout_app_secret: v,
								} ) )
							}
						/>
						{ test && test.mailboxes ? (
							<SelectField
								label={ __( 'Mailbox', 'helpdesk-hero-pro' ) }
								value={ draft.helpscout_mailbox }
								onChange={ set( 'helpscout_mailbox' ) }
								options={ [
									{
										value: '',
										label: __(
											'Choose a mailbox',
											'helpdesk-hero-pro'
										),
									},
									...test.mailboxes.map( ( m ) => ( {
										value: m.id,
										label: m.name,
									} ) ),
								] }
							/>
						) : (
							<TextField
								label={ __(
									'Mailbox ID',
									'helpdesk-hero-pro'
								) }
								value={ draft.helpscout_mailbox }
								onChange={ set( 'helpscout_mailbox' ) }
								help={ __(
									'Save and test the connection to pick from your mailboxes.',
									'helpdesk-hero-pro'
								) }
							/>
						) }
					</div>
				</Card>
			) }

			{ draft.helpdesk === 'zendesk' && (
				<Card
					title="Zendesk"
					sub={ __(
						'Admin Center › Apps and integrations › Zendesk API › Add API token. Use an agent’s email address.',
						'helpdesk-hero-pro'
					) }
				>
					<div className="hdh-form-grid">
						<TextField
							label={ __( 'Subdomain', 'helpdesk-hero-pro' ) }
							value={ draft.zendesk_subdomain }
							onChange={ set( 'zendesk_subdomain' ) }
							help="yourcompany.zendesk.com → yourcompany"
						/>
						<TextField
							label={ __( 'Agent email', 'helpdesk-hero-pro' ) }
							type="email"
							value={ draft.zendesk_email }
							onChange={ set( 'zendesk_email' ) }
						/>
						<TextField
							label={ __( 'API token', 'helpdesk-hero-pro' ) }
							type="password"
							autoComplete="new-password"
							value={ secrets.zendesk_token }
							placeholder={
								data.secrets.zendesk_token
									? __(
											'Saved — leave empty to keep',
											'helpdesk-hero-pro'
									  )
									: ''
							}
							onChange={ ( v ) =>
								setSecrets( ( s ) => ( {
									...s,
									zendesk_token: v,
								} ) )
							}
						/>
					</div>
				</Card>
			) }

			{ savedType !== 'none' && draft.helpdesk === savedType && (
				<Card>
					<div className="hdh-row">
						<Button
							icon="plug"
							onClick={ runTest }
							disabled={ testing || dirty }
						>
							{ testing
								? __( 'Testing…', 'helpdesk-hero-pro' )
								: __( 'Test connection', 'helpdesk-hero-pro' ) }
						</Button>
						{ dirty && (
							<span className="hdh-muted">
								{ __(
									'Save your changes first.',
									'helpdesk-hero-pro'
								) }
							</span>
						) }
						{ test && (
							<span
								className="hdh-row"
								style={ {
									color: test.ok
										? 'var(--hdh-good-ink)'
										: 'var(--hdh-critical-ink)',
								} }
							>
								<Icon
									name={ test.ok ? 'check' : 'alert' }
									size={ 15 }
								/>
								{ test.message }
							</span>
						) }
					</div>
				</Card>
			) }

			<SaveBar
				dirty={ !! dirty }
				saving={ saving }
				save={ save }
				discard={ () => {
					setDraft( data.settings );
					setSecrets( {
						helpscout_app_secret: '',
						zendesk_token: '',
					} );
				} }
			/>
		</>
	);
}
