/**
 * Inbox views: saved filters and sort as tabs above the Inbox, with live counts.
 */
import { __, sprintf } from '@wordpress/i18n';
import { useState } from '@wordpress/element';
import { useApi, send } from './ui/lib/hooks';
import { Button, useToast } from './ui/components/ui';
import { confirmAction } from './ui/components/kit';
import { errorText } from './Workflow';

const hub = window.hdhBoot || {};

/**
 * The filters that matter for comparing (no empty values, status defaults to active).
 *
 * @param {Object} f Filters.
 * @return {string} Key.
 */
function key( f ) {
	const clean = { status: 'active', ...f };
	return JSON.stringify(
		Object.keys( clean )
			.filter( ( k ) => clean[ k ] !== '' && clean[ k ] !== undefined )
			.sort()
			.map( ( k ) => [ k, String( clean[ k ] ) ] )
	);
}

export function ViewsBar( { filters, sort, apply } ) {
	const { data, reload } = useApi( 'views' );
	const [ saving, setSaving ] = useState( false );
	const [ name, setName ] = useState( '' );
	const [ scope, setScope ] = useState( 'personal' );
	const toast = useToast();
	if ( ! data ) {
		return null;
	}
	const all = [
		...data.personal.map( ( v ) => ( { ...v, scope: 'personal' } ) ),
		...data.shared.map( ( v ) => ( { ...v, scope: 'shared' } ) ),
	];
	const current = all.find( ( v ) => key( v.filters ) === key( filters ) );
	const save = () => {
		send( 'views', 'POST', {
			scope,
			view: { name, filters, sort },
		} )
			.then( () => {
				toast( __( 'View saved', 'helpdesk-hero-pro' ) );
				setSaving( false );
				setName( '' );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) );
	};
	const update = () =>
		send( 'views', 'POST', {
			scope: current.scope,
			view: { ...current, filters, sort },
		} )
			.then( () => {
				toast( __( 'View updated', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) );
	const remove = async () => {
		if (
			! ( await confirmAction(
				sprintf(
					/* translators: %s: view */
					__( 'Delete the view “%s”? The tickets aren’t affected.', 'helpdesk-hero-pro' ),
					current.name
				),
				{ confirmText: __( 'Delete', 'helpdesk-hero-pro' ) }
			) )
		) {
			return;
		}
		send( `views/${ current.scope }/${ current.id }`, 'DELETE' )
			.then( () => {
				apply( { status: 'active' }, null );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) );
	};
	const canEdit = current && ( current.scope === 'personal' || hub.canManage );
	return (
		<div className="hdh-views">
			<div className="hdh-views__list" role="toolbar" aria-label={ __( 'Views', 'helpdesk-hero-pro' ) }>
				<button
					type="button"
					className={ `hdh-view ${ key( filters ) === key( {} ) ? 'is-active' : '' }` }
					onClick={ () => apply( { status: 'active' }, null ) }
				>
					{ __( 'All active', 'helpdesk-hero-pro' ) }
				</button>
				{ all.map( ( v ) => (
					<button
						key={ `${ v.scope }-${ v.id }` }
						type="button"
						className={ `hdh-view ${ current && current.id === v.id && current.scope === v.scope ? 'is-active' : '' }` }
						title={ v.scope === 'shared' ? __( 'Shared with the team', 'helpdesk-hero-pro' ) : __( 'Only you see this view', 'helpdesk-hero-pro' ) }
						onClick={ () => apply( v.filters, v.sort ) }
					>
						{ v.name }
						<span className="hdh-view__count">{ v.count }</span>
					</button>
				) ) }
			</div>
			<div className="hdh-views__actions">
				{ ! saving && (
					<Button
						size="sm"
						variant="ghost"
						icon="plus"
						onClick={ () => {
							if ( key( filters ) === key( {} ) ) {
								toast(
									__(
										'A view saves the filters and sort you choose. Pick them first (Filters button, status tabs, sort), then click New view.',
										'helpdesk-hero-pro'
									),
									'info',
									{ duration: 7000 }
								);
								return;
							}
							setSaving( true );
						} }
					>
						{ current
							? __( 'New view from these filters', 'helpdesk-hero-pro' )
							: __( 'New view', 'helpdesk-hero-pro' ) }
					</Button>
				) }
				{ canEdit && (
					<>
						<Button size="sm" variant="ghost" onClick={ update }>
							{ __( 'Save sort', 'helpdesk-hero-pro' ) }
						</Button>
						<Button size="sm" variant="ghost" icon="trash" onClick={ remove }>
							{ __( 'Delete view', 'helpdesk-hero-pro' ) }
						</Button>
					</>
				) }
				{ saving && (
					<span className="hdh-row" style={ { gap: 6 } }>
						<input
							className="hdh-input"
							style={ { width: 180 } }
							aria-label={ __( 'View name', 'helpdesk-hero-pro' ) }
							placeholder={ __( 'For example: My VIP tickets', 'helpdesk-hero-pro' ) }
							value={ name }
							maxLength={ 40 }
							// eslint-disable-next-line jsx-a11y/no-autofocus
							autoFocus
							onChange={ ( e ) => setName( e.target.value ) }
							onKeyDown={ ( e ) => e.key === 'Enter' && name.trim() && save() }
						/>
						<select
							className="hdh-input hdh-select"
							aria-label={ __( 'Who sees it', 'helpdesk-hero-pro' ) }
							value={ scope }
							onChange={ ( e ) => setScope( e.target.value ) }
						>
							<option value="personal">{ __( 'Just me', 'helpdesk-hero-pro' ) }</option>
							{ hub.canManage && (
								<option value="shared">{ __( 'Whole team', 'helpdesk-hero-pro' ) }</option>
							) }
						</select>
						<Button size="sm" variant="primary" disabled={ ! name.trim() } onClick={ save }>
							{ __( 'Save', 'helpdesk-hero-pro' ) }
						</Button>
						<Button size="sm" variant="ghost" onClick={ () => setSaving( false ) }>
							{ __( 'Cancel', 'helpdesk-hero-pro' ) }
						</Button>
					</span>
				) }
			</div>
		</div>
	);
}
