/**
 * Service levels: SLA targets per customer tier (on the tier editor in Settings), business
 * hours and the default targets (Workflow), and custom statuses (Workflow).
 */
import { __, sprintf } from '@wordpress/i18n';
import { useState, useEffect } from '@wordpress/element';
import { useApi, send } from './ui/lib/hooks';
import { Card, Button, Loading, useToast } from './ui/components/ui';
import { Check, SelectField } from './ui/components/kit';
import { errorText } from './Workflow';

/**
 * Minutes as hours for inputs ("" for none).
 *
 * @param {number} minutes Minutes.
 * @return {string} Hours.
 */
function toHours( minutes ) {
	return minutes ? String( Math.round( ( minutes / 60 ) * 100 ) / 100 ) : '';
}

function toMinutes( hours ) {
	const h = parseFloat( String( hours ).replace( ',', '.' ) );
	return h > 0 ? Math.round( h * 60 ) : 0;
}

const DAYS = [
	[ 1, __( 'Mon', 'helpdesk-hero-pro' ) ],
	[ 2, __( 'Tue', 'helpdesk-hero-pro' ) ],
	[ 3, __( 'Wed', 'helpdesk-hero-pro' ) ],
	[ 4, __( 'Thu', 'helpdesk-hero-pro' ) ],
	[ 5, __( 'Fri', 'helpdesk-hero-pro' ) ],
	[ 6, __( 'Sat', 'helpdesk-hero-pro' ) ],
	[ 7, __( 'Sun', 'helpdesk-hero-pro' ) ],
];

/**
 * Hours input that keeps what's typed ("1.5", "0.25") and reports minutes.
 *
 * @param {Object}   props          Props.
 * @param {number}   props.minutes  Minutes.
 * @param {Function} props.onChange ( minutes ) => void.
 * @param {string}   props.label    Accessible label.
 * @return {JSX.Element} Input.
 */
function HoursInput( { minutes, onChange, label } ) {
	const [ text, setText ] = useState( toHours( minutes ) );
	useEffect( () => {
		// Follow outside changes, but not while the typed text already means this value.
		if ( toMinutes( text ) !== ( minutes || 0 ) ) {
			setText( toHours( minutes ) );
		}
	}, [ minutes ] ); // eslint-disable-line react-hooks/exhaustive-deps
	return (
		<input
			className="hdh-input"
			style={ { width: 90 } }
			inputMode="decimal"
			placeholder="—"
			aria-label={ label }
			value={ text }
			onChange={ ( e ) => {
				setText( e.target.value );
				onChange( toMinutes( e.target.value ) );
			} }
		/>
	);
}

function PolicySelect( { value, onChange, policies, label, emptyLabel } ) {
	return (
		<select
			className="hdh-input hdh-select"
			aria-label={ label }
			value={ value || '' }
			onChange={ ( e ) => onChange( e.target.value ) }
		>
			<option value="">{ emptyLabel }</option>
			{ policies.map( ( p ) => (
				<option key={ p.id || p.name } value={ p.id }>
					{ p.name }
				</option>
			) ) }
		</select>
	);
}

export function SlaCard() {
	const { data, reload } = useApi( 'sla' );
	const [ draft, setDraft ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setDraft( data.settings );
		}
	}, [ data ] );
	if ( ! data || ! draft ) {
		return <Loading />;
	}
	const dirty = JSON.stringify( draft ) !== JSON.stringify( data.settings );
	const hours = draft.hours;
	const setHours = ( patch ) =>
		setDraft( { ...draft, hours: { ...hours, ...patch } } );
	const setPolicy = ( i, patch ) =>
		setDraft( {
			...draft,
			policies: draft.policies.map( ( p, n ) =>
				n === i ? { ...p, ...patch } : p
			),
		} );
	// New policies get an ID from their name, so they can be assigned before saving.
	const named = draft.policies
		.filter( ( p ) => p.name.trim() )
		.map( ( p ) => ( {
			...p,
			id:
				p.id ||
				p.name
					.trim()
					.toLowerCase()
					.replace( /[^a-z0-9]+/g, '-' )
					.replace( /^-|-$/g, '' ),
		} ) );
	const save = () => {
		setBusy( true );
		send( 'sla', 'POST', { ...draft, policies: named } )
			.then( () => {
				toast(
					__(
						'Saved. Open tickets were recalculated.',
						'helpdesk-hero-pro'
					)
				);
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	const assign = ( map, key, value ) => {
		const next = { ...draft[ map ] };
		if ( value ) {
			next[ key ] = value;
		} else {
			delete next[ key ];
		}
		setDraft( { ...draft, [ map ]: next } );
	};
	const ownSites = Object.keys( draft.sites );
	return (
		<>
			<Card
				title={ __( 'SLA policies', 'helpdesk-hero-pro' ) }
				sub={ __(
					'Targets for the first reply and for resolution, for example “VIP: reply in 1 hour, resolve in 8”. Leave a target empty for none. The clock pauses while a ticket waits on the customer.',
					'helpdesk-hero-pro'
				) }
				bodyClass={ null }
			>
				{ draft.policies.length > 0 && (
					<div className="hdh-table-wrap">
						<table className="hdh-table">
							<thead>
								<tr>
									<th scope="col">{ __( 'Policy', 'helpdesk-hero-pro' ) }</th>
									<th scope="col">{ __( 'First reply within (hours)', 'helpdesk-hero-pro' ) }</th>
									<th scope="col">{ __( 'Resolved within (hours)', 'helpdesk-hero-pro' ) }</th>
									<th scope="col">{ __( 'Default', 'helpdesk-hero-pro' ) }</th>
									<th scope="col">
										<span className="hdh-sr">{ __( 'Actions', 'helpdesk-hero-pro' ) }</span>
									</th>
								</tr>
							</thead>
							<tbody>
								{ draft.policies.map( ( p, i ) => (
									<tr key={ p.id || `new-${ i }` }>
										<td>
											<input
												className="hdh-input"
												style={ { width: '100%', minWidth: 140 } }
												aria-label={ __( 'Policy name', 'helpdesk-hero-pro' ) }
												placeholder={ __( 'For example: VIP', 'helpdesk-hero-pro' ) }
												value={ p.name }
												maxLength={ 60 }
												onChange={ ( e ) => setPolicy( i, { name: e.target.value } ) }
											/>
										</td>
										<td>
											<HoursInput
												label={ __( 'First reply within (hours)', 'helpdesk-hero-pro' ) }
												minutes={ p.respond }
												onChange={ ( m ) => setPolicy( i, { respond: m } ) }
											/>
										</td>
										<td>
											<HoursInput
												label={ __( 'Resolved within (hours)', 'helpdesk-hero-pro' ) }
												minutes={ p.resolve }
												onChange={ ( m ) => setPolicy( i, { resolve: m } ) }
											/>
										</td>
										<td>
											<input
												type="radio"
												name="hdh-sla-default"
												aria-label={ __( 'Default policy', 'helpdesk-hero-pro' ) }
												disabled={ ! p.id }
												checked={ !! p.id && draft.default === p.id }
												onChange={ () => setDraft( { ...draft, default: p.id } ) }
											/>
										</td>
										<td style={ { width: 1 } }>
											<Button
												size="sm"
												variant="ghost"
												icon="trash"
												aria-label={ __( 'Delete policy', 'helpdesk-hero-pro' ) }
												onClick={ () =>
													setDraft( {
														...draft,
														default: draft.default === p.id ? '' : draft.default,
														policies: draft.policies.filter( ( _, n ) => n !== i ),
													} )
												}
											/>
										</td>
									</tr>
								) ) }
							</tbody>
						</table>
					</div>
				) }
				<div className="hdh-row" style={ { padding: 18 } }>
					<Button
						size="sm"
						icon="plus"
						onClick={ () =>
							setDraft( {
								...draft,
								policies: [ ...draft.policies, { id: '', name: '', respond: 0, resolve: 0 } ],
							} )
						}
					>
						{ __( 'Add policy', 'helpdesk-hero-pro' ) }
					</Button>
					{ draft.default && (
						<Button
							size="sm"
							variant="ghost"
							onClick={ () => setDraft( { ...draft, default: '' } ) }
						>
							{ __( 'No default policy', 'helpdesk-hero-pro' ) }
						</Button>
					) }
				</div>
			</Card>

			<Card
				title={ __( 'Who gets which policy', 'helpdesk-hero-pro' ) }
				sub={ __(
					'A site’s own policy (set in its drawer under Sites) comes first. Otherwise the strictest of its tier’s and the ticket’s service’s policy applies, so a VIP’s security fix gets the faster target. Without either, the default applies.',
					'helpdesk-hero-pro'
				) }
			>
				<div className="hdh-stack" style={ { gap: 16 } }>
					{ named.length === 0 && (
						<p className="hdh-muted" style={ { margin: 0 } }>
							{ __( 'Add a policy first.', 'helpdesk-hero-pro' ) }
						</p>
					) }
					{ named.length > 0 && data.tiers.length > 0 && (
						<div className="hdh-stack" style={ { gap: 8 } }>
							<div className="hdh-section-title">{ __( 'Customer tiers', 'helpdesk-hero-pro' ) }</div>
							{ data.tiers.map( ( t ) => (
								<div key={ t.id } className="hdh-assign-row">
									<span>{ t.name }</span>
									<PolicySelect
										label={ t.name }
										value={ draft.tiers[ t.id ] }
										onChange={ ( v ) => assign( 'tiers', t.id, v ) }
										policies={ named }
										emptyLabel={ __( 'No policy of its own', 'helpdesk-hero-pro' ) }
									/>
								</div>
							) ) }
						</div>
					) }
					{ named.length > 0 && data.services.length > 0 && (
						<div className="hdh-stack" style={ { gap: 8 } }>
							<div className="hdh-section-title">{ __( 'Services', 'helpdesk-hero-pro' ) }</div>
							{ data.services.map( ( x ) => (
								<div key={ x.id } className="hdh-assign-row">
									<span>{ x.name }</span>
									<PolicySelect
										label={ x.name }
										value={ draft.services[ x.id ] }
										onChange={ ( v ) => assign( 'services', x.id, v ) }
										policies={ named }
										emptyLabel={ __( 'No policy of its own', 'helpdesk-hero-pro' ) }
									/>
								</div>
							) ) }
						</div>
					) }
					{ ownSites.length > 0 && (
						<div className="hdh-stack" style={ { gap: 8 } }>
							<div className="hdh-section-title">{ __( 'Sites with their own policy', 'helpdesk-hero-pro' ) }</div>
							{ ownSites.map( ( id ) => (
								<div key={ id } className="hdh-assign-row">
									<span>{ data.sites[ id ] || `#${ id }` }</span>
									<PolicySelect
										label={ data.sites[ id ] || id }
										value={ draft.sites[ id ] }
										onChange={ ( v ) => assign( 'sites', id, v ) }
										policies={ named }
										emptyLabel={ __( 'Use tier, service or default', 'helpdesk-hero-pro' ) }
									/>
								</div>
							) ) }
						</div>
					) }
				</div>
			</Card>

			<Card title={ __( 'Business hours', 'helpdesk-hero-pro' ) }>
				<div className="hdh-stack" style={ { gap: 10 } }>
					<Check
						label={ __( 'Count only business hours', 'helpdesk-hero-pro' ) }
						desc={ sprintf(
							/* translators: %s: timezone */
							__(
								'Otherwise targets count around the clock. Times are in the site’s timezone (%s, Settings › General).',
								'helpdesk-hero-pro'
							),
							data.timezone
						) }
						checked={ hours.enabled }
						onChange={ ( on ) => setHours( { enabled: on } ) }
					/>
					{ hours.enabled && (
						<>
							<div className="hdh-row" style={ { gap: 6 } }>
								{ DAYS.map( ( [ n, label ] ) => {
									const on = hours.days.includes( n );
									return (
										<button
											key={ n }
											type="button"
											className={ `hdh-tagpill is-toggle ${ on ? 'is-on' : '' }` }
											aria-pressed={ on }
											onClick={ () =>
												setHours( {
													days: on
														? hours.days.filter( ( d ) => d !== n )
														: [ ...hours.days, n ].sort(),
												} )
											}
										>
											{ label }
										</button>
									);
								} ) }
							</div>
							<div className="hdh-row" style={ { gap: 8 } }>
								<label className="hdh-inline-field" htmlFor="sla-start">
									<span>{ __( 'From', 'helpdesk-hero-pro' ) }</span>
									<input
										id="sla-start"
										type="time"
										className="hdh-input"
										value={ hours.start }
										onChange={ ( e ) => setHours( { start: e.target.value } ) }
									/>
								</label>
								<label className="hdh-inline-field" htmlFor="sla-end">
									<span>{ __( 'to', 'helpdesk-hero-pro' ) }</span>
									<input
										id="sla-end"
										type="time"
										className="hdh-input"
										value={ hours.end }
										onChange={ ( e ) => setHours( { end: e.target.value } ) }
									/>
								</label>
							</div>
						</>
					) }
				</div>
			</Card>
			{ dirty && (
				<div>
					<Button variant="primary" disabled={ busy } onClick={ save }>
						{ __( 'Save service levels', 'helpdesk-hero-pro' ) }
					</Button>
				</div>
			) }
		</>
	);
}

/**
 * A site's own SLA policy (in the site drawer).
 *
 * @param {Object} props      Props.
 * @param {Object} props.site Site.
 * @return {JSX.Element|null} Field.
 */
export function SiteSlaPanel( { site } ) {
	const { data, reload } = useApi( 'sla' );
	const toast = useToast();
	if ( ! data || ! ( window.hdhBoot || {} ).canManage || ! data.settings.policies.length ) {
		return null;
	}
	const current = data.settings.sites[ String( site.id ) ] || '';
	return (
		<div className="hdh-card hdh-stack" style={ { padding: 16 } }>
			<div className="hdh-section-title">{ __( 'Service level', 'helpdesk-hero-pro' ) }</div>
			<PolicySelect
				label={ __( 'SLA policy for this site', 'helpdesk-hero-pro' ) }
				value={ current }
				policies={ data.settings.policies }
				emptyLabel={ __( 'Use the tier’s, service’s or default policy', 'helpdesk-hero-pro' ) }
				onChange={ ( policy ) =>
					send( `sla/site/${ site.id }`, 'POST', { policy } )
						.then( () => {
							toast( __( 'Service level saved', 'helpdesk-hero-pro' ) );
							reload();
						} )
						.catch( ( e ) => toast( errorText( e ), 'alert' ) )
				}
			/>
		</div>
	);
}

const BASES = [
	{ value: 'open', label: __( 'Open', 'helpdesk-hero-pro' ) },
	{
		value: 'pending',
		label: __( 'Waiting on customer', 'helpdesk-hero-pro' ),
	},
	{ value: 'closed', label: __( 'Closed', 'helpdesk-hero-pro' ) },
];

export function StatusesCard() {
	const { data, reload } = useApi( 'statuses' );
	const [ list, setList ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setList( data.statuses );
		}
	}, [ data ] );
	if ( ! data || ! list ) {
		return <Loading />;
	}
	const dirty = JSON.stringify( list ) !== JSON.stringify( data.statuses );
	const set = ( i, patch ) =>
		setList( list.map( ( s, n ) => ( n === i ? { ...s, ...patch } : s ) ) );
	const save = () => {
		setBusy( true );
		send( 'statuses', 'POST', { statuses: list } )
			.then( () => {
				toast(
					__(
						'Statuses saved. Reload the page to use them.',
						'helpdesk-hero-pro'
					)
				);
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	return (
		<Card
			title={ __( 'Custom statuses', 'helpdesk-hero-pro' ) }
			sub={ __(
				'More detail than Open, Waiting on customer and Closed, such as “In progress” or “Waiting on hosting”. Each belongs to one of those three, which still decides what happens (closing ends access and asks for a rating; waiting pauses the SLA). Customers see the base status, unless you tick “Show to customers”.',
				'helpdesk-hero-pro'
			) }
		>
			<div className="hdh-stack" style={ { gap: 8 } }>
				{ list.map( ( s, i ) => (
					<div key={ s.id || `new-${ i }` } className="hdh-row">
						<input
							type="color"
							aria-label={ __( 'Colour', 'helpdesk-hero-pro' ) }
							value={ s.color || '#6b6963' }
							onChange={ ( e ) => set( i, { color: e.target.value } ) }
							style={ {
								width: 36,
								height: 30,
								border: 0,
								background: 'none',
							} }
						/>
						<input
							className="hdh-input"
							aria-label={ __( 'Status name', 'helpdesk-hero-pro' ) }
							placeholder={ __( 'In progress', 'helpdesk-hero-pro' ) }
							value={ s.label }
							maxLength={ 40 }
							onChange={ ( e ) => set( i, { label: e.target.value } ) }
							style={ { flex: 1, maxWidth: 240 } }
						/>
						<SelectField
							label={ __( 'Counts as', 'helpdesk-hero-pro' ) }
							hideLabel
							value={ s.base }
							onChange={ ( v ) => set( i, { base: v } ) }
							options={ BASES }
						/>
						<Check
							label={ __( 'Show to customers', 'helpdesk-hero-pro' ) }
							checked={ !! s.public }
							onChange={ ( on ) => set( i, { public: on } ) }
						/>
						<Button
							size="sm"
							variant="ghost"
							icon="trash"
							aria-label={ __( 'Delete status', 'helpdesk-hero-pro' ) }
							onClick={ () =>
								setList( list.filter( ( _, n ) => n !== i ) )
							}
						/>
					</div>
				) ) }
				<div className="hdh-row">
					<Button
						size="sm"
						icon="plus"
						onClick={ () =>
							setList( [
								...list,
								{ id: '', label: '', color: '#2a78d6', base: 'open', public: false },
							] )
						}
					>
						{ __( 'Add status', 'helpdesk-hero-pro' ) }
					</Button>
					{ dirty && (
						<Button
							size="sm"
							variant="primary"
							disabled={ busy }
							onClick={ save }
						>
							{ __( 'Save statuses', 'helpdesk-hero-pro' ) }
						</Button>
					) }
				</div>
			</div>
		</Card>
	);
}
