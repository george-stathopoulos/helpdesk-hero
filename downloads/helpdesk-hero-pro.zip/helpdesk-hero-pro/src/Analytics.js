import { __, _n, sprintf } from '@wordpress/i18n';
import { useState } from '@wordpress/element';
import { addQueryArgs } from '@wordpress/url';
import { useApi } from './ui/lib/hooks';
import { ago, when } from './ui/lib/time';
import {
	Card,
	PageHead,
	Segmented,
	Button,
	ErrorNotice,
	Loading,
	Empty,
} from './ui/components/ui';
import { StackedColumns, BarList } from './ui/components/charts';
import { Donut, Stars } from './ui/components/kit';
import Icon from './ui/components/Icon';

const RANGES = [
	{ value: 7, label: __( '7 days', 'helpdesk-hero-pro' ) },
	{ value: 30, label: __( '30 days', 'helpdesk-hero-pro' ) },
	{ value: 90, label: __( '90 days', 'helpdesk-hero-pro' ) },
	{ value: 365, label: __( 'Year', 'helpdesk-hero-pro' ) },
];

const STAR_COLOR = {
	1: 'var(--hdh-critical)',
	2: 'var(--hdh-critical)',
	3: 'var(--hdh-warning)',
	4: 'var(--hdh-good)',
	5: 'var(--hdh-good)',
};

const LEVEL_COLOR = {
	critical: 'var(--hdh-critical)',
	warning: 'var(--hdh-warning)',
};

function hoursText( h ) {
	if ( h === null || h === undefined ) {
		return '—';
	}
	if ( h < 1 ) {
		return sprintf(
			/* translators: %d: minutes */
			__( '%d min', 'helpdesk-hero-pro' ),
			Math.max( 1, Math.round( h * 60 ) )
		);
	}
	if ( h < 48 ) {
		return sprintf(
			/* translators: %s: hours */
			__( '%s h', 'helpdesk-hero-pro' ),
			Math.round( h * 10 ) / 10
		);
	}
	return sprintf(
		/* translators: %s: days */
		__( '%s days', 'helpdesk-hero-pro' ),
		Math.round( ( h / 24 ) * 10 ) / 10
	);
}

function bars( items, colors = {} ) {
	return items.map( ( i ) => ( {
		id: i.label,
		label: i.label,
		value: i.value,
		color: colors[ i.label ] || LEVEL_COLOR[ i.level ] || 'var(--hdh-s1)',
	} ) );
}

function count( v ) {
	return sprintf(
		/* translators: %d: number of tickets */
		_n( '%d ticket', '%d tickets', v, 'helpdesk-hero-pro' ),
		v
	);
}

/**
 * Weekly buckets for long ranges, so a year reads as 52 columns instead of 365.
 *
 * @param {Object} series { dates, opened, closed }.
 * @return {Object} Series.
 */
function bucket( series ) {
	if ( series.dates.length <= 90 ) {
		return series;
	}
	const out = { dates: [], opened: [], closed: [] };
	for ( let i = 0; i < series.dates.length; i += 7 ) {
		out.dates.push( series.dates[ i ] );
		out.opened.push(
			series.opened.slice( i, i + 7 ).reduce( ( a, b ) => a + b, 0 )
		);
		out.closed.push(
			series.closed.slice( i, i + 7 ).reduce( ( a, b ) => a + b, 0 )
		);
	}
	return out;
}

export default function Analytics() {
	const [ days, setDays ] = useState( 30 );
	const [ site, setSite ] = useState( 0 );
	const { data, error, loading, reload } = useApi(
		addQueryArgs( 'analytics', { days, site: site || undefined } )
	);

	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ reload } />;
	}
	if ( ! data ) {
		return <Loading />;
	}
	const t = data.totals;
	const series = bucket( data.series );
	const siteName = data.site
		? data.site.name
		: __( 'All sites', 'helpdesk-hero-pro' );

	return (
		<div className={ loading ? 'hdh-is-loading' : '' }>
			<PageHead
				title={ __( 'Analytics', 'helpdesk-hero-pro' ) }
				lede={ sprintf(
					/* translators: 1: site name or "All sites", 2: generated date */
					__( '%1$s · generated %2$s', 'helpdesk-hero-pro' ),
					siteName,
					when( data.generated )
				) }
			>
				<div className="hdh-toolbar hdh-noprint">
					<select
						className="hdh-input hdh-select"
						aria-label={ __( 'Site', 'helpdesk-hero-pro' ) }
						value={ site }
						onChange={ ( e ) =>
							setSite( parseInt( e.target.value, 10 ) )
						}
					>
						<option value={ 0 }>
							{ __( 'All sites', 'helpdesk-hero-pro' ) }
						</option>
						{ data.sites_list.map( ( s ) => (
							<option key={ s.id } value={ s.id }>
								{ s.name }
							</option>
						) ) }
					</select>
					<Segmented
						label={ __( 'Range', 'helpdesk-hero-pro' ) }
						value={ days }
						onChange={ setDays }
						options={ RANGES }
					/>
					<Button icon="table" onClick={ () => window.print() }>
						{ __( 'Export PDF', 'helpdesk-hero-pro' ) }
					</Button>
				</div>
			</PageHead>

			<div className="hdh-kpis">
				<KPI
					icon="inbox"
					label={ __( 'Tickets', 'helpdesk-hero-pro' ) }
					value={ t.tickets }
				/>
				<KPI
					icon="check"
					label={ __( 'Closed', 'helpdesk-hero-pro' ) }
					value={ t.closed }
				/>
				<KPI
					icon="clock"
					label={ __( 'First reply', 'helpdesk-hero-pro' ) }
					value={ hoursText( t.first_response ) }
					foot={ __( 'median', 'helpdesk-hero-pro' ) }
				/>
				<KPI
					icon="gauge"
					label={ __( 'Time to close', 'helpdesk-hero-pro' ) }
					value={ hoursText( t.resolution ) }
					foot={ __( 'median', 'helpdesk-hero-pro' ) }
				/>
				<KPI
					icon="spark"
					label={ __( 'Rating', 'helpdesk-hero-pro' ) }
					value={ t.rating ? `${ t.rating } / 5` : '—' }
					foot={ sprintf(
						/* translators: %d: number of ratings */ _n(
							'%d rating',
							'%d ratings',
							t.ratings,
							'helpdesk-hero-pro'
						),
						t.ratings
					) }
				/>
				<KPI
					icon="globe"
					label={ __( 'Sites', 'helpdesk-hero-pro' ) }
					value={ data.site ? 1 : data.sites_list.length }
				/>
			</div>

			{ ! t.tickets ? (
				<Card>
					<Empty
						title={ __(
							'No tickets in this period',
							'helpdesk-hero-pro'
						) }
						text={ __(
							'Try a longer range or another site.',
							'helpdesk-hero-pro'
						) }
					/>
				</Card>
			) : (
				<div className="hdh-grid">
					<Card
						className="hdh-span-12"
						title={ __( 'Tickets over time', 'helpdesk-hero-pro' ) }
						sub={
							series.dates.length < data.series.dates.length
								? __( 'Per week', 'helpdesk-hero-pro' )
								: __( 'Per day', 'helpdesk-hero-pro' )
						}
					>
						<StackedColumns
							dates={ series.dates }
							series={ [
								{
									id: 'opened',
									label: __( 'Opened', 'helpdesk-hero-pro' ),
									values: series.opened,
									color: 'var(--hdh-s1)',
								},
								{
									id: 'closed',
									label: __( 'Closed', 'helpdesk-hero-pro' ),
									values: series.closed,
									color: 'var(--hdh-s3)',
								},
							] }
							format={ ( v ) => String( Math.round( v ) ) }
							height={ 240 }
							title={ __(
								'Tickets opened and closed',
								'helpdesk-hero-pro'
							) }
						/>
					</Card>
					<Card
						className="hdh-span-4"
						title={ __( 'Categories', 'helpdesk-hero-pro' ) }
					>
						<Donut
							items={ data.categories }
							title={ __(
								'Tickets by category',
								'helpdesk-hero-pro'
							) }
						/>
					</Card>
					<Card
						className="hdh-span-4"
						title={ __( 'Priorities', 'helpdesk-hero-pro' ) }
					>
						<Donut
							items={ data.priorities.map( ( p, i ) => ( {
								...p,
								color: [
									'var(--hdh-s1)',
									'var(--hdh-s4)',
									'var(--hdh-s2)',
									'var(--hdh-s8)',
								][ i % 4 ],
							} ) ) }
							title={ __(
								'Tickets by priority',
								'helpdesk-hero-pro'
							) }
						/>
					</Card>
					<Card
						className="hdh-span-4"
						title={ __(
							'How tickets arrived',
							'helpdesk-hero-pro'
						) }
					>
						<Donut
							items={ data.channels }
							title={ __(
								'Tickets by channel',
								'helpdesk-hero-pro'
							) }
						/>
					</Card>
					<Card
						className="hdh-span-6"
						title={ __( 'Recurring issues', 'helpdesk-hero-pro' ) }
						sub={ __(
							'Health check findings on the most tickets',
							'helpdesk-hero-pro'
						) }
					>
						{ data.issues.length ? (
							<BarList
								items={ bars( data.issues ) }
								format={ count }
							/>
						) : (
							<p className="hdh-muted">
								{ __(
									'No repeated problems found.',
									'helpdesk-hero-pro'
								) }
							</p>
						) }
					</Card>
					<Card
						className="hdh-span-6"
						title={ __( 'Tags', 'helpdesk-hero-pro' ) }
					>
						{ data.tags.length ? (
							<BarList
								items={ bars( data.tags, data.tag_colors ) }
								format={ count }
							/>
						) : (
							<p className="hdh-muted">
								{ __(
									'No tagged tickets in this period.',
									'helpdesk-hero-pro'
								) }
							</p>
						) }
					</Card>
					{ ! data.site && (
						<Card
							className="hdh-span-6"
							title={ __( 'Busiest sites', 'helpdesk-hero-pro' ) }
						>
							<BarList
								items={ bars( data.top_sites ) }
								format={ count }
							/>
						</Card>
					) }
					<Card
						className={ data.site ? 'hdh-span-12' : 'hdh-span-6' }
						title={ __( 'Ratings', 'helpdesk-hero-pro' ) }
						sub={ __(
							'From customers, after a ticket is closed or access ends',
							'helpdesk-hero-pro'
						) }
					>
						{ ! t.ratings ? (
							<p className="hdh-muted">
								{ __(
									'No ratings yet. Turn on “Ask customers to rate support” in your policies.',
									'helpdesk-hero-pro'
								) }
							</p>
						) : (
							<div className="hdh-stack">
								<BarList
									items={ [ 5, 4, 3, 2, 1 ].map( ( n ) => ( {
										id: String( n ),
										label: '★'.repeat( n ),
										value: data.ratings.distribution[
											n - 1
										],
										color: STAR_COLOR[ n ],
									} ) ) }
									format={ ( v ) => String( v ) }
								/>
								<div
									className="hdh-section-title"
									style={ { marginTop: 8 } }
								>
									{ __(
										'Latest reviews',
										'helpdesk-hero-pro'
									) }
								</div>
								<ul className="hdh-feed">
									{ data.ratings.recent.map( ( r ) => (
										<li
											key={ r.id }
											className="hdh-feed__item"
											style={ {
												gridTemplateColumns:
													'auto minmax(0,1fr) auto',
												padding: '10px 0',
												alignItems: 'start',
											} }
										>
											<Stars
												value={ r.rating }
												size={ 12 }
											/>
											<div>
												<a
													href={ `#/ticket/${ r.id }` }
												>
													{ r.subject }
												</a>
												{ r.comment && (
													<div
														style={ {
															marginTop: 2,
														} }
													>
														“{ r.comment }”
													</div>
												) }
												<div className="hdh-muted">
													{ r.site }
												</div>
											</div>
											<span className="hdh-muted">
												{ ago( r.time ) }
											</span>
										</li>
									) ) }
								</ul>
							</div>
						) }
					</Card>
				</div>
			) }
			<p className="hdh-muted" style={ { marginTop: 18, fontSize: 12 } }>
				<Icon name="info" size={ 12 } />{ ' ' }
				{ __(
					'Times are medians over tickets opened in the period. Export PDF uses your browser’s print dialog: choose “Save as PDF”.',
					'helpdesk-hero-pro'
				) }
			</p>
		</div>
	);
}

function KPI( { icon, label, value, foot } ) {
	return (
		<Card bodyClass={ null }>
			<div className="hdh-stat">
				<div className="hdh-stat__label">
					<Icon name={ icon } size={ 14 } />
					{ label }
				</div>
				<div className="hdh-stat__value">{ value }</div>
				{ foot && (
					<div className="hdh-stat__foot hdh-muted">{ foot }</div>
				) }
			</div>
		</Card>
	);
}
