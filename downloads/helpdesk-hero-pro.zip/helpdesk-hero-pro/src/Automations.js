/**
 * Automations: the editor (Settings › Automations) and quick actions on tickets.
 */
import { __, sprintf } from '@wordpress/i18n';
import { useState, useEffect } from '@wordpress/element';
import { useApi, send } from './ui/lib/hooks';
import {
	Card,
	Button,
	Drawer,
	Switch,
	Loading,
	Empty,
	useToast,
} from './ui/components/ui';
import { TextField, confirmAction } from './ui/components/kit';
import { errorText } from './Workflow';

const OPS = {
	is: __( 'is', 'helpdesk-hero-pro' ),
	is_not: __( 'is not', 'helpdesk-hero-pro' ),
	contains: __( 'contains', 'helpdesk-hero-pro' ),
	lte: __( 'is at most', 'helpdesk-hero-pro' ),
	gte: __( 'is at least', 'helpdesk-hero-pro' ),
};

/**
 * Choices for a condition's or action's value ({} = free text).
 *
 * @param {string} key  Field or action.
 * @param {Object} opts Options from the server.
 * @return {Object|null} value => label, or null for free text.
 */
function choices( key, opts ) {
	switch ( key ) {
		case 'site':
			return opts.sites;
		case 'tier':
			return opts.tiers;
		case 'priority':
		case 'set_priority':
			return opts.priorities;
		case 'service':
		case 'set_service':
			return opts.services;
		case 'tag':
		case 'event_tag':
		case 'add_tag':
		case 'remove_tag':
			return opts.tags;
		case 'status':
		case 'event_status':
		case 'set_status':
			return opts.statuses;
		case 'assignee':
			return { 0: __( 'Nobody', 'helpdesk-hero-pro' ), ...opts.team };
		case 'assign':
			return {
				round_robin: __( 'Next supporter in turn (round-robin)', 'helpdesk-hero-pro' ),
				none: __( 'Nobody', 'helpdesk-hero-pro' ),
				...opts.team,
			};
		case 'send_reply':
			return opts.replies;
		case 'business_hours':
			return {
				yes: __( 'Yes', 'helpdesk-hero-pro' ),
				no: __( 'No', 'helpdesk-hero-pro' ),
			};
		case 'email':
			return null;
	}
	return null;
}

function ValueInput( { k, value, onChange, opts, label, placeholder } ) {
	const list = choices( k, opts );
	if ( list ) {
		return (
			<select
				className="hdh-input hdh-select"
				aria-label={ label }
				value={ value }
				onChange={ ( e ) => onChange( e.target.value ) }
			>
				<option value="">{ __( 'Choose…', 'helpdesk-hero-pro' ) }</option>
				{ Object.keys( list ).map( ( v ) => (
					<option key={ v } value={ v }>
						{ list[ v ] }
					</option>
				) ) }
			</select>
		);
	}
	return (
		<input
			className="hdh-input"
			style={ { flex: 1, minWidth: 160 } }
			aria-label={ label }
			placeholder={ placeholder }
			value={ value }
			onChange={ ( e ) => onChange( e.target.value ) }
		/>
	);
}

/**
 * Ready-made automations to start from.
 *
 * @return {Array} Presets.
 */
function presets() {
	return [
		{
			name: __( 'Follow up on low ratings', 'helpdesk-hero-pro' ),
			trigger: 'rated',
			match: 'all',
			conditions: [ { field: 'rating', op: 'lte', value: '3' } ],
			actions: [
				{ type: 'add_note', value: __( 'Low rating: please follow up with the customer.', 'helpdesk-hero-pro' ) },
				{ type: 'email', value: 'team' },
			],
		},
		{
			name: __( 'Share new tickets round-robin', 'helpdesk-hero-pro' ),
			trigger: 'ticket_created',
			match: 'all',
			conditions: [],
			actions: [ { type: 'assign', value: 'round_robin' } ],
		},
		{
			name: __( 'Close tickets waiting 7 days', 'helpdesk-hero-pro' ),
			trigger: 'waiting_customer',
			hours: 168,
			match: 'all',
			conditions: [],
			actions: [ { type: 'set_status', value: 'closed' } ],
		},
		{
			name: __( 'Urgent tickets to Slack', 'helpdesk-hero-pro' ),
			trigger: 'ticket_created',
			match: 'all',
			conditions: [ { field: 'priority', op: 'is', value: 'urgent' } ],
			actions: [ { type: 'slack', value: __( 'Urgent ticket: {ticket_subject} ({site_name})', 'helpdesk-hero-pro' ) } ],
		},
		{
			name: __( 'Escalate: no reply in 4 hours', 'helpdesk-hero-pro' ),
			trigger: 'no_team_reply',
			hours: 4,
			match: 'all',
			conditions: [],
			actions: [
				{ type: 'set_priority', value: 'high' },
				{ type: 'email', value: 'team' },
			],
		},
	];
}

function Editor( { automation, meta, onSave, onClose } ) {
	const [ a, setA ] = useState( automation );
	const set = ( patch ) => setA( { ...a, ...patch } );
	const opts = meta.options;
	const fieldKeys = Object.keys( meta.fields );
	const actionKeys = Object.keys( meta.actions );
	const valid =
		a.name.trim() &&
		a.actions.length &&
		a.actions.every( ( x ) => x.type && ( x.value || [ 'add_note', 'slack' ].includes( x.type ) ) );
	return (
		<Drawer
			wide
			title={
				<h2 className="hdh-card__title">
					{ a.id
						? __( 'Edit automation', 'helpdesk-hero-pro' )
						: __( 'New automation', 'helpdesk-hero-pro' ) }
				</h2>
			}
			onClose={ onClose }
			footer={
				<Button variant="primary" disabled={ ! valid } onClick={ () => onSave( a ) }>
					{ __( 'Save automation', 'helpdesk-hero-pro' ) }
				</Button>
			}
		>
			<div className="hdh-stack" style={ { gap: 18 } }>
				<TextField
					label={ __( 'Name', 'helpdesk-hero-pro' ) }
					value={ a.name }
					maxLength={ 80 }
					onChange={ ( v ) => set( { name: v } ) }
				/>
				<div className="hdh-stack" style={ { gap: 8 } }>
					<div className="hdh-section-title">{ __( 'When', 'helpdesk-hero-pro' ) }</div>
					<div className="hdh-row">
						<select
							className="hdh-input hdh-select"
							aria-label={ __( 'Trigger', 'helpdesk-hero-pro' ) }
							value={ a.trigger }
							onChange={ ( e ) => set( { trigger: e.target.value } ) }
						>
							{ Object.keys( meta.triggers ).map( ( t ) => (
								<option key={ t } value={ t }>
									{ meta.triggers[ t ][ 0 ] }
								</option>
							) ) }
						</select>
						{ meta.triggers[ a.trigger ] && meta.triggers[ a.trigger ][ 1 ] && (
							<label className="hdh-inline-field" htmlFor="hdh-auto-hours">
								<input
									id="hdh-auto-hours"
									type="number"
									min="1"
									className="hdh-input"
									style={ { width: 80 } }
									value={ a.hours ?? 24 }
									onChange={ ( e ) =>
										set( { hours: parseInt( e.target.value, 10 ) || '' } )
									}
								/>
								<span>{ __( 'hours', 'helpdesk-hero-pro' ) }</span>
							</label>
						) }
					</div>
				</div>
				<div className="hdh-stack" style={ { gap: 8 } }>
					<div className="hdh-section-title hdh-row">
						{ __( 'If', 'helpdesk-hero-pro' ) }
						{ a.conditions.length > 1 && (
							<select
								className="hdh-input hdh-select"
								aria-label={ __( 'Match', 'helpdesk-hero-pro' ) }
								value={ a.match }
								onChange={ ( e ) => set( { match: e.target.value } ) }
							>
								<option value="all">{ __( 'all of these', 'helpdesk-hero-pro' ) }</option>
								<option value="any">{ __( 'any of these', 'helpdesk-hero-pro' ) }</option>
							</select>
						) }
					</div>
					{ ! a.conditions.length && (
						<p className="hdh-muted" style={ { margin: 0 } }>
							{ __( 'Every ticket (no conditions).', 'helpdesk-hero-pro' ) }
						</p>
					) }
					{ a.conditions.map( ( c, i ) => {
						const setC = ( patch ) =>
							set( {
								conditions: a.conditions.map( ( x, n ) =>
									n === i ? { ...x, ...patch } : x
								),
							} );
						return (
							<div key={ i } className="hdh-row">
								<select
									className="hdh-input hdh-select"
									aria-label={ __( 'Field', 'helpdesk-hero-pro' ) }
									value={ c.field }
									onChange={ ( e ) => setC( { field: e.target.value, value: '' } ) }
								>
									{ fieldKeys.map( ( f ) => (
										<option key={ f } value={ f }>
											{ meta.fields[ f ] }
										</option>
									) ) }
								</select>
								<select
									className="hdh-input hdh-select"
									aria-label={ __( 'Comparison', 'helpdesk-hero-pro' ) }
									value={ c.op }
									onChange={ ( e ) => setC( { op: e.target.value } ) }
								>
									{ Object.keys( OPS ).map( ( o ) => (
										<option key={ o } value={ o }>
											{ OPS[ o ] }
										</option>
									) ) }
								</select>
								<ValueInput
									k={ c.field }
									value={ c.value }
									opts={ opts }
									label={ __( 'Value', 'helpdesk-hero-pro' ) }
									onChange={ ( v ) => setC( { value: v } ) }
								/>
								<Button
									size="sm"
									variant="ghost"
									icon="trash"
									aria-label={ __( 'Remove condition', 'helpdesk-hero-pro' ) }
									onClick={ () =>
										set( { conditions: a.conditions.filter( ( _, n ) => n !== i ) } )
									}
								/>
							</div>
						);
					} ) }
					<div>
						<Button
							size="sm"
							icon="plus"
							onClick={ () =>
								set( {
									conditions: [
										...a.conditions,
										{ field: fieldKeys[ 0 ], op: 'is', value: '' },
									],
								} )
							}
						>
							{ __( 'Add condition', 'helpdesk-hero-pro' ) }
						</Button>
					</div>
				</div>
				<div className="hdh-stack" style={ { gap: 8 } }>
					<div className="hdh-section-title">{ __( 'Then', 'helpdesk-hero-pro' ) }</div>
					{ a.actions.map( ( x, i ) => {
						const setX = ( patch ) =>
							set( {
								actions: a.actions.map( ( y, n ) =>
									n === i ? { ...y, ...patch } : y
								),
							} );
						const placeholder = {
							add_note: __( 'Note text ({customer_name} and other variables work)', 'helpdesk-hero-pro' ),
							email: __( 'team, assignee, or an email address', 'helpdesk-hero-pro' ),
							slack: __( 'Message (optional)', 'helpdesk-hero-pro' ),
						}[ x.type ];
						return (
							<div key={ i } className="hdh-row">
								<select
									className="hdh-input hdh-select"
									aria-label={ __( 'Action', 'helpdesk-hero-pro' ) }
									value={ x.type }
									onChange={ ( e ) => setX( { type: e.target.value, value: '' } ) }
								>
									{ actionKeys.map( ( k ) => (
										<option key={ k } value={ k }>
											{ meta.actions[ k ] }
										</option>
									) ) }
								</select>
								<ValueInput
									k={ x.type }
									value={ x.value }
									opts={ opts }
									label={ __( 'Value', 'helpdesk-hero-pro' ) }
									placeholder={ placeholder }
									onChange={ ( v ) => setX( { value: v } ) }
								/>
								<Button
									size="sm"
									variant="ghost"
									icon="trash"
									aria-label={ __( 'Remove action', 'helpdesk-hero-pro' ) }
									onClick={ () =>
										set( { actions: a.actions.filter( ( _, n ) => n !== i ) } )
									}
								/>
							</div>
						);
					} ) }
					<div>
						<Button
							size="sm"
							icon="plus"
							onClick={ () =>
								set( {
									actions: [ ...a.actions, { type: actionKeys[ 0 ], value: '' } ],
								} )
							}
						>
							{ __( 'Add action', 'helpdesk-hero-pro' ) }
						</Button>
					</div>
					<p className="hdh-muted" style={ { margin: 0 } }>
						{ __(
							'An automation sends a customer at most one reply per ticket, and its actions never start other automations.',
							'helpdesk-hero-pro'
						) }
					</p>
				</div>
			</div>
		</Drawer>
	);
}

export function AutomationsSettings() {
	const { data, reload } = useApi( 'automations' );
	const [ list, setList ] = useState( null );
	const [ editing, setEditing ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setList( data.automations );
		}
	}, [ data ] );
	if ( ! data || ! list ) {
		return <Loading />;
	}
	const persist = ( next ) => {
		setBusy( true );
		return send( 'automations', 'POST', { automations: next } )
			.then( () => {
				toast( __( 'Automations saved', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	const move = ( i, by ) => {
		const next = [ ...list ];
		const [ item ] = next.splice( i, 1 );
		next.splice( i + by, 0, item );
		persist( next );
	};
	const blank = {
		id: '',
		name: '',
		enabled: true,
		trigger: 'ticket_created',
		hours: 24,
		match: 'all',
		conditions: [],
		actions: [ { type: 'assign', value: '' } ],
	};
	return (
		<>
			<Card
				title={ __( 'Automations', 'helpdesk-hero-pro' ) }
				sub={ __(
					'When something happens, if a ticket matches, do things for you. They run in this order. Each run is noted in the ticket’s history.',
					'helpdesk-hero-pro'
				) }
				action={
					<Button size="sm" variant="primary" icon="plus" onClick={ () => setEditing( blank ) }>
						{ __( 'New automation', 'helpdesk-hero-pro' ) }
					</Button>
				}
				bodyClass={ null }
			>
				{ ! list.length ? (
					<Empty
						compact
						title={ __( 'No automations yet', 'helpdesk-hero-pro' ) }
						text={ __( 'Start from one of these, or make your own.', 'helpdesk-hero-pro' ) }
					>
						<div className="hdh-row" style={ { justifyContent: 'center' } }>
							{ presets().map( ( p ) => (
								<Button
									key={ p.name }
									size="sm"
									onClick={ () => setEditing( { ...blank, ...p } ) }
								>
									{ p.name }
								</Button>
							) ) }
						</div>
					</Empty>
				) : (
					<div className="hdh-table-wrap">
						<table className="hdh-table">
							<tbody>
								{ list.map( ( a, i ) => (
									<tr key={ a.id }>
										<td style={ { width: 1 } }>
											<Switch
												label={ a.name }
												checked={ a.enabled }
												disabled={ busy }
												onChange={ ( on ) =>
													persist(
														list.map( ( x, n ) =>
															n === i ? { ...x, enabled: on } : x
														)
													)
												}
											/>
										</td>
										<td>
											<button
												type="button"
												className="hdh-strong-link hdh-link-button"
												onClick={ () => setEditing( a ) }
											>
												{ a.name }
											</button>
											<div className="hdh-muted">
												{ ( data.triggers[ a.trigger ] || [ '' ] )[ 0 ].replace(
													'…',
													String( a.hours )
												) }
												{ ' · ' }
												{ sprintf(
													/* translators: %d: number of actions */
													__( '%d actions', 'helpdesk-hero-pro' ),
													a.actions.length
												) }
											</div>
										</td>
										<td style={ { width: 1, whiteSpace: 'nowrap' } }>
											<Button size="sm" variant="ghost" disabled={ i === 0 || busy } onClick={ () => move( i, -1 ) } aria-label={ __( 'Move up', 'helpdesk-hero-pro' ) }>
												↑
											</Button>
											<Button size="sm" variant="ghost" disabled={ i === list.length - 1 || busy } onClick={ () => move( i, 1 ) } aria-label={ __( 'Move down', 'helpdesk-hero-pro' ) }>
												↓
											</Button>
											<Button
												size="sm"
												variant="ghost"
												icon="trash"
												aria-label={ __( 'Delete automation', 'helpdesk-hero-pro' ) }
												onClick={ async () => {
													if (
														await confirmAction(
															sprintf(
																/* translators: %s: automation */
																__( 'Delete “%s”?', 'helpdesk-hero-pro' ),
																a.name
															),
															{ confirmText: __( 'Delete', 'helpdesk-hero-pro' ) }
														)
													) {
														persist( list.filter( ( _, n ) => n !== i ) );
													}
												} }
											/>
										</td>
									</tr>
								) ) }
							</tbody>
						</table>
					</div>
				) }
			</Card>
			{ list.length > 0 && (
				<Card title={ __( 'Start from a ready-made one', 'helpdesk-hero-pro' ) }>
					<div className="hdh-row">
						{ presets().map( ( p ) => (
							<Button key={ p.name } size="sm" onClick={ () => setEditing( { ...blank, ...p } ) }>
								{ p.name }
							</Button>
						) ) }
					</div>
				</Card>
			) }
			{ editing && (
				<Editor
					automation={ editing }
					meta={ data }
					onClose={ () => setEditing( null ) }
					onSave={ ( a ) => {
						const next = a.id
							? list.map( ( x ) => ( x.id === a.id ? a : x ) )
							: [ ...list, a ];
						persist( next ).then( () => setEditing( null ) );
					} }
				/>
			) }
		</>
	);
}

/**
 * Manual automations as buttons on a ticket.
 *
 * @param {Object} props        Props.
 * @param {Object} props.ticket Ticket.
 * @return {JSX.Element|null} Card.
 */
export function QuickActions( { ticket } ) {
	const { data } = useApi( 'automations/manual' );
	const [ busy, setBusy ] = useState( '' );
	const toast = useToast();
	if ( ! data || ! data.automations.length || ( window.hdhBoot || {} ).canSupport === false ) {
		return null;
	}
	return (
		<Card title={ __( 'Quick actions', 'helpdesk-hero-pro' ) }>
			<div className="hdh-row" style={ { gap: 6 } }>
				{ data.automations.map( ( a ) => (
					<Button
						key={ a.id }
						size="sm"
						icon="bolt"
						disabled={ !! busy }
						onClick={ () => {
							setBusy( a.id );
							send( `automations/${ a.id }/run/${ ticket.id }`, 'POST' )
								.then( ( r ) => {
									toast(
										r.done.length
											? r.done.join( ', ' )
											: __( 'Nothing to do', 'helpdesk-hero-pro' )
									);
									window.location.reload();
								} )
								.catch( ( e ) => toast( errorText( e ), 'alert' ) )
								.finally( () => setBusy( '' ) );
						} }
					>
						{ a.name }
					</Button>
				) ) }
			</div>
		</Card>
	);
}
