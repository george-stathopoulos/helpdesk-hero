/**
 * Reports › Team: how each supporter is doing over a period.
 */
import { __, sprintf } from '@wordpress/i18n';
import { useState, useEffect } from '@wordpress/element';
import { addQueryArgs } from '@wordpress/url';
import { send } from './ui/lib/hooks';
import { Card, PageHead, ErrorNotice, Loading, Empty } from './ui/components/ui';

const PRESETS = [
	[ 7, __( '7 days', 'helpdesk-hero-pro' ) ],
	[ 30, __( '30 days', 'helpdesk-hero-pro' ) ],
	[ 90, __( '90 days', 'helpdesk-hero-pro' ) ],
	[ 365, __( '12 months', 'helpdesk-hero-pro' ) ],
];

function daysAgo( d ) {
	return new Date( Date.now() - d * 86400000 ).toISOString().slice( 0, 10 );
}

function hours( h ) {
	if ( h === null || h === undefined ) {
		return '—';
	}
	if ( h < 1 ) {
		/* translators: %d: minutes */
		return sprintf( __( '%d min', 'helpdesk-hero-pro' ), Math.round( h * 60 ) );
	}
	if ( h >= 48 ) {
		/* translators: %s: days */
		return sprintf( __( '%s days', 'helpdesk-hero-pro' ), ( h / 24 ).toFixed( 1 ) );
	}
	/* translators: %s: hours */
	return sprintf( __( '%s h', 'helpdesk-hero-pro' ), h );
}

export default function TeamReport() {
	const [ range, setRange ] = useState( { from: daysAgo( 29 ), to: daysAgo( 0 ) } );
	const [ data, setData ] = useState( null );
	const [ error, setError ] = useState( null );
	const [ sort, setSort ] = useState( { by: 'assigned', dir: -1 } );
	useEffect( () => {
		setError( null );
		send( addQueryArgs( 'analytics/team', range ) )
			.then( setData )
			.catch( setError );
	}, [ range.from, range.to ] ); // eslint-disable-line react-hooks/exhaustive-deps

	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ () => setRange( { ...range } ) } />;
	}
	if ( ! data ) {
		return <Loading />;
	}
	const days = Math.round( ( new Date( data.to ) - new Date( data.from ) ) / 86400000 ) + 1;
	const preset = PRESETS.find( ( [ d ] ) => d === days && data.to === daysAgo( 0 ) );
	const cols = [
		[ 'assigned', __( 'Assigned', 'helpdesk-hero-pro' ), __( 'Tickets opened in the period and assigned to them.', 'helpdesk-hero-pro' ) ],
		[ 'resolved', __( 'Resolved', 'helpdesk-hero-pro' ), __( 'Of those, how many are closed.', 'helpdesk-hero-pro' ) ],
		[ 'replies', __( 'Replies', 'helpdesk-hero-pro' ), __( 'Replies they sent to customers in the period (notes not counted).', 'helpdesk-hero-pro' ) ],
		[ 'replies_to_resolve', __( 'Replies to resolve', 'helpdesk-hero-pro' ), __( 'Average replies their closed tickets needed. Lower usually means clearer answers.', 'helpdesk-hero-pro' ) ],
		[ 'first_response', __( 'First reply', 'helpdesk-hero-pro' ), __( 'Median time to the first reply on their tickets.', 'helpdesk-hero-pro' ) ],
		[ 'resolution', __( 'Resolution', 'helpdesk-hero-pro' ), __( 'Median time from opening to closing their tickets.', 'helpdesk-hero-pro' ) ],
		[ 'sla_met', __( 'SLA met', 'helpdesk-hero-pro' ), __( 'Share of response and resolution targets met on their tickets.', 'helpdesk-hero-pro' ) ],
		[ 'rating', __( 'Happiness', 'helpdesk-hero-pro' ), __( 'Average customer rating on their tickets (1–5 stars).', 'helpdesk-hero-pro' ) ],
		...( data.time
			? [ [ 'hours', __( 'Handling time', 'helpdesk-hero-pro' ), __( 'Time they logged in the period.', 'helpdesk-hero-pro' ) ] ]
			: [] ),
	];
	const show = ( row, key ) => {
		const v = row[ key ];
		if ( key === 'first_response' || key === 'resolution' || key === 'hours' ) {
			return hours( v );
		}
		if ( key === 'sla_met' ) {
			return v === null ? '—' : `${ v }%`;
		}
		if ( key === 'rating' ) {
			return v === null ? '—' : `${ v } ★ (${ row.ratings })`;
		}
		return v === null || v === undefined ? '—' : v;
	};
	const rows = [ ...data.rows ].sort( ( a, b ) => {
		const x = a[ sort.by ] ?? -1;
		const y = b[ sort.by ] ?? -1;
		return x === y ? a.name.localeCompare( b.name ) : ( x > y ? 1 : -1 ) * sort.dir;
	} );
	return (
		<>
			<PageHead
				title={ __( 'Team', 'helpdesk-hero-pro' ) }
				lede={ sprintf(
					/* translators: 1: start date, 2: end date */
					__( 'How each supporter is doing, %1$s – %2$s. Click a name to see their tickets.', 'helpdesk-hero-pro' ),
					data.from,
					data.to
				) }
			/>
			<div className="hdh-card" style={ { marginBottom: 16 } }>
				<div className="hdh-explorer__bar">
					<div className="hdh-tabs" role="group" aria-label={ __( 'Period', 'helpdesk-hero-pro' ) }>
						{ PRESETS.map( ( [ d, label ] ) => (
							<button
								key={ d }
								type="button"
								aria-pressed={ !! preset && preset[ 0 ] === d }
								className={ `hdh-tabs__tab ${ preset && preset[ 0 ] === d ? 'is-active' : '' }` }
								onClick={ () => setRange( { from: daysAgo( d - 1 ), to: daysAgo( 0 ) } ) }
							>
								{ label }
							</button>
						) ) }
					</div>
					<input
						type="date"
						className="hdh-input"
						aria-label={ __( 'From', 'helpdesk-hero-pro' ) }
						value={ range.from }
						onChange={ ( e ) => setRange( { ...range, from: e.target.value } ) }
					/>
					<input
						type="date"
						className="hdh-input"
						aria-label={ __( 'Until', 'helpdesk-hero-pro' ) }
						value={ range.to }
						onChange={ ( e ) => setRange( { ...range, to: e.target.value } ) }
					/>
				</div>
			</div>
			<Card bodyClass={ null }>
				{ ! rows.length ? (
					<Empty compact title={ __( 'Nothing in this period.', 'helpdesk-hero-pro' ) } />
				) : (
					<div className="hdh-table-wrap">
						<table className="hdh-table">
							<thead>
								<tr>
									<th scope="col">{ __( 'Supporter', 'helpdesk-hero-pro' ) }</th>
									{ cols.map( ( [ key, label, tip ] ) => (
										<th
											key={ key }
											scope="col"
											title={ tip }
											aria-sort={
												sort.by === key ? ( sort.dir > 0 ? 'ascending' : 'descending' ) : undefined
											}
										>
											<button
												type="button"
												className="hdh-link-button"
												onClick={ () =>
													setSort( {
														by: key,
														dir: sort.by === key ? -sort.dir : -1,
													} )
												}
											>
												{ label }
												{ sort.by === key ? ( sort.dir > 0 ? ' ↑' : ' ↓' ) : '' }
											</button>
										</th>
									) ) }
								</tr>
							</thead>
							<tbody>
								{ rows.map( ( r ) => (
									<tr key={ r.id }>
										<td>
											<a href={ `#/inbox?assignee=${ r.id }&status=all` }>{ r.name }</a>
										</td>
										{ cols.map( ( [ key ] ) => (
											<td key={ key }>{ show( r, key ) }</td>
										) ) }
									</tr>
								) ) }
								<tr className="hdh-table__total">
									<td>
										<strong>{ __( 'Whole team', 'helpdesk-hero-pro' ) }</strong>
									</td>
									{ cols.map( ( [ key ] ) => (
										<td key={ key }>
											<strong>{ key === 'replies_to_resolve' ? '—' : show( data.total, key ) }</strong>
										</td>
									) ) }
								</tr>
							</tbody>
						</table>
					</div>
				) }
			</Card>
			<details className="hdh-details" style={ { marginTop: 12 } }>
				<summary>{ __( 'What these numbers mean', 'helpdesk-hero-pro' ) }</summary>
				<ul className="hdh-plain-list" style={ { marginTop: 8 } }>
					{ cols.map( ( [ key, label, tip ] ) => (
						<li key={ key }>
							<strong>{ label }:</strong> { tip }
						</li>
					) ) }
				</ul>
			</details>
		</>
	);
}
