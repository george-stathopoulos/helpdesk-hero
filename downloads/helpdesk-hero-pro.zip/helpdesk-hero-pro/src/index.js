/**
 * Helpdesk Hero Pro: pages and panels for the hub dashboard, registered through the hub's
 * `helpdeskHeroHub.*` filters.
 */
import { __, sprintf } from '@wordpress/i18n';
import { addFilter } from '@wordpress/hooks';
import { useState, useEffect } from '@wordpress/element';
import { useApi, send } from './ui/lib/hooks';
import { ago } from './ui/lib/time';
import {
	Card,
	PageHead,
	Setting,
	Switch,
	Button,
	ErrorNotice,
	Loading,
	Pill,
	useToast,
} from './ui/components/ui';
import {
	TextField,
	TextArea,
	SelectField,
	KeyValues,
	Check,
	LocalAiHint,
	confirmAction,
} from './ui/components/kit';
import { SaveBar } from './ui/lib/settings';
import Icon from './ui/components/Icon';
import Analytics from './Analytics';
import Helpdesk from './Helpdesk';

const pro = window.hdhProBoot || {};

function errorText( e ) {
	return (
		( e && e.message ) || __( 'Something went wrong.', 'helpdesk-hero-pro' )
	);
}

/* ------------------------------------------------------------------ White label */

/**
 * The customer's help center under the support team's name, logo, colour, links and text,
 * with a live preview of the header customers see.
 *
 * @param {Object}   props       Props.
 * @param {Object}   props.draft Settings draft.
 * @param {Function} props.set   Setter factory: set( key )( value ).
 * @return {JSX.Element} Card.
 */
function WhiteLabelCard( { draft, set } ) {
	const color = draft.brand_color || '#4a3aa7';
	const chooseLogo = () => {
		if ( ! window.wp || ! window.wp.media ) {
			return;
		}
		const frame = window.wp.media( {
			title: __( 'Choose a logo', 'helpdesk-hero-pro' ),
			library: { type: 'image' },
			multiple: false,
		} );
		frame.on( 'select', () => {
			const file = frame.state().get( 'selection' ).first().toJSON();
			set( 'brand_logo' )( file.url );
		} );
		frame.open();
	};
	return (
		<Card
			title={ __( 'White label', 'helpdesk-hero-pro' ) }
			sub={ __(
				'Your customers’ help center under your name: logo, colour, links and text. Saving sends it to every connected site.',
				'helpdesk-hero-pro'
			) }
		>
			<div
				className="hdh-wl-preview"
				aria-label={ __( 'Preview', 'helpdesk-hero-pro' ) }
				role="img"
			>
				<span
					className="hdh-wl-preview__mark"
					style={ { background: color } }
				>
					{ draft.brand_logo ? (
						<img src={ draft.brand_logo } alt="" />
					) : (
						<Icon name="ring" size={ 18 } />
					) }
				</span>
				<span>
					<strong>
						{ draft.brand_name ||
							__( 'Get Help', 'helpdesk-hero-pro' ) }
					</strong>
					<small>
						{ sprintf(
							/* translators: %s: support team name */
							__( 'from %s', 'helpdesk-hero-pro' ),
							( window.hdhBoot || {} ).teamName || ''
						) }
					</small>
				</span>
				<span
					className="hdh-wl-preview__button"
					style={ { background: color } }
				>
					{ __( 'New ticket', 'helpdesk-hero-pro' ) }
				</span>
			</div>
			<div className="hdh-form-grid" style={ { marginTop: 16 } }>
				<TextField
					label={ __( 'Help center name', 'helpdesk-hero-pro' ) }
					value={ draft.brand_name }
					onChange={ set( 'brand_name' ) }
					help={ __(
						'Replaces “Get Help” in your customers’ menu, admin bar and screens, e.g. “Acme Care”.',
						'helpdesk-hero-pro'
					) }
				/>
				<div className="hdh-field">
					<label htmlFor="hhp-color">
						{ __( 'Brand colour', 'helpdesk-hero-pro' ) }
					</label>
					<div className="hdh-row">
						<input
							id="hhp-color"
							type="color"
							value={ color }
							onChange={ ( e ) =>
								set( 'brand_color' )( e.target.value )
							}
							className="hdh-color"
						/>
						<code>{ color }</code>
						{ draft.brand_color && (
							<Button
								size="sm"
								variant="ghost"
								onClick={ () => set( 'brand_color' )( '' ) }
							>
								{ __( 'Reset', 'helpdesk-hero-pro' ) }
							</Button>
						) }
					</div>
				</div>
				<div className="hdh-field is-wide">
					<span className="hdh-field__label">
						{ __( 'Logo', 'helpdesk-hero-pro' ) }
					</span>
					<div className="hdh-row">
						<Button size="sm" onClick={ chooseLogo }>
							<Icon name="upload" size={ 14 } />
							{ __(
								'Choose from the Media Library',
								'helpdesk-hero-pro'
							) }
						</Button>
						{ draft.brand_logo && (
							<Button
								size="sm"
								variant="ghost"
								onClick={ () => set( 'brand_logo' )( '' ) }
							>
								{ __( 'Remove', 'helpdesk-hero-pro' ) }
							</Button>
						) }
					</div>
					<TextField
						label={ __(
							'or a logo URL (https)',
							'helpdesk-hero-pro'
						) }
						type="url"
						value={ draft.brand_logo }
						onChange={ set( 'brand_logo' ) }
						help={ __(
							'Square works best, at least 64×64 pixels.',
							'helpdesk-hero-pro'
						) }
					/>
				</div>
				<TextField
					label={ __( 'Help center link', 'helpdesk-hero-pro' ) }
					type="url"
					value={ draft.brand_url }
					onChange={ set( 'brand_url' ) }
					help={ __(
						'Your knowledge base or support page, linked at the top of the help center.',
						'helpdesk-hero-pro'
					) }
				/>
				<TextArea
					label={ __( 'Contact and hours', 'helpdesk-hero-pro' ) }
					value={ draft.brand_contact }
					onChange={ set( 'brand_contact' ) }
					rows={ 3 }
					help={ __(
						'Shown next to the ticket form, e.g. phone, hours, response times.',
						'helpdesk-hero-pro'
					) }
				/>
				<TextArea
					className="is-wide"
					label={ __(
						'Note on the New ticket screen',
						'helpdesk-hero-pro'
					) }
					value={ draft.brand_intro }
					onChange={ set( 'brand_intro' ) }
					rows={ 3 }
					help={ __(
						'Replaces the note from your support policy.',
						'helpdesk-hero-pro'
					) }
				/>
			</div>
		</Card>
	);
}

/* ------------------------------------------------------------------ Supporters */

/**
 * Choose which hub users reply to customers and log in to their sites, and the name customers
 * see for each. Customer sites then give every supporter their own temporary account.
 *
 * @return {JSX.Element} Card.
 */
function SupportersCard() {
	const { data, error, reload } = useApi( 'supporters' );
	const [ rows, setRows ] = useState( null );
	const [ saving, setSaving ] = useState( false );
	const toast = useToast();

	useEffect( () => {
		if ( data ) {
			setRows( data.supporters );
		}
	}, [ data ] );

	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ reload } />;
	}
	if ( ! data || ! rows ) {
		return <Loading />;
	}
	const dirty = JSON.stringify( rows ) !== JSON.stringify( data.supporters );
	const find = ( id ) => rows.find( ( r ) => r.user_id === id );
	const toggle = ( user, on ) =>
		setRows(
			on
				? [ ...rows, { user_id: user.user_id, name: user.name } ]
				: rows.filter( ( r ) => r.user_id !== user.user_id )
		);
	const rename = ( id, name ) =>
		setRows(
			rows.map( ( r ) => ( r.user_id === id ? { ...r, name } : r ) )
		);
	const save = () => {
		setSaving( true );
		send( 'supporters', 'POST', { supporters: rows } )
			.then( () => {
				toast( __( 'Supporters saved', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setSaving( false ) );
	};

	return (
		<Card
			title={ __( 'Supporters', 'helpdesk-hero-pro' ) }
			sub={ __(
				'Choose who replies to customers and logs in to their sites, and the name customers see. Each supporter gets their own temporary account on a customer’s site, deleted when access ends. With nobody chosen, everyone with hub access can support.',
				'helpdesk-hero-pro'
			) }
			bodyClass={ null }
		>
			<div className="hdh-table-wrap">
				<table className="hdh-table">
					<thead>
						<tr>
							<th scope="col">
								{ __( 'Team member', 'helpdesk-hero-pro' ) }
							</th>
							<th scope="col">
								{ __( 'Supporter', 'helpdesk-hero-pro' ) }
							</th>
							<th scope="col">
								{ __(
									'Name customers see',
									'helpdesk-hero-pro'
								) }
							</th>
						</tr>
					</thead>
					<tbody>
						{ data.users.map( ( u ) => {
							const row = find( u.user_id );
							return (
								<tr key={ u.user_id }>
									<td>
										<strong>{ u.name }</strong>
										<div className="hdh-muted">
											{ u.email } · { u.role }
										</div>
									</td>
									<td>
										<Check
											label={ sprintf(
												/* translators: %s: user name */
												__(
													'%s is a supporter',
													'helpdesk-hero-pro'
												),
												u.name
											) }
											hideLabel
											checked={ !! row }
											onChange={ ( on ) =>
												toggle( u, on )
											}
										/>
									</td>
									<td>
										{ row ? (
											<TextField
												label={ sprintf(
													/* translators: %s: user name */
													__(
														'Name customers see for %s',
														'helpdesk-hero-pro'
													),
													u.name
												) }
												hideLabel
												value={ row.name }
												onChange={ ( name ) =>
													rename( u.user_id, name )
												}
											/>
										) : (
											<span className="hdh-muted">—</span>
										) }
									</td>
								</tr>
							);
						} ) }
					</tbody>
				</table>
			</div>
			<div
				className="hdh-row"
				style={ {
					padding: '14px 20px',
					justifyContent: 'space-between',
				} }
			>
				<a
					className="hdh-btn is-ghost is-sm"
					href={ `${
						( window.hdhBoot || {} ).adminUrl
					}user-new.php` }
				>
					<Icon name="user" size={ 15 } />
					{ __(
						'Add a team member (Support Agent role)',
						'helpdesk-hero-pro'
					) }
				</a>
				<Button
					variant="primary"
					disabled={ ! dirty || saving }
					onClick={ save }
				>
					{ __( 'Save supporters', 'helpdesk-hero-pro' ) }
				</Button>
			</div>
		</Card>
	);
}

/* ------------------------------------------------------------------ Pro page */

function ProPage() {
	const { data, error, reload } = useApi( 'settings' );
	const [ draft, setDraft ] = useState( null );
	const [ key, setKey ] = useState( '' );
	const [ busy, setBusy ] = useState( '' );
	const toast = useToast();

	useEffect( () => {
		if ( data ) {
			setDraft( data.settings );
		}
	}, [ data ] );

	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ reload } />;
	}
	if ( ! data || ! draft ) {
		return <Loading />;
	}
	const lic = data.license;
	const set = ( k ) => ( v ) => setDraft( ( d ) => ( { ...d, [ k ]: v } ) );
	const dirty = JSON.stringify( draft ) !== JSON.stringify( data.settings );

	const license = ( op ) => {
		setBusy( op );
		send( 'license', 'POST', { op, key } )
			.then( () => {
				if ( op === 'activate' || op === 'deactivate' ) {
					window.location.reload();
					return;
				}
				toast( __( 'License checked', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( '' ) );
	};
	const save = () => {
		setBusy( 'save' );
		send( 'settings', 'POST', draft )
			.then( ( r ) => {
				toast(
					sprintf(
						/* translators: %d: number of sites */
						__(
							'Saved. Branding sent to %d sites.',
							'helpdesk-hero-pro'
						),
						r.sent
					)
				);
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( '' ) );
	};

	return (
		<>
			<PageHead
				title={ __( 'Helpdesk Hero Pro', 'helpdesk-hero-pro' ) }
				lede={ __(
					'AI triage and reply drafts, white label for customer sites, supporters, messages to every site, and a Support Agent role.',
					'helpdesk-hero-pro'
				) }
			/>
			<div className="hdh-split">
				<div className="hdh-split__main">
					{ lic.active ? (
						<>
							<Card
								title={ __( 'AI triage', 'helpdesk-hero-pro' ) }
								sub={
									data.ai
										? __(
												'Uses this site’s AI provider (Settings › Connectors).',
												'helpdesk-hero-pro'
										  )
										: __(
												'Connect an AI provider in Settings › Connectors (WordPress 7.0+) to use AI features.',
												'helpdesk-hero-pro'
										  )
								}
								bodyClass={ null }
							>
								<div style={ { padding: '0 20px' } }>
									<LocalAiHint
										local={
											( window.hdhBoot || {} ).localAi
										}
										enabled={ data.ai }
									/>
								</div>
								<Setting
									title={ __(
										'Write a triage brief for every new ticket',
										'helpdesk-hero-pro'
									) }
									desc={ __(
										'Summary, likely cause, suspects, first steps and what to ask. Written in the background, so customers never wait.',
										'helpdesk-hero-pro'
									) }
								>
									<Switch
										label={ __(
											'Auto triage',
											'helpdesk-hero-pro'
										) }
										checked={ draft.auto_triage }
										onChange={ set( 'auto_triage' ) }
									/>
								</Setting>
								<Setting
									title={ __(
										'Add the brief to the help desk as an internal note',
										'helpdesk-hero-pro'
									) }
								>
									<Switch
										label={ __(
											'Triage note',
											'helpdesk-hero-pro'
										) }
										checked={ draft.triage_note }
										onChange={ set( 'triage_note' ) }
									/>
								</Setting>
							</Card>
							<WhiteLabelCard draft={ draft } set={ set } />
							<SupportersCard />
						</>
					) : (
						<Card>
							<p>
								{ __(
									'Activate your license to switch on Pro features.',
									'helpdesk-hero-pro'
								) }
							</p>
						</Card>
					) }
				</div>
				<aside className="hdh-split__side">
					<Card title={ __( 'License', 'helpdesk-hero-pro' ) }>
						{ lic.active ? (
							<div className="hdh-stack">
								<Pill tone="good" icon="check">
									{ __( 'Active', 'helpdesk-hero-pro' ) }
								</Pill>
								<KeyValues
									rows={ [
										[
											__( 'Key', 'helpdesk-hero-pro' ),
											lic.key,
										],
										lic.expires_at
											? [
													__(
														'Renews',
														'helpdesk-hero-pro'
													),
													ago( lic.expires_at ),
											  ]
											: null,
									] }
								/>
								{ lic.grace && (
									<p className="hdh-muted">{ lic.error }</p>
								) }
								<div className="hdh-row">
									<Button
										size="sm"
										icon="refresh"
										disabled={ !! busy }
										onClick={ () => license( 'check' ) }
									>
										{ __(
											'Check now',
											'helpdesk-hero-pro'
										) }
									</Button>
									<Button
										size="sm"
										variant="ghost"
										disabled={ !! busy }
										onClick={ () =>
											license( 'deactivate' )
										}
									>
										{ __(
											'Deactivate here',
											'helpdesk-hero-pro'
										) }
									</Button>
								</div>
							</div>
						) : (
							<div className="hdh-stack">
								{ lic.error && (
									<p
										style={ {
											color: 'var(--hdh-critical-ink)',
										} }
									>
										{ lic.error }
									</p>
								) }
								<TextField
									label={ __(
										'License key',
										'helpdesk-hero-pro'
									) }
									value={ key }
									onChange={ setKey }
									autoComplete="off"
									help={
										lic.test_site
											? __(
													'Trying Pro? Enter TEST as the license key.',
													'helpdesk-hero-pro'
											  )
											: undefined
									}
								/>
								<div className="hdh-row">
									<Button
										variant="primary"
										icon="key"
										disabled={ ! key.trim() || !! busy }
										onClick={ () => license( 'activate' ) }
									>
										{ __(
											'Activate',
											'helpdesk-hero-pro'
										) }
									</Button>
									{ data.buy_url && (
										<a
											className="hdh-btn"
											href={ data.buy_url }
											target="_blank"
											rel="noopener noreferrer"
										>
											{ __(
												'Buy a license',
												'helpdesk-hero-pro'
											) }
										</a>
									) }
								</div>
							</div>
						) }
					</Card>
				</aside>
			</div>
			{ lic.active && (
				<SaveBar
					dirty={ dirty }
					saving={ busy === 'save' }
					save={ save }
					discard={ () => setDraft( data.settings ) }
				/>
			) }
		</>
	);
}

/* ------------------------------------------------------------------ Triage panel */

function TriagePanel( { ticket } ) {
	const { data, error, reload } = useApi( `triage/${ ticket.id }` );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();

	useEffect( () => {
		if ( data && data.queued && ! data.brief ) {
			const t = window.setTimeout( reload, 5000 );
			return () => window.clearTimeout( t );
		}
		return undefined;
	}, [ data, reload ] );

	const regenerate = () => {
		setBusy( true );
		send( `triage/${ ticket.id }`, 'POST' )
			.then( reload )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};

	const b = data && data.brief;
	let emptyText = __( 'No brief yet.', 'helpdesk-hero-pro' );
	if ( data && ! data.ai ) {
		emptyText = __(
			'Connect an AI provider in Settings › Connectors to get triage briefs.',
			'helpdesk-hero-pro'
		);
	} else if ( busy || ( data && data.queued ) ) {
		emptyText = __( 'Writing the brief…', 'helpdesk-hero-pro' );
	}
	return (
		<Card
			title={ __( 'AI triage', 'helpdesk-hero-pro' ) }
			action={
				data && data.ai ? (
					<Button
						size="sm"
						variant="ghost"
						icon="refresh"
						disabled={ busy }
						onClick={ regenerate }
					>
						{ b
							? __( 'Again', 'helpdesk-hero-pro' )
							: __( 'Write it', 'helpdesk-hero-pro' ) }
					</Button>
				) : null
			}
		>
			{ error && <p className="hdh-muted">{ errorText( error ) }</p> }
			{ ! data && ! error && (
				<p className="hdh-muted">
					{ __( 'Loading…', 'helpdesk-hero-pro' ) }
				</p>
			) }
			{ data && ! b && <p className="hdh-muted">{ emptyText }</p> }
			{ data && ! b && (
				<LocalAiHint
					local={ ( window.hdhBoot || {} ).localAi }
					enabled={ data.ai }
				/>
			) }
			{ b && (
				<div className="hdh-stack" style={ { gap: 10 } }>
					<strong>{ b.summary }</strong>
					<div className="hdh-row" style={ { gap: 6 } }>
						<Pill
							tone={
								{ high: 'good', medium: 'warning' }[
									b.confidence
								] || ''
							}
						>
							{ sprintf(
								/* translators: %s: low, medium or high */
								__( 'Confidence: %s', 'helpdesk-hero-pro' ),
								b.confidence
							) }
						</Pill>
						{ b.priority !== ticket.priority && (
							<Pill tone="accent">
								{ sprintf(
									/* translators: %s: priority */
									__(
										'Suggested priority: %s',
										'helpdesk-hero-pro'
									),
									b.priority
								) }
							</Pill>
						) }
					</div>
					<p>{ b.likely_cause }</p>
					{ b.suspects.length > 0 && (
						<div>
							<div className="hdh-section-title">
								{ __( 'Suspects', 'helpdesk-hero-pro' ) }
							</div>
							<ul
								style={ {
									margin: '0 0 0 16px',
									listStyle: 'disc',
								} }
							>
								{ b.suspects.map( ( s, i ) => (
									<li key={ i }>
										<strong>{ s.name }</strong> —{ ' ' }
										{ s.reason }
									</li>
								) ) }
							</ul>
						</div>
					) }
					{ b.first_steps.length > 0 && (
						<div>
							<div className="hdh-section-title">
								{ __( 'First steps', 'helpdesk-hero-pro' ) }
							</div>
							<ol style={ { margin: '0 0 0 18px' } }>
								{ b.first_steps.map( ( s, i ) => (
									<li key={ i }>{ s }</li>
								) ) }
							</ol>
						</div>
					) }
					{ b.ask_customer.length > 0 && (
						<div>
							<div className="hdh-section-title">
								{ __(
									'Ask the customer',
									'helpdesk-hero-pro'
								) }
							</div>
							<ol style={ { margin: '0 0 0 18px' } }>
								{ b.ask_customer.map( ( s, i ) => (
									<li key={ i }>{ s }</li>
								) ) }
							</ol>
						</div>
					) }
				</div>
			) }
		</Card>
	);
}

/* ------------------------------------------------------------------ Draft tool */

function DraftTool( { ticket, setBody } ) {
	const [ hint, setHint ] = useState( '' );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	if ( ! ( window.hdhBoot || {} ).aiEnabled ) {
		return null;
	}
	const draft = () => {
		setBusy( true );
		send( `draft/${ ticket.id }`, 'POST', { hint } )
			.then( ( r ) => setBody( r.draft ) )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	return (
		<div className="hdh-row">
			<input
				className="hdh-input"
				style={ { flex: 1, minWidth: 200 } }
				aria-label={ __(
					'What should the reply say?',
					'helpdesk-hero-pro'
				) }
				placeholder={ __(
					'Optional: what should the reply say?',
					'helpdesk-hero-pro'
				) }
				value={ hint }
				onChange={ ( e ) => setHint( e.target.value ) }
			/>
			<Button icon="spark" disabled={ busy } onClick={ draft }>
				{ busy
					? __( 'Drafting…', 'helpdesk-hero-pro' )
					: __( 'Draft with AI', 'helpdesk-hero-pro' ) }
			</Button>
		</div>
	);
}

/* ------------------------------------------------------------------ Broadcast */

function BroadcastPanel( { sites } ) {
	const empty = {
		title: '',
		body: '',
		level: 'info',
		action_label: '',
		action_url: '',
	};
	const [ open, setOpen ] = useState( false );
	const [ n, setN ] = useState( empty );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	const count = sites.filter( ( s ) => s.status === 'active' ).length;
	const set = ( k ) => ( v ) => setN( ( s ) => ( { ...s, [ k ]: v } ) );
	if ( ! count ) {
		return null;
	}
	const sendAll = async () => {
		if (
			! ( await confirmAction(
				__(
					'Send this message to every connected site?',
					'helpdesk-hero-pro'
				)
			) )
		) {
			return;
		}
		setBusy( true );
		send( 'broadcast', 'POST', n )
			.then( ( r ) => {
				toast(
					sprintf(
						/* translators: %d: number of sites */
						__( 'Message sent to %d sites', 'helpdesk-hero-pro' ),
						r.sent
					)
				);
				setN( empty );
				setOpen( false );
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	return (
		<Card
			style={ { marginBottom: 18 } }
			title={ __( 'Message every site', 'helpdesk-hero-pro' ) }
			sub={ sprintf(
				/* translators: %d: number of sites */
				__(
					'A notice in wp-admin on all %d connected sites: security releases, outages, new versions.',
					'helpdesk-hero-pro'
				),
				count
			) }
			action={
				! open && (
					<Button
						size="sm"
						icon="message"
						onClick={ () => setOpen( true ) }
					>
						{ __( 'Write a message', 'helpdesk-hero-pro' ) }
					</Button>
				)
			}
		>
			{ open && (
				<div className="hdh-form-grid">
					<TextField
						className="is-wide"
						label={ __( 'Title', 'helpdesk-hero-pro' ) }
						value={ n.title }
						onChange={ set( 'title' ) }
					/>
					<TextArea
						className="is-wide"
						label={ __( 'Message', 'helpdesk-hero-pro' ) }
						value={ n.body }
						onChange={ set( 'body' ) }
						rows={ 3 }
					/>
					<SelectField
						label={ __( 'Type', 'helpdesk-hero-pro' ) }
						value={ n.level }
						onChange={ set( 'level' ) }
						options={ [
							{
								value: 'info',
								label: __( 'Information', 'helpdesk-hero-pro' ),
							},
							{
								value: 'warning',
								label: __(
									'Action needed',
									'helpdesk-hero-pro'
								),
							},
							{
								value: 'error',
								label: __( 'Urgent', 'helpdesk-hero-pro' ),
							},
						] }
					/>
					<TextField
						label={ __(
							'Button text (optional)',
							'helpdesk-hero-pro'
						) }
						value={ n.action_label }
						onChange={ set( 'action_label' ) }
					/>
					<TextField
						label={ __( 'Button link', 'helpdesk-hero-pro' ) }
						value={ n.action_url }
						onChange={ set( 'action_url' ) }
						placeholder="admin:update-core.php"
					/>
					<div className="hdh-row is-wide">
						<Button
							variant="primary"
							icon="send"
							disabled={ busy || ! n.title.trim() }
							onClick={ sendAll }
						>
							{ __( 'Send to all sites', 'helpdesk-hero-pro' ) }
						</Button>
						<Button
							variant="ghost"
							onClick={ () => setOpen( false ) }
						>
							{ __( 'Cancel', 'helpdesk-hero-pro' ) }
						</Button>
					</div>
				</div>
			) }
		</Card>
	);
}

/* ------------------------------------------------------------------ Register */

addFilter( 'helpdeskHeroHub.routes', 'helpdesk-hero-pro/route', ( routes ) => {
	let out = [ ...routes ];
	if ( pro.licensed ) {
		// Analytics right after the Overview; the Help desk page gains Help Scout and Zendesk.
		const at = out.findIndex( ( r ) => r.id === 'overview' ) + 1;
		out.splice( at, 0, {
			id: 'analytics',
			label: __( 'Analytics', 'helpdesk-hero-pro' ),
			icon: 'chart',
			Page: Analytics,
		} );
		out = out.map( ( r ) =>
			r.id === 'helpdesk' ? { ...r, Page: Helpdesk } : r
		);
	}
	return [
		...out,
		{
			id: 'pro',
			label: __( 'Pro', 'helpdesk-hero-pro' ),
			icon: 'spark',
			Page: ProPage,
			admin: true,
		},
	];
} );

if ( pro.licensed ) {
	addFilter(
		'helpdeskHeroHub.ticketPanels',
		'helpdesk-hero-pro/triage',
		( panels ) => [ TriagePanel, ...panels ]
	);
	addFilter(
		'helpdeskHeroHub.replyTools',
		'helpdesk-hero-pro/draft',
		( tools ) => [ ...tools, DraftTool ]
	);
	addFilter(
		'helpdeskHeroHub.sitesPanels',
		'helpdesk-hero-pro/broadcast',
		( panels ) => [ ...panels, BroadcastPanel ]
	);
}
