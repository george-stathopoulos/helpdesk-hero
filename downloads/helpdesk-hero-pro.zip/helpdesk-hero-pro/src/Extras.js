/**
 * Custom ticket fields, attachments (settings and the reply tool) and merging tickets.
 */
import { __, sprintf } from '@wordpress/i18n';
import { useState, useEffect, useRef } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { useApi, send } from './ui/lib/hooks';
import { Card, Button, Loading, useToast } from './ui/components/ui';
import {
	Check,
	SelectField,
	fileSize,
	confirmAction,
} from './ui/components/kit';
import Icon from './ui/components/Icon';
import { errorText } from './Workflow';

const hub = window.hdhBoot || {};

/**
 * Whether a site's plugin version is at least 2.1 (attachments and fields need it).
 *
 * @param {string} version Version.
 * @return {boolean} Supported.
 */
function supports( version ) {
	if ( ! version ) {
		return false;
	}
	const [ a, b ] = String( version ).split( '.' ).map( Number );
	return a > 2 || ( a === 2 && b >= 1 );
}

/* ------------------------------------------------------------------ Fields */

export function FieldsCard() {
	const { data, reload } = useApi( 'fields' );
	const [ list, setList ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setList( data.fields );
		}
	}, [ data ] );
	if ( ! data || ! list ) {
		return <Loading />;
	}
	const dirty = JSON.stringify( list ) !== JSON.stringify( data.fields );
	const set = ( i, patch ) =>
		setList( list.map( ( f, n ) => ( n === i ? { ...f, ...patch } : f ) ) );
	const save = () => {
		setBusy( true );
		send( 'fields', 'POST', { fields: list } )
			.then( () => {
				toast(
					__(
						'Fields saved and sent to your sites',
						'helpdesk-hero-pro'
					)
				);
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	const types = Object.keys( data.types ).map( ( k ) => ( {
		value: k,
		label: data.types[ k ],
	} ) );
	return (
		<Card
			title={ __( 'Ticket fields', 'helpdesk-hero-pro' ) }
			sub={ __(
				'Extra questions on the customer’s New ticket screen, such as an order number or which product it’s about. Don’t ask for passwords or keys here. Sites need Helpdesk Hero 2.1 or later to show them.',
				'helpdesk-hero-pro'
			) }
		>
			<div className="hdh-stack" style={ { gap: 12 } }>
				{ list.map( ( f, i ) => (
					<div key={ f.id || `new-${ i }` } className="hdh-tier-edit">
						<div className="hdh-row">
							<input
								className="hdh-input"
								style={ { flex: 1, minWidth: 180 } }
								aria-label={ __( 'Question', 'helpdesk-hero-pro' ) }
								placeholder={ __( 'Order number', 'helpdesk-hero-pro' ) }
								value={ f.label }
								maxLength={ 80 }
								onChange={ ( e ) => set( i, { label: e.target.value } ) }
							/>
							<SelectField
								label={ __( 'Type', 'helpdesk-hero-pro' ) }
								hideLabel
								value={ f.type }
								onChange={ ( v ) => set( i, { type: v } ) }
								options={ types }
							/>
							<Button
								size="sm"
								variant="ghost"
								icon="trash"
								aria-label={ __( 'Delete field', 'helpdesk-hero-pro' ) }
								onClick={ () =>
									setList( list.filter( ( _, n ) => n !== i ) )
								}
							/>
						</div>
						{ f.type === 'select' && (
							<input
								className="hdh-input"
								aria-label={ __(
									'Choices, separated by commas',
									'helpdesk-hero-pro'
								) }
								placeholder={ __(
									'Choices, separated by commas',
									'helpdesk-hero-pro'
								) }
								// Keep what's typed (commas included); the list is read from it.
								value={
									f.options_text ??
									( f.options || [] ).join( ', ' )
								}
								onChange={ ( e ) =>
									set( i, {
										options_text: e.target.value,
										options: e.target.value
											.split( ',' )
											.map( ( o ) => o.trim() )
											.filter( Boolean ),
									} )
								}
							/>
						) }
						<input
							className="hdh-input"
							aria-label={ __( 'Help text', 'helpdesk-hero-pro' ) }
							placeholder={ __(
								'Help text (optional)',
								'helpdesk-hero-pro'
							) }
							value={ f.help || '' }
							maxLength={ 200 }
							onChange={ ( e ) => set( i, { help: e.target.value } ) }
						/>
						{ f.type !== 'checkbox' && (
							<Check
								label={ __( 'Required', 'helpdesk-hero-pro' ) }
								checked={ !! f.required }
								onChange={ ( on ) => set( i, { required: on } ) }
							/>
						) }
					</div>
				) ) }
				<div className="hdh-row">
					<Button
						size="sm"
						icon="plus"
						onClick={ () =>
							setList( [
								...list,
								{
									id: '',
									label: '',
									type: 'text',
									options: [],
									required: false,
									help: '',
								},
							] )
						}
					>
						{ __( 'Add field', 'helpdesk-hero-pro' ) }
					</Button>
					{ dirty && (
						<Button
							size="sm"
							variant="primary"
							disabled={ busy }
							onClick={ save }
						>
							{ __( 'Save fields', 'helpdesk-hero-pro' ) }
						</Button>
					) }
				</div>
			</div>
		</Card>
	);
}

/* ------------------------------------------------------------------ Attachment settings */

export function AttachmentsCard() {
	const { data, reload } = useApi( 'attachments' );
	const [ draft, setDraft ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	useEffect( () => {
		if ( data ) {
			setDraft( data.settings );
		}
	}, [ data ] );
	if ( ! data || ! draft ) {
		return <Loading />;
	}
	const dirty = JSON.stringify( draft ) !== JSON.stringify( data.settings );
	const save = () => {
		setBusy( true );
		send( 'attachments', 'POST', draft )
			.then( () => {
				toast(
					__(
						'Saved and sent to your sites',
						'helpdesk-hero-pro'
					)
				);
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	return (
		<Card
			title={ __( 'Attachments', 'helpdesk-hero-pro' ) }
			sub={ __(
				'Customers attach screenshots and files to tickets and replies, and your team attaches files to replies. Files stay private: they’re stored outside public access and only shown in the dashboards. SVG, HTML and scripts are never accepted.',
				'helpdesk-hero-pro'
			) }
		>
			<div className="hdh-stack" style={ { gap: 12 } }>
				<Check
					label={ __( 'Allow attachments', 'helpdesk-hero-pro' ) }
					desc={ __(
						'Customer sites need Helpdesk Hero 2.1 or later.',
						'helpdesk-hero-pro'
					) }
					checked={ draft.enabled }
					onChange={ ( on ) => setDraft( { ...draft, enabled: on } ) }
				/>
				{ draft.enabled && (
					<>
						<div className="hdh-row" style={ { gap: 16 } }>
							<label className="hdh-inline-field" htmlFor="hdh-att-mb">
								<span>
									{ __( 'Up to', 'helpdesk-hero-pro' ) }
								</span>
								<input
									id="hdh-att-mb"
									type="number"
									min="1"
									max="25"
									className="hdh-input"
									style={ { width: 70 } }
									value={ draft.max_mb }
									onChange={ ( e ) =>
										setDraft( {
											...draft,
											max_mb: parseInt( e.target.value, 10 ) || '',
										} )
									}
								/>
								<span>
									{ __( 'MB per file', 'helpdesk-hero-pro' ) }
								</span>
							</label>
							<label className="hdh-inline-field" htmlFor="hdh-att-n">
								<input
									id="hdh-att-n"
									type="number"
									min="1"
									max="10"
									className="hdh-input"
									style={ { width: 60 } }
									value={ draft.max_files }
									onChange={ ( e ) =>
										setDraft( {
											...draft,
											max_files: parseInt( e.target.value, 10 ) || '',
										} )
									}
								/>
								<span>
									{ __( 'files per message', 'helpdesk-hero-pro' ) }
								</span>
							</label>
						</div>
						<label className="hdh-inline-field" htmlFor="hdh-att-keep">
							<span>{ __( 'Delete files', 'helpdesk-hero-pro' ) }</span>
							<input
								id="hdh-att-keep"
								type="number"
								min="0"
								max="3650"
								className="hdh-input"
								style={ { width: 80 } }
								value={ draft.keep_days ?? 0 }
								onChange={ ( e ) =>
									setDraft( {
										...draft,
										keep_days: e.target.value === '' ? '' : Math.max( 0, parseInt( e.target.value, 10 ) || 0 ),
									} )
								}
							/>
							<span>
								{ __(
									'days after the ticket closes, on your hub and on the customer’s site (0: keep them).',
									'helpdesk-hero-pro'
								) }
							</span>
						</label>
						{ draft.max_mb > data.server && (
							<p className="hdh-muted">
								{ sprintf(
									/* translators: %d: megabytes */
									__(
										'This server accepts uploads up to %d MB, so larger files fail here. Customer sites have their own limits too.',
										'helpdesk-hero-pro'
									),
									data.server
								) }
							</p>
						) }
						<fieldset className="hdh-field">
							<legend className="hdh-field__label">
								{ __( 'File types', 'helpdesk-hero-pro' ) }
							</legend>
							<div className="hdh-row" style={ { gap: 6 } }>
								{ data.types.map( ( t ) => {
									const on = draft.types.includes( t );
									return (
										<button
											key={ t }
											type="button"
											className={ `hdh-tagpill is-toggle ${
												on ? 'is-on' : ''
											}` }
											aria-pressed={ on }
											onClick={ () =>
												setDraft( {
													...draft,
													types: on
														? draft.types.filter(
																( x ) => x !== t
														  )
														: [ ...draft.types, t ],
												} )
											}
										>
											.{ t }
										</button>
									);
								} ) }
							</div>
						</fieldset>
					</>
				) }
				{ dirty && (
					<div>
						<Button variant="primary" disabled={ busy } onClick={ save }>
							{ __( 'Save attachments', 'helpdesk-hero-pro' ) }
						</Button>
					</div>
				) }
			</div>
		</Card>
	);
}

/* ------------------------------------------------------------------ Reply tool */

/**
 * Attach files to a reply: uploads go to the hub first, and their IDs travel with the reply.
 *
 * @param {Object} props Props from the hub's reply box.
 * @return {JSX.Element|null} Tool.
 */
export function AttachTool( { ticket, extra, setExtra } ) {
	const input = useRef( null );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	const config = ticket.attachments || {};
	if ( ! config.enabled ) {
		return null;
	}
	const files = ( extra && extra.files ) || [];
	const version = ticket.site ? ticket.site.version : '';
	const update = ( list ) =>
		setExtra( {
			...extra,
			files: list,
			attachments: list.map( ( f ) => f.id ),
		} );
	const pick = async ( e ) => {
		const chosen = Array.from( e.target.files || [] );
		e.target.value = '';
		if ( files.length + chosen.length > config.max_files ) {
			toast(
				sprintf(
					/* translators: %d: number of files */
					__( 'Up to %d files per reply.', 'helpdesk-hero-pro' ),
					config.max_files
				),
				'alert'
			);
			return;
		}
		setBusy( true );
		const added = [];
		for ( const file of chosen ) {
			if ( file.size > config.max_mb * 1024 * 1024 ) {
				toast(
					sprintf(
						/* translators: 1: file name, 2: megabytes */
						__( '%1$s is larger than %2$d MB.', 'helpdesk-hero-pro' ),
						file.name,
						config.max_mb
					),
					'alert'
				);
				continue;
			}
			const body = new window.FormData();
			body.append( 'file', file );
			try {
				added.push(
					await apiFetch( {
						path: '/helpdesk-hero-hub/v1/admin/attachments',
						method: 'POST',
						body,
					} )
				);
			} catch ( err ) {
				toast( `${ file.name }: ${ errorText( err ) }`, 'alert' );
			}
		}
		update( [ ...files, ...added ] );
		setBusy( false );
	};
	return (
		<div className="hdh-stack" style={ { gap: 6 } }>
			<div className="hdh-row">
				<Button
					size="sm"
					icon="paperclip"
					disabled={ busy }
					onClick={ () => input.current && input.current.click() }
				>
					{ busy
						? __( 'Uploading…', 'helpdesk-hero-pro' )
						: __( 'Attach files', 'helpdesk-hero-pro' ) }
				</Button>
				<input
					ref={ input }
					type="file"
					multiple
					className="hdh-sr"
					tabIndex={ -1 }
					aria-hidden="true"
					accept={ ( config.types || [] ).map( ( t ) => `.${ t }` ).join( ',' ) }
					onChange={ pick }
				/>
				{ ! supports( version ) && (
					<span className="hdh-muted">
						{ __(
							'This site runs an older Helpdesk Hero: the customer sees your reply, but not the files, until they update.',
							'helpdesk-hero-pro'
						) }
					</span>
				) }
			</div>
			{ files.length > 0 && (
				<ul className="hdh-attachments">
					{ files.map( ( f ) => (
						<li key={ f.id }>
							<span className="hdh-attachments__chip">
								<Icon name="file" size={ 14 } />
								<span className="hdh-attachments__name">
									{ f.name }
								</span>
								<span className="hdh-muted">{ fileSize( f.size ) }</span>
								<button
									type="button"
									className="hdh-link-button"
									aria-label={ sprintf(
										/* translators: %s: file name */
										__( 'Remove %s', 'helpdesk-hero-pro' ),
										f.name
									) }
									onClick={ () =>
										update( files.filter( ( x ) => x.id !== f.id ) )
									}
								>
									×
								</button>
							</span>
						</li>
					) ) }
				</ul>
			) }
		</div>
	);
}

/* ------------------------------------------------------------------ Merge */

export function MergePanel( { ticket } ) {
	const [ open, setOpen ] = useState( false );
	if ( ticket.merged_into || hub.canSupport === false ) {
		return null;
	}
	return (
		<Card title={ __( 'Merge', 'helpdesk-hero-pro' ) }>
			{ open ? (
				<MergeChooser ticket={ ticket } onCancel={ () => setOpen( false ) } />
			) : (
				<Button size="sm" icon="merge" onClick={ () => setOpen( true ) }>
					{ __( 'Merge into another ticket…', 'helpdesk-hero-pro' ) }
				</Button>
			) }
		</Card>
	);
}

function MergeChooser( { ticket, onCancel } ) {
	const [ into, setInto ] = useState( '' );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	const { data } = useApi( `merge/${ ticket.id }/candidates` );
	if ( ! data || ! data.tickets ) {
		return <Loading />;
	}
	const merge = async () => {
		const target = data.tickets.find( ( t ) => String( t.id ) === into );
		const yes = await confirmAction(
			sprintf(
				/* translators: 1: ticket number, 2: subject */
				__(
					'Merge this ticket into #%1$d “%2$s”? This one closes, its conversation shows there, and the customer’s replies go there. This can’t be undone.',
					'helpdesk-hero-pro'
				),
				target.id,
				target.subject
			),
			{ confirmText: __( 'Merge', 'helpdesk-hero-pro' ) }
		);
		if ( ! yes ) {
			return;
		}
		setBusy( true );
		send( `merge/${ ticket.id }`, 'POST', { into: target.id } )
			.then( ( r ) => {
				toast( __( 'Tickets merged', 'helpdesk-hero-pro' ) );
				window.location.hash = `#/ticket/${ r.into }`;
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	return (
		<div className="hdh-stack" style={ { gap: 8 } }>
			<select
				className="hdh-input hdh-select"
				aria-label={ __( 'Ticket to merge into', 'helpdesk-hero-pro' ) }
				value={ into }
				onChange={ ( e ) => setInto( e.target.value ) }
			>
				<option value="">
					{ data.tickets.length
						? __( 'Choose a ticket from this site…', 'helpdesk-hero-pro' )
						: __( 'No other tickets from this site', 'helpdesk-hero-pro' ) }
				</option>
				{ data.tickets.map( ( t ) => (
					<option key={ t.id } value={ t.id }>
						#{ t.id } { t.subject }
					</option>
				) ) }
			</select>
			<div className="hdh-row">
				<Button
					size="sm"
					variant="primary"
					disabled={ ! into || busy }
					onClick={ merge }
				>
					{ __( 'Merge', 'helpdesk-hero-pro' ) }
				</Button>
				<Button size="sm" variant="ghost" onClick={ onCancel }>
					{ __( 'Cancel', 'helpdesk-hero-pro' ) }
				</Button>
			</div>
		</div>
	);
}
