/**
 * Time on tickets: the ticket panel (service, timer, automatic tracking, site sessions,
 * entries), the banner for tracked time waiting to be logged, and the Time & billing page.
 */
import { __, _n, sprintf } from '@wordpress/i18n';
import { useState, useEffect, useRef } from '@wordpress/element';
import { addQueryArgs } from '@wordpress/url';
import { useApi, useStored, send } from './ui/lib/hooks';
import {
	Card,
	PageHead,
	Button,
	Drawer,
	ErrorNotice,
	Loading,
	Empty,
	Segmented,
	useToast,
} from './ui/components/ui';
import {
	Check,
	TextField,
	SelectField,
	Pager,
	confirmAction,
	BillingBadge,
} from './ui/components/kit';
import { errorText, useHubData } from './Workflow';
import { money } from './Billing';

/**
 * "1 h 25 min".
 *
 * @param {number} minutes Minutes.
 * @return {string} Duration.
 */
export function duration( minutes ) {
	const m = Math.round( minutes || 0 );
	const h = Math.floor( m / 60 );
	if ( ! h ) {
		/* translators: %d: minutes */
		return sprintf( __( '%d min', 'helpdesk-hero-pro' ), m );
	}
	return m % 60
		? /* translators: 1: hours, 2: minutes */
		  sprintf( __( '%1$d h %2$d min', 'helpdesk-hero-pro' ), h, m % 60 )
		: /* translators: %d: hours */
		  sprintf( __( '%d h', 'helpdesk-hero-pro' ), h );
}

/**
 * Minutes from "90", "1:30", "1h30", "1.5h" or "45m".
 *
 * @param {string} text Text.
 * @return {number} Minutes (0 if unreadable).
 */
function parseMinutes( text ) {
	const t = String( text ).trim().toLowerCase().replace( ',', '.' );
	let m = t.match( /^(\d+):(\d{1,2})$/ );
	if ( m ) {
		return parseInt( m[ 1 ], 10 ) * 60 + parseInt( m[ 2 ], 10 );
	}
	m = t.match( /^(\d+(?:\.\d+)?)\s*h(?:\s*(\d+)\s*m?)?$/ );
	if ( m ) {
		return Math.round(
			parseFloat( m[ 1 ] ) * 60 + ( m[ 2 ] ? parseInt( m[ 2 ], 10 ) : 0 )
		);
	}
	m = t.match( /^(\d+)\s*m?$/ );
	return m ? parseInt( m[ 1 ], 10 ) : 0;
}

function today() {
	const d = new Date();
	return `${ d.getFullYear() }-${ String( d.getMonth() + 1 ).padStart(
		2,
		'0'
	) }-${ String( d.getDate() ).padStart( 2, '0' ) }`;
}

export const STATE_LABELS = {
	unbilled: __( 'Unbilled', 'helpdesk-hero-pro' ),
	invoiced: __( 'Invoiced', 'helpdesk-hero-pro' ),
	paid: __( 'Paid', 'helpdesk-hero-pro' ),
};

/* ------------------------------------------------------------------ Automatic tracking store */

const AUTO_KEY = 'hdh-pro-autotime';

function readAuto() {
	try {
		return JSON.parse( window.localStorage.getItem( AUTO_KEY ) || '{}' ) || {};
	} catch ( e ) {
		return {};
	}
}

function writeAuto( drafts ) {
	try {
		window.localStorage.setItem( AUTO_KEY, JSON.stringify( drafts ) );
	} catch ( e ) {}
}

/**
 * Tracks active working time on a ticket while its page is open: starts when someone works on
 * it (typing, logging in to the site), counts only while the tab is visible and the person is
 * active, and keeps the total in this browser until it's logged or discarded.
 *
 * @param {Object}  ticket  Ticket.
 * @param {boolean} enabled Automatic mode.
 * @param {number}  idle    Idle minutes before pausing.
 * @return {[number, Function]} Seconds tracked and a reset function.
 */
function useAutoTime( ticket, enabled, idle ) {
	const [ seconds, setSeconds ] = useState(
		() => ( readAuto()[ ticket.id ] || {} ).seconds || 0
	);
	const active = useRef( seconds > 0 );
	const lastInput = useRef( Date.now() );

	useEffect( () => {
		if ( ! enabled ) {
			return undefined;
		}
		const onWork = ( e ) => {
			if ( e.detail && e.detail.id === ticket.id ) {
				active.current = true;
				lastInput.current = Date.now();
			}
		};
		const onInput = () => {
			lastInput.current = Date.now();
		};
		const events = [ 'keydown', 'mousedown', 'mousemove', 'scroll', 'touchstart' ];
		window.addEventListener( 'hdh:ticket-work', onWork );
		events.forEach( ( ev ) =>
			window.addEventListener( ev, onInput, { passive: true } )
		);
		const tick = window.setInterval( () => {
			if (
				! active.current ||
				document.visibilityState !== 'visible' ||
				Date.now() - lastInput.current > idle * 60000
			) {
				return;
			}
			const drafts = readAuto();
			const entry = drafts[ ticket.id ] || {
				seconds: 0,
				subject: ticket.subject,
			};
			entry.seconds += 15;
			entry.subject = ticket.subject;
			drafts[ ticket.id ] = entry;
			writeAuto( drafts );
			setSeconds( entry.seconds );
		}, 15000 );
		return () => {
			window.removeEventListener( 'hdh:ticket-work', onWork );
			events.forEach( ( ev ) => window.removeEventListener( ev, onInput ) );
			window.clearInterval( tick );
		};
	}, [ enabled, idle, ticket.id, ticket.subject ] );

	const reset = () => {
		const drafts = readAuto();
		delete drafts[ ticket.id ];
		writeAuto( drafts );
		active.current = false;
		setSeconds( 0 );
	};
	return [ seconds, reset ];
}

/**
 * Above every page: tracked time not yet logged, for tickets you've left.
 *
 * @param {Object} props       Props.
 * @param {string} props.route Current route.
 * @return {JSX.Element|null} Banners.
 */
export function TimeDrafts( { route } ) {
	const [ drafts, setDrafts ] = useState( readAuto );
	const [ busy, setBusy ] = useState( '' );
	const toast = useToast();
	const here = ( route.match( /^ticket\/(\d+)/ ) || [] )[ 1 ];
	const waiting = Object.keys( drafts ).filter(
		( id ) => id !== here && drafts[ id ].seconds >= 60
	);
	if ( ! waiting.length ) {
		return null;
	}
	const drop = ( id ) => {
		const next = readAuto();
		delete next[ id ];
		writeAuto( next );
		setDrafts( next );
	};
	const log = ( id ) => {
		setBusy( id );
		send( `time/ticket/${ id }`, 'POST', {
			minutes: Math.round( drafts[ id ].seconds / 60 ),
			source: 'auto',
			worked_on: today(),
		} )
			.then( () => {
				toast( __( 'Time logged', 'helpdesk-hero-pro' ) );
				drop( id );
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( '' ) );
	};
	return (
		<div className="hdh-stack" style={ { gap: 8, marginBottom: 16 } }>
			{ waiting.map( ( id ) => (
				<div key={ id } className="hdh-banner" role="status">
					<div className="hdh-banner__text">
						{ sprintf(
							/* translators: 1: time, 2: ticket number, 3: subject */
							__(
								'You worked %1$s on #%2$s “%3$s”. Log it?',
								'helpdesk-hero-pro'
							),
							duration( drafts[ id ].seconds / 60 ),
							id,
							drafts[ id ].subject || ''
						) }
					</div>
					<Button
						size="sm"
						variant="primary"
						disabled={ busy === id }
						onClick={ () => log( id ) }
					>
						{ __( 'Log time', 'helpdesk-hero-pro' ) }
					</Button>
					<a className="hdh-btn is-sm" href={ `#/ticket/${ id }` }>
						{ __( 'Adjust', 'helpdesk-hero-pro' ) }
					</a>
					<Button size="sm" variant="ghost" onClick={ () => drop( id ) }>
						{ __( 'Discard', 'helpdesk-hero-pro' ) }
					</Button>
				</div>
			) ) }
		</div>
	);
}

/* ------------------------------------------------------------------ Ticket panel */

export function TimePanel( { ticket } ) {
	const { data, reload } = useApi( `time/ticket/${ ticket.id }` );
	const settings = data ? data.settings : { time_mode: 'manual', idle_minutes: 5 };
	const [ autoSeconds, resetAuto ] = useAutoTime(
		ticket,
		settings.time_mode === 'auto',
		settings.idle_minutes
	);
	// The start/stop timer survives page loads in this browser.
	const [ timers, setTimers ] = useStored( 'pro-timers', {} );
	const started = timers[ ticket.id ] || 0;
	const [ now, setNow ] = useState( Date.now() );
	const [ amount, setAmount ] = useState( '' );
	const [ note, setNote ] = useState( '' );
	const [ billable, setBillable ] = useState( null );
	const [ busy, setBusy ] = useState( false );
	const [ editing, setEditing ] = useState( null );
	const toast = useToast();
	const services = ( window.hdhBoot || {} ).services || [];

	useEffect( () => {
		if ( ! started ) {
			return undefined;
		}
		const t = window.setInterval( () => setNow( Date.now() ), 15000 );
		return () => window.clearInterval( t );
	}, [ started ] );

	if ( ! data ) {
		return (
			<Card title={ __( 'Time', 'helpdesk-hero-pro' ) }>
				<Loading />
			</Card>
		);
	}
	const running = started ? Math.max( 1, ( now - started ) / 60000 ) : 0;
	const add = ( minutes, source, extra = {} ) => {
		setBusy( true );
		return send( `time/ticket/${ ticket.id }`, 'POST', {
			minutes,
			note,
			worked_on: today(),
			source,
			...( billable === null ? {} : { billable } ),
			...extra,
		} )
			.then( () => {
				setAmount( '' );
				setNote( '' );
				toast( __( 'Time added', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	const setService = ( service ) =>
		send( `ticket/${ ticket.id }/service`, 'POST', { service } )
			.then( () => {
				toast( __( 'Service set', 'helpdesk-hero-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) );
	const remove = async ( entry ) => {
		if (
			! ( await confirmAction(
				__( 'Delete this entry?', 'helpdesk-hero-pro' ),
				{ confirmText: __( 'Delete', 'helpdesk-hero-pro' ) }
			) )
		) {
			return;
		}
		send( `time/${ entry.id }`, 'DELETE' )
			.then( reload )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) );
	};
	const currency = settings.currency;

	return (
		<Card
			title={ __( 'Time', 'helpdesk-hero-pro' ) }
			sub={ sprintf(
				/* translators: 1: total time, 2: amount */
				__( '%1$s · %2$s', 'helpdesk-hero-pro' ),
				duration( data.total ),
				money( data.amount, currency )
			) }
		>
			<div className="hdh-stack" style={ { gap: 10 } }>
				<SelectField
					label={ __( 'Service', 'helpdesk-hero-pro' ) }
					value={ data.service }
					onChange={ setService }
					options={ [
						{ value: '', label: __( 'Not set', 'helpdesk-hero-pro' ) },
						...services.map( ( s ) => ( { value: s.id, label: s.name } ) ),
					] }
					help={
						data.rate
							? sprintf(
									/* translators: %s: hourly rate */
									__( 'Rate here: %s / hour', 'helpdesk-hero-pro' ),
									money( data.rate, currency )
							  )
							: undefined
					}
				/>

				{ settings.time_mode === 'auto' && autoSeconds >= 60 && (
					<div className="hdh-policy-note">
						<span>
							{ sprintf(
								/* translators: %s: time */
								__( 'Tracked so far: %s', 'helpdesk-hero-pro' ),
								duration( autoSeconds / 60 )
							) }
						</span>
						<Button
							size="sm"
							variant="primary"
							disabled={ busy }
							onClick={ () =>
								add( Math.round( autoSeconds / 60 ), 'auto' ).then(
									resetAuto
								)
							}
						>
							{ __( 'Log', 'helpdesk-hero-pro' ) }
						</Button>
						<Button size="sm" variant="ghost" onClick={ resetAuto }>
							{ __( 'Discard', 'helpdesk-hero-pro' ) }
						</Button>
					</div>
				) }
				{ settings.time_mode === 'auto' && autoSeconds < 60 && (
					<p className="hdh-muted" style={ { margin: 0 } }>
						{ __(
							'Time is tracked automatically while you work on this ticket.',
							'helpdesk-hero-pro'
						) }
					</p>
				) }
				{ settings.time_mode === 'sessions' && (
					<SessionSuggestions
						ticket={ ticket }
						onLog={ ( s ) =>
							add( s.minutes, 'session', {
								source_ref: s.key,
								worked_on: s.start.slice( 0, 10 ),
								note: s.by
									? sprintf(
											/* translators: %s: person */
											__( 'Site session (%s)', 'helpdesk-hero-pro' ),
											s.by
									  )
									: __( 'Site session', 'helpdesk-hero-pro' ),
							} )
						}
					/>
				) }

				<div className="hdh-row">
					{ started ? (
						<Button
							size="sm"
							icon="pause"
							onClick={ () => {
								const next = { ...timers };
								delete next[ ticket.id ];
								setTimers( next );
								setAmount(
									String(
										Math.max( 1, Math.round( ( Date.now() - started ) / 60000 ) )
									)
								);
							} }
						>
							{ sprintf(
								/* translators: %s: time so far */
								__( 'Stop timer (%s)', 'helpdesk-hero-pro' ),
								duration( running )
							) }
						</Button>
					) : (
						<Button
							size="sm"
							icon="timer"
							onClick={ () => {
								setNow( Date.now() );
								setTimers( { ...timers, [ ticket.id ]: Date.now() } );
							} }
						>
							{ __( 'Start timer', 'helpdesk-hero-pro' ) }
						</Button>
					) }
				</div>
				<div className="hdh-row">
					<input
						className="hdh-input"
						style={ { width: 90 } }
						aria-label={ __( 'Time spent', 'helpdesk-hero-pro' ) }
						placeholder={ __( '1:30', 'helpdesk-hero-pro' ) }
						value={ amount }
						onChange={ ( e ) => setAmount( e.target.value ) }
					/>
					<input
						className="hdh-input"
						style={ { flex: 1, minWidth: 120 } }
						aria-label={ __( 'What you did', 'helpdesk-hero-pro' ) }
						placeholder={ __( 'What you did (optional)', 'helpdesk-hero-pro' ) }
						value={ note }
						maxLength={ 255 }
						onChange={ ( e ) => setNote( e.target.value ) }
					/>
				</div>
				<div className="hdh-row">
					<Check
						label={ __( 'Billable', 'helpdesk-hero-pro' ) }
						checked={ billable === null ? true : billable }
						onChange={ setBillable }
					/>
					<Button
						size="sm"
						variant="primary"
						disabled={ busy || ! amount.trim() }
						onClick={ () => {
							const minutes = parseMinutes( amount );
							if ( ! minutes ) {
								toast(
									__(
										'Enter the time, for example 45, 1:30 or 1.5h.',
										'helpdesk-hero-pro'
									),
									'alert'
								);
								return;
							}
							add( minutes, started ? 'timer' : 'manual' );
						} }
					>
						{ __( 'Add time', 'helpdesk-hero-pro' ) }
					</Button>
				</div>
				{ data.entries.length > 0 && (
					<ul className="hdh-time-list">
						{ data.entries.map( ( e ) => (
							<li key={ e.id }>
								<strong>
									{ e.kind === 'charge'
										? money( e.amount, currency )
										: duration( e.minutes ) }
								</strong>
								{ e.kind === 'time' && e.amount > 0 && (
									<span> · { money( e.amount, currency ) }</span>
								) }
								<span className="hdh-muted">
									{ ' · ' }
									{ e.billable ? (
										<BillingBadge state={ e.state } />
									) : (
										__( 'not billable', 'helpdesk-hero-pro' )
									) }
									{ ' · ' }
									{ e.user } ·{ ' ' }
									{ new Date( `${ e.worked_on }T12:00:00` ).toLocaleDateString() }
								</span>
								{ e.note && <div>{ e.note }</div> }
								{ ( e.mine || ( window.hdhBoot || {} ).canManage ) && (
									<span className="hdh-row" style={ { gap: 10 } }>
										<button
											type="button"
											className="hdh-link-button"
											onClick={ () => setEditing( e ) }
										>
											{ __( 'Edit', 'helpdesk-hero-pro' ) }
										</button>
										{ e.state === 'unbilled' && (
											<button
												type="button"
												className="hdh-link-button"
												onClick={ () => remove( e ) }
											>
												{ __( 'Delete', 'helpdesk-hero-pro' ) }
											</button>
										) }
									</span>
								) }
							</li>
						) ) }
					</ul>
				) }
			</div>
			{ editing && (
				<EntryDrawer
					entry={ editing }
					onClose={ () => setEditing( null ) }
					onSaved={ () => {
						setEditing( null );
						reload();
					} }
				/>
			) }
		</Card>
	);
}

function SessionSuggestions( { ticket, onLog } ) {
	const { data, error, reload } = useApi( `time/ticket/${ ticket.id }/sessions` );
	const [ hidden, setHidden ] = useStored( 'pro-dismissed-sessions', [] );
	if ( error ) {
		return (
			<p className="hdh-muted" style={ { margin: 0 } }>
				{ __(
					'Site sessions can’t be read right now (the site may be offline).',
					'helpdesk-hero-pro'
				) }
			</p>
		);
	}
	if ( ! data ) {
		return null;
	}
	const list = data.sessions.filter( ( s ) => ! hidden.includes( s.key ) );
	if ( ! list.length ) {
		return (
			<p className="hdh-muted" style={ { margin: 0 } }>
				{ __(
					'Support logins on the site appear here, ready to log.',
					'helpdesk-hero-pro'
				) }
			</p>
		);
	}
	return (
		<div className="hdh-stack" style={ { gap: 6 } }>
			{ list.map( ( s ) => (
				<div key={ s.key } className="hdh-policy-note">
					<span>
						{ sprintf(
							/* translators: 1: time, 2: person, 3: date */
							__( 'Site session: %1$s %2$s (%3$s)', 'helpdesk-hero-pro' ),
							duration( s.minutes ),
							s.by,
							new Date( s.start ).toLocaleString()
						) }
					</span>
					<Button
						size="sm"
						variant="primary"
						onClick={ () => onLog( s ).then( reload ) }
					>
						{ __( 'Log', 'helpdesk-hero-pro' ) }
					</Button>
					<Button
						size="sm"
						variant="ghost"
						onClick={ () => setHidden( [ ...hidden, s.key ] ) }
					>
						{ __( 'Dismiss', 'helpdesk-hero-pro' ) }
					</Button>
				</div>
			) ) }
		</div>
	);
}

/* ------------------------------------------------------------------ Edit an entry */

function EntryDrawer( { entry, onClose, onSaved } ) {
	const [ d, setD ] = useState( {
		minutes: String( entry.minutes ),
		amount: String( entry.amount ),
		service: entry.service,
		billable: entry.billable,
		note: entry.note,
		worked_on: entry.worked_on,
		state: entry.state,
		invoice_ref: entry.invoice_ref,
		billing_note: entry.billing_note,
	} );
	const [ busy, setBusy ] = useState( false );
	const toast = useToast();
	const services = ( window.hdhBoot || {} ).services || [];
	const canManage = ( window.hdhBoot || {} ).canManage;
	const save = () => {
		const body = { ...d };
		if ( entry.kind === 'time' ) {
			body.minutes = parseMinutes( d.minutes );
			delete body.amount;
		} else {
			body.amount = parseFloat( d.amount ) || 0;
			delete body.minutes;
		}
		if ( ! canManage ) {
			delete body.state;
			delete body.invoice_ref;
			delete body.billing_note;
		}
		setBusy( true );
		send( `time/${ entry.id }`, 'POST', body )
			.then( () => {
				toast( __( 'Entry saved', 'helpdesk-hero-pro' ) );
				onSaved();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) )
			.finally( () => setBusy( false ) );
	};
	const set = ( k ) => ( v ) => setD( { ...d, [ k ]: v } );
	return (
		<Drawer
			title={
				<h2 className="hdh-card__title">
					{ __( 'Edit entry', 'helpdesk-hero-pro' ) }
				</h2>
			}
			onClose={ onClose }
			footer={
				<Button variant="primary" disabled={ busy } onClick={ save }>
					{ __( 'Save', 'helpdesk-hero-pro' ) }
				</Button>
			}
		>
			<div className="hdh-stack">
				{ entry.kind === 'time' ? (
					<TextField
						label={ __( 'Time', 'helpdesk-hero-pro' ) }
						value={ d.minutes }
						onChange={ set( 'minutes' ) }
						help={ __( 'Minutes, or 1:30, or 1.5h.', 'helpdesk-hero-pro' ) }
					/>
				) : (
					<TextField
						label={ __( 'Amount', 'helpdesk-hero-pro' ) }
						type="number"
						step="0.01"
						value={ d.amount }
						onChange={ set( 'amount' ) }
					/>
				) }
				<SelectField
					label={ __( 'Service', 'helpdesk-hero-pro' ) }
					value={ d.service }
					onChange={ set( 'service' ) }
					options={ [
						{ value: '', label: __( 'Not set', 'helpdesk-hero-pro' ) },
						...services.map( ( s ) => ( { value: s.id, label: s.name } ) ),
					] }
				/>
				<Check
					label={ __( 'Billable', 'helpdesk-hero-pro' ) }
					checked={ d.billable }
					onChange={ set( 'billable' ) }
				/>
				<TextField
					label={ __( 'Date', 'helpdesk-hero-pro' ) }
					type="date"
					value={ d.worked_on }
					onChange={ set( 'worked_on' ) }
				/>
				<TextField
					label={ __( 'What was done', 'helpdesk-hero-pro' ) }
					value={ d.note }
					maxLength={ 255 }
					onChange={ set( 'note' ) }
				/>
				{ canManage && (
					<>
						<SelectField
							label={ __( 'Billing', 'helpdesk-hero-pro' ) }
							value={ d.state }
							onChange={ set( 'state' ) }
							options={ Object.keys( STATE_LABELS ).map( ( k ) => ( {
								value: k,
								label: STATE_LABELS[ k ],
							} ) ) }
						/>
						<TextField
							label={ __( 'Invoice reference', 'helpdesk-hero-pro' ) }
							value={ d.invoice_ref }
							maxLength={ 64 }
							placeholder="#4444"
							onChange={ set( 'invoice_ref' ) }
						/>
						<TextField
							label={ __( 'Billing note', 'helpdesk-hero-pro' ) }
							value={ d.billing_note }
							maxLength={ 255 }
							placeholder={ __(
								'For example: paid by bank transfer on 3 Oct',
								'helpdesk-hero-pro'
							) }
							onChange={ set( 'billing_note' ) }
						/>
					</>
				) }
			</div>
		</Drawer>
	);
}

/* ------------------------------------------------------------------ Time & billing page */

function monthRange( offset ) {
	const d = new Date();
	d.setDate( 1 );
	d.setMonth( d.getMonth() + offset );
	const y = d.getFullYear();
	const m = String( d.getMonth() + 1 ).padStart( 2, '0' );
	const last = new Date( y, d.getMonth() + 1, 0 ).getDate();
	return { from: `${ y }-${ m }-01`, to: `${ y }-${ m }-${ last }` };
}

function csv( rows ) {
	return rows
		.map( ( r ) =>
			r
				.map( ( v ) => {
					const s = String( v ?? '' );
					// Quote, and stop spreadsheet formulas in text fields.
					const safe = /^[=+\-@]/.test( s ) ? `'${ s }` : s;
					return `"${ safe.replace( /"/g, '""' ) }"`;
				} )
				.join( ',' )
		)
		.join( '\n' );
}

function download( name, text, type ) {
	const blob = new window.Blob( [ text ], { type } );
	const url = window.URL.createObjectURL( blob );
	const a = document.createElement( 'a' );
	a.href = url;
	a.download = name;
	document.body.appendChild( a );
	a.click();
	a.remove();
	window.URL.revokeObjectURL( url );
}

function PeriodSelect( { range, setRange } ) {
	return (
		<select
			className="hdh-input hdh-select"
			aria-label={ __( 'Period', 'helpdesk-hero-pro' ) }
			value={ JSON.stringify( range ) }
			onChange={ ( e ) => setRange( JSON.parse( e.target.value ) ) }
		>
			{ [ 0, -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11 ].map( ( o ) => {
				const r = monthRange( o );
				return (
					<option key={ o } value={ JSON.stringify( r ) }>
						{ new Date( `${ r.from }T12:00:00` ).toLocaleDateString( undefined, {
							month: 'long',
							year: 'numeric',
						} ) }
					</option>
				);
			} ) }
		</select>
	);
}

function Summary( { range, site } ) {
	const { data, error, reload } = useApi(
		addQueryArgs( 'time/report', { ...range, site: site || undefined } )
	);
	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ reload } />;
	}
	if ( ! data ) {
		return <Loading />;
	}
	if ( ! data.sites.length ) {
		return (
			<Empty
				compact
				title={ __( 'Nothing logged in this period.', 'helpdesk-hero-pro' ) }
			/>
		);
	}
	const c = data.currency;
	return (
		<div className="hdh-table-wrap">
			<table className="hdh-table">
				<thead>
					<tr>
						<th scope="col">{ __( 'Site', 'helpdesk-hero-pro' ) }</th>
						<th scope="col">{ __( 'Time', 'helpdesk-hero-pro' ) }</th>
						<th scope="col">{ __( 'Retainer', 'helpdesk-hero-pro' ) }</th>
						<th scope="col">{ __( 'Charged', 'helpdesk-hero-pro' ) }</th>
						<th scope="col">{ __( 'Unbilled', 'helpdesk-hero-pro' ) }</th>
						<th scope="col">{ __( 'Invoiced', 'helpdesk-hero-pro' ) }</th>
						<th scope="col">{ __( 'Paid', 'helpdesk-hero-pro' ) }</th>
					</tr>
				</thead>
				<tbody>
					{ data.sites.map( ( s ) => (
						<tr key={ s.site_id }>
							<td>{ s.name }</td>
							<td>{ duration( s.minutes ) }</td>
							<td>
								{ s.retainer_hours
									? sprintf(
											/* translators: 1: hours used, 2: hours included */
											__( '%1$s of %2$s h', 'helpdesk-hero-pro' ),
											( s.retainer_used / 60 ).toFixed( 1 ),
											s.retainer_hours
									  )
									: '—' }
							</td>
							<td>{ money( s.charged, c ) }</td>
							<td>
								<strong>{ money( s.due, c ) }</strong>
							</td>
							<td>{ money( s.invoiced, c ) }</td>
							<td>{ money( s.paid, c ) }</td>
						</tr>
					) ) }
				</tbody>
			</table>
		</div>
	);
}

function Entries( { range, site } ) {
	const [ filters, setFilters ] = useState( {
		state: '',
		service: '',
		kind: '',
		search: '',
	} );
	const [ page, setPage ] = useState( 1 );
	const [ perPage, setPerPage ] = useStored( 'time-per-page', 50 );
	const [ selected, setSelected ] = useState( [] );
	const [ editing, setEditing ] = useState( null );
	const [ bulk, setBulk ] = useState( { state: 'invoiced', ref: '', note: '' } );
	const toast = useToast();
	const services = ( window.hdhBoot || {} ).services || [];
	const { data, error, reload } = useApi(
		addQueryArgs( 'time/entries', {
			...range,
			site: site || undefined,
			...Object.fromEntries(
				Object.entries( filters ).filter( ( [ , v ] ) => v !== '' )
			),
			page,
			per_page: perPage,
		} )
	);
	useEffect( () => {
		setPage( 1 );
		setSelected( [] );
	}, [ range, site, filters, perPage ] );
	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ reload } />;
	}
	if ( ! data ) {
		return <Loading />;
	}
	const set = ( k ) => ( e ) => setFilters( { ...filters, [ k ]: e.target.value } );
	const ids = data.entries.map( ( e ) => e.id );
	const applyBulk = () => {
		send( 'time/bulk', 'POST', { ids: selected, ...bulk } )
			.then( ( r ) => {
				toast(
					sprintf(
						/* translators: %d: number of entries */
						_n( '%d entry updated', '%d entries updated', r.updated, 'helpdesk-hero-pro' ),
						r.updated
					)
				);
				setSelected( [] );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) );
	};
	const exportCsv = () => {
		const rows = [
			[
				__( 'Date', 'helpdesk-hero-pro' ),
				__( 'Site', 'helpdesk-hero-pro' ),
				__( 'Ticket', 'helpdesk-hero-pro' ),
				__( 'Subject', 'helpdesk-hero-pro' ),
				__( 'Service', 'helpdesk-hero-pro' ),
				__( 'Person', 'helpdesk-hero-pro' ),
				__( 'Minutes', 'helpdesk-hero-pro' ),
				__( 'Hours', 'helpdesk-hero-pro' ),
				__( 'Rate', 'helpdesk-hero-pro' ),
				__( 'Amount', 'helpdesk-hero-pro' ),
				__( 'Billable', 'helpdesk-hero-pro' ),
				__( 'State', 'helpdesk-hero-pro' ),
				__( 'Invoice', 'helpdesk-hero-pro' ),
				__( 'Note', 'helpdesk-hero-pro' ),
				__( 'Billing note', 'helpdesk-hero-pro' ),
			],
			...data.entries.map( ( e ) => [
				e.worked_on,
				e.site,
				e.ticket_id,
				e.subject,
				e.service_name,
				e.user,
				e.minutes,
				( e.minutes / 60 ).toFixed( 2 ),
				e.rate,
				e.amount,
				e.billable ? 'yes' : 'no',
				e.state,
				e.invoice_ref,
				e.note,
				e.billing_note,
			] ),
		];
		download( `helpdesk-hero-time-${ range.from }-${ range.to }.csv`, csv( rows ), 'text/csv' );
	};
	const canManage = ( window.hdhBoot || {} ).canManage;
	return (
		<>
			<div className="hdh-toolbar" style={ { padding: '12px 18px' } }>
				<input
					type="search"
					className="hdh-input"
					placeholder={ __( 'Search notes, invoice or subject', 'helpdesk-hero-pro' ) }
					aria-label={ __( 'Search entries', 'helpdesk-hero-pro' ) }
					value={ filters.search }
					onChange={ set( 'search' ) }
				/>
				<select
					className="hdh-input hdh-select"
					aria-label={ __( 'Billing', 'helpdesk-hero-pro' ) }
					value={ filters.state }
					onChange={ set( 'state' ) }
				>
					<option value="">{ __( 'Any billing state', 'helpdesk-hero-pro' ) }</option>
					{ Object.keys( STATE_LABELS ).map( ( k ) => (
						<option key={ k } value={ k }>
							{ STATE_LABELS[ k ] }
						</option>
					) ) }
					<option value="nonbillable">
						{ __( 'Not billable', 'helpdesk-hero-pro' ) }
					</option>
				</select>
				<select
					className="hdh-input hdh-select"
					aria-label={ __( 'Service', 'helpdesk-hero-pro' ) }
					value={ filters.service }
					onChange={ set( 'service' ) }
				>
					<option value="">{ __( 'All services', 'helpdesk-hero-pro' ) }</option>
					{ services.map( ( s ) => (
						<option key={ s.id } value={ s.id }>
							{ s.name }
						</option>
					) ) }
					<option value="none">{ __( 'No service', 'helpdesk-hero-pro' ) }</option>
				</select>
				<select
					className="hdh-input hdh-select"
					aria-label={ __( 'Type', 'helpdesk-hero-pro' ) }
					value={ filters.kind }
					onChange={ set( 'kind' ) }
				>
					<option value="">{ __( 'Time and charges', 'helpdesk-hero-pro' ) }</option>
					<option value="time">{ __( 'Time only', 'helpdesk-hero-pro' ) }</option>
					<option value="charge">{ __( 'Fixed charges only', 'helpdesk-hero-pro' ) }</option>
				</select>
				<Button size="sm" icon="download" disabled={ ! data.entries.length } onClick={ exportCsv }>
					{ __( 'CSV', 'helpdesk-hero-pro' ) }
				</Button>
			</div>
			<p className="hdh-muted" style={ { padding: '0 18px', margin: 0 } }>
				{ sprintf(
					/* translators: 1: entries, 2: time, 3: amount */
					__( '%1$d entries · %2$s · %3$s', 'helpdesk-hero-pro' ),
					data.total,
					duration( data.sums.minutes ),
					money( data.sums.amount, data.currency )
				) }
			</p>
			{ selected.length > 0 && canManage && (
				<div className="hdh-banner" style={ { margin: '12px 18px 0' } }>
					<strong>
						{ sprintf(
							/* translators: %d: number of entries */
							_n( '%d selected', '%d selected', selected.length, 'helpdesk-hero-pro' ),
							selected.length
						) }
					</strong>
					<select
						className="hdh-input hdh-select"
						aria-label={ __( 'Mark as', 'helpdesk-hero-pro' ) }
						value={ bulk.state }
						onChange={ ( e ) => setBulk( { ...bulk, state: e.target.value } ) }
					>
						{ Object.keys( STATE_LABELS ).map( ( k ) => (
							<option key={ k } value={ k }>
								{ sprintf(
									/* translators: %s: billing state */
									__( 'Mark as %s', 'helpdesk-hero-pro' ),
									STATE_LABELS[ k ].toLowerCase()
								) }
							</option>
						) ) }
					</select>
					<input
						className="hdh-input"
						style={ { width: 120 } }
						aria-label={ __( 'Invoice reference', 'helpdesk-hero-pro' ) }
						placeholder="#4444"
						value={ bulk.ref }
						onChange={ ( e ) => setBulk( { ...bulk, ref: e.target.value } ) }
					/>
					<input
						className="hdh-input"
						style={ { flex: 1, minWidth: 140 } }
						aria-label={ __( 'Note', 'helpdesk-hero-pro' ) }
						placeholder={ __( 'Note (optional)', 'helpdesk-hero-pro' ) }
						value={ bulk.note }
						onChange={ ( e ) => setBulk( { ...bulk, note: e.target.value } ) }
					/>
					<Button size="sm" variant="primary" onClick={ applyBulk }>
						{ __( 'Apply', 'helpdesk-hero-pro' ) }
					</Button>
				</div>
			) }
			{ ! data.entries.length ? (
				<Empty compact title={ __( 'No entries match.', 'helpdesk-hero-pro' ) } />
			) : (
				<div className="hdh-table-wrap">
					<table className="hdh-table">
						<thead>
							<tr>
								{ canManage && (
									<th scope="col" style={ { width: 1 } }>
										<input
											type="checkbox"
											className="hdh-select-row"
											aria-label={ __( 'Select all on this page', 'helpdesk-hero-pro' ) }
											checked={ ids.every( ( id ) => selected.includes( id ) ) }
											onChange={ ( e ) =>
												setSelected(
													e.target.checked
														? [ ...new Set( [ ...selected, ...ids ] ) ]
														: selected.filter( ( id ) => ! ids.includes( id ) )
												)
											}
										/>
									</th>
								) }
								<th scope="col">{ __( 'Date', 'helpdesk-hero-pro' ) }</th>
								<th scope="col">{ __( 'Ticket', 'helpdesk-hero-pro' ) }</th>
								<th scope="col">{ __( 'Service', 'helpdesk-hero-pro' ) }</th>
								<th scope="col">{ __( 'Time', 'helpdesk-hero-pro' ) }</th>
								<th scope="col">{ __( 'Amount', 'helpdesk-hero-pro' ) }</th>
								<th scope="col">{ __( 'Billing', 'helpdesk-hero-pro' ) }</th>
							</tr>
						</thead>
						<tbody>
							{ data.entries.map( ( e ) => (
								<tr key={ e.id } className="hdh-row-link" onClick={ () => setEditing( e ) }>
									{ canManage && (
										<td onClick={ ( ev ) => ev.stopPropagation() }>
											<input
												type="checkbox"
												className="hdh-select-row"
												aria-label={ __( 'Select entry', 'helpdesk-hero-pro' ) }
												checked={ selected.includes( e.id ) }
												onChange={ ( ev ) =>
													setSelected(
														ev.target.checked
															? [ ...selected, e.id ]
															: selected.filter( ( x ) => x !== e.id )
													)
												}
											/>
										</td>
									) }
									<td className="hdh-nowrap">
										{ new Date( `${ e.worked_on }T12:00:00` ).toLocaleDateString() }
										<div className="hdh-muted">{ e.user }</div>
									</td>
									<td>
										<a
											href={ `#/ticket/${ e.ticket_id }` }
											onClick={ ( ev ) => ev.stopPropagation() }
										>
											#{ e.ticket_id } { e.subject }
										</a>
										<div className="hdh-muted">
											{ e.site }
											{ e.note ? ` · ${ e.note }` : '' }
										</div>
									</td>
									<td>{ e.service_name || '—' }</td>
									<td className="hdh-nowrap">
										{ e.kind === 'charge' ? '—' : duration( e.minutes ) }
									</td>
									<td className="hdh-nowrap">
										{ e.amount ? money( e.amount, data.currency ) : '—' }
									</td>
									<td>
										{ e.billable ? (
											<BillingBadge state={ e.state } />
										) : (
											__( 'Not billable', 'helpdesk-hero-pro' )
										) }
										{ e.invoice_ref && (
											<div className="hdh-muted">{ e.invoice_ref }</div>
										) }
									</td>
								</tr>
							) ) }
						</tbody>
					</table>
					<Pager
						page={ data.page }
						perPage={ perPage }
						total={ data.total }
						onPage={ setPage }
						onPer={ setPerPage }
					/>
				</div>
			) }
			{ editing && (
				<EntryDrawer
					entry={ editing }
					onClose={ () => setEditing( null ) }
					onSaved={ () => {
						setEditing( null );
						reload();
					} }
				/>
			) }
		</>
	);
}

export default function TimeBilling() {
	const [ tab, setTab ] = useStored( 'time-tab', 'summary' );
	const [ range, setRange ] = useState( monthRange( 0 ) );
	const [ site, setSite ] = useState( '' );
	const sites = useHubData( 'admin/sites' );
	return (
		<>
			<PageHead
				title={ __( 'Time & billing', 'helpdesk-hero-pro' ) }
				lede={ __(
					'What your team did for each customer, what it costs, and what’s been invoiced and paid.',
					'helpdesk-hero-pro'
				) }
			/>
			<Card
				bodyClass={ null }
				title={
					<Segmented
						label={ __( 'View', 'helpdesk-hero-pro' ) }
						value={ tab }
						onChange={ setTab }
						options={ [
							{ value: 'summary', label: __( 'Per site', 'helpdesk-hero-pro' ) },
							{ value: 'entries', label: __( 'All entries', 'helpdesk-hero-pro' ) },
						] }
					/>
				}
				action={
					<div className="hdh-toolbar">
						<PeriodSelect range={ range } setRange={ setRange } />
						<select
							className="hdh-input hdh-select"
							aria-label={ __( 'Site', 'helpdesk-hero-pro' ) }
							value={ site }
							onChange={ ( e ) => setSite( e.target.value ) }
						>
							<option value="">{ __( 'All sites', 'helpdesk-hero-pro' ) }</option>
							{ ( sites ? sites.sites : [] ).map( ( s ) => (
								<option key={ s.id } value={ s.id }>
									{ s.name }
								</option>
							) ) }
						</select>
					</div>
				}
			>
				{ tab === 'summary' ? (
					<Summary range={ range } site={ site } />
				) : (
					<Entries range={ range } site={ site } />
				) }
			</Card>
		</>
	);
}
