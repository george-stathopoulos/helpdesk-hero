/**
 * Analytics explorer: the Inbox filters, a date range and a "group by", with KPIs, clickable
 * charts that narrow the filters, a group table, saved reports, the matching tickets, and
 * print / save as PDF.
 */
import { __, _n, sprintf } from '@wordpress/i18n';
import { useState, useEffect, useMemo } from '@wordpress/element';
import { addQueryArgs } from '@wordpress/url';
import apiFetch from '@wordpress/api-fetch';
import { useApi, send } from './ui/lib/hooks';
import { ago, when } from './ui/lib/time';
import {
	Card,
	PageHead,
	Button,
	ErrorNotice,
	Loading,
	Empty,
	useToast,
} from './ui/components/ui';
import { confirmAction, Pager } from './ui/components/kit';
import { StackedColumns, BarList } from './ui/components/charts';
import Icon from './ui/components/Icon';
import { useHubData, errorText } from './Workflow';

const hub = window.hdhBoot || {};

const PRESETS = [
	[ 7, __( '7 days', 'helpdesk-hero-pro' ) ],
	[ 30, __( '30 days', 'helpdesk-hero-pro' ) ],
	[ 90, __( '90 days', 'helpdesk-hero-pro' ) ],
	[ 365, __( '12 months', 'helpdesk-hero-pro' ) ],
];

// Which Inbox filter a breakdown or group narrows.
const FILTER_FOR = {
	site: 'site',
	category: 'category',
	service: 'service',
	assignee: 'assignee',
	tier: 'tier',
	priority: 'priority',
	tag: 'tag',
	status: 'status',
};

const STATUS_TEXT = {
	open: __( 'Open', 'helpdesk-hero-pro' ),
	pending: __( 'Waiting on customer', 'helpdesk-hero-pro' ),
	closed: __( 'Closed', 'helpdesk-hero-pro' ),
};

/**
 * A date some days ago, as YYYY-MM-DD.
 *
 * @param {number} days Days back.
 * @return {string} Date.
 */
function daysAgo( days ) {
	return new Date( Date.now() - days * 86400000 ).toISOString().slice( 0, 10 );
}

/**
 * Hours as text.
 *
 * @param {number|null} h Hours.
 * @return {string} Text.
 */
function hours( h ) {
	if ( h === null || h === undefined ) {
		return '—';
	}
	if ( h < 1 ) {
		/* translators: %d: minutes */
		return sprintf( __( '%d min', 'helpdesk-hero-pro' ), Math.round( h * 60 ) );
	}
	if ( h >= 48 ) {
		/* translators: %s: days */
		return sprintf( __( '%s days', 'helpdesk-hero-pro' ), ( h / 24 ).toFixed( 1 ) );
	}
	/* translators: %s: hours */
	return sprintf( __( '%s h', 'helpdesk-hero-pro' ), h );
}

function money( amount, currency ) {
	try {
		return new Intl.NumberFormat( undefined, {
			style: 'currency',
			currency: currency || 'EUR',
		} ).format( amount || 0 );
	} catch ( e ) {
		return `${ ( amount || 0 ).toFixed( 2 ) } ${ currency }`;
	}
}

function Kpi( { label, value, foot } ) {
	return (
		<Card bodyClass={ null }>
			<div className="hdh-stat">
				<div className="hdh-stat__label">{ label }</div>
				<div className="hdh-stat__value">{ value }</div>
				{ foot && <div className="hdh-stat__foot hdh-muted">{ foot }</div> }
			</div>
		</Card>
	);
}

/**
 * Saved reports: chips to load, save the current one, delete.
 *
 * @param {Object}   props         Props.
 * @param {Object}   props.current { filters, group }.
 * @param {Function} props.onLoad  ( report ) => void.
 * @return {JSX.Element|null} Bar.
 */
function SavedReports( { current, onLoad } ) {
	const { data, reload } = useApi( 'analytics/reports' );
	const [ naming, setNaming ] = useState( false );
	const [ name, setName ] = useState( '' );
	const [ scope, setScope ] = useState( 'personal' );
	const toast = useToast();
	if ( ! data ) {
		return null;
	}
	const all = [
		...data.personal.map( ( v ) => ( { ...v, scope: 'personal' } ) ),
		...data.shared.map( ( v ) => ( { ...v, scope: 'shared' } ) ),
	];
	const same = ( v ) =>
		v.group === current.group &&
		JSON.stringify( Object.entries( v.filters ).sort() ) ===
			JSON.stringify(
				Object.entries( current.filters )
					.filter( ( [ , x ] ) => x !== '' && x !== undefined )
					.map( ( [ k, x ] ) => [ k, String( x ) ] )
					.sort()
			);
	const active = all.find( same );
	const save = () =>
		send( 'analytics/reports', 'POST', {
			scope,
			view: { name, filters: current.filters, group: current.group },
		} )
			.then( () => {
				toast( __( 'Report saved', 'helpdesk-hero-pro' ) );
				setNaming( false );
				setName( '' );
				reload();
			} )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) );
	const remove = async () => {
		if (
			! ( await confirmAction(
				/* translators: %s: report name */
				sprintf( __( 'Delete the saved report “%s”?', 'helpdesk-hero-pro' ), active.name ),
				{ confirmText: __( 'Delete', 'helpdesk-hero-pro' ) }
			) )
		) {
			return;
		}
		send( `analytics/reports/${ active.scope }/${ active.id }`, 'DELETE' )
			.then( reload )
			.catch( ( e ) => toast( errorText( e ), 'alert' ) );
	};
	return (
		<div className="hdh-views hdh-noprint" style={ { padding: 0, marginBottom: 14 } }>
			<div className="hdh-views__list" role="toolbar" aria-label={ __( 'Saved reports', 'helpdesk-hero-pro' ) }>
				{ all.map( ( v ) => (
					<button
						key={ `${ v.scope }-${ v.id }` }
						type="button"
						className={ `hdh-view ${ active && active.id === v.id && active.scope === v.scope ? 'is-active' : '' }` }
						title={
							v.scope === 'shared'
								? __( 'Shared with the team', 'helpdesk-hero-pro' )
								: __( 'Only you see this report', 'helpdesk-hero-pro' )
						}
						onClick={ () => onLoad( v ) }
					>
						<Icon name="chart" size={ 13 } />
						{ v.name }
					</button>
				) ) }
			</div>
			<div className="hdh-views__actions">
				{ ! naming && (
					<Button size="sm" variant="ghost" icon="plus" onClick={ () => setNaming( true ) }>
						{ __( 'Save as report', 'helpdesk-hero-pro' ) }
					</Button>
				) }
				{ active && ! naming && ( active.scope === 'personal' || hub.canManage ) && (
					<Button size="sm" variant="ghost" icon="trash" onClick={ remove }>
						{ __( 'Delete report', 'helpdesk-hero-pro' ) }
					</Button>
				) }
				{ naming && (
					<span className="hdh-row" style={ { gap: 6 } }>
						<input
							className="hdh-input"
							style={ { width: 200 } }
							aria-label={ __( 'Report name', 'helpdesk-hero-pro' ) }
							placeholder={ __( 'For example: VIP response times', 'helpdesk-hero-pro' ) }
							value={ name }
							maxLength={ 40 }
							// eslint-disable-next-line jsx-a11y/no-autofocus
							autoFocus
							onChange={ ( e ) => setName( e.target.value ) }
							onKeyDown={ ( e ) => e.key === 'Enter' && name.trim() && save() }
						/>
						<select
							className="hdh-input hdh-select"
							aria-label={ __( 'Who sees it', 'helpdesk-hero-pro' ) }
							value={ scope }
							onChange={ ( e ) => setScope( e.target.value ) }
						>
							<option value="personal">{ __( 'Just me', 'helpdesk-hero-pro' ) }</option>
							{ hub.canManage && (
								<option value="shared">{ __( 'Whole team', 'helpdesk-hero-pro' ) }</option>
							) }
						</select>
						<Button size="sm" variant="primary" disabled={ ! name.trim() } onClick={ save }>
							{ __( 'Save', 'helpdesk-hero-pro' ) }
						</Button>
						<Button size="sm" variant="ghost" onClick={ () => setNaming( false ) }>
							{ __( 'Cancel', 'helpdesk-hero-pro' ) }
						</Button>
					</span>
				) }
			</div>
		</div>
	);
}

/**
 * The tickets behind the numbers (same filters), paged.
 *
 * @param {Object} props         Props.
 * @param {Object} props.filters Filters.
 * @return {JSX.Element} Card.
 */
function TicketList( { filters } ) {
	const [ page, setPage ] = useState( 1 );
	const [ perPage, setPerPage ] = useState( 20 );
	const [ data, setData ] = useState( null );
	const key = JSON.stringify( filters );
	useEffect( () => setPage( 1 ), [ key ] );
	useEffect( () => {
		apiFetch( {
			path: addQueryArgs( '/helpdesk-hero-hub/v1/admin/tickets', {
				...filters,
				orderby: 'created',
				order: 'desc',
				page,
				per_page: perPage,
			} ),
		} )
			.then( setData )
			.catch( () => setData( { tickets: [], total: 0 } ) );
	}, [ key, page, perPage ] ); // eslint-disable-line react-hooks/exhaustive-deps
	return (
		<Card
			title={ __( 'Tickets', 'helpdesk-hero-pro' ) }
			sub={
				data
					? sprintf(
							/* translators: %d: number of tickets */
							_n( '%d ticket matches.', '%d tickets match.', data.total || 0, 'helpdesk-hero-pro' ),
							data.total || 0
					  )
					: null
			}
			bodyClass={ null }
		>
			{ ! data ? (
				<Loading />
			) : (
				<>
					<div className="hdh-table-wrap">
						<table className="hdh-table">
							<thead>
								<tr>
									<th scope="col">{ __( 'Ticket', 'helpdesk-hero-pro' ) }</th>
									<th scope="col">{ __( 'Site', 'helpdesk-hero-pro' ) }</th>
									<th scope="col">{ __( 'Status', 'helpdesk-hero-pro' ) }</th>
									<th scope="col">{ __( 'Opened', 'helpdesk-hero-pro' ) }</th>
								</tr>
							</thead>
							<tbody>
								{ data.tickets.map( ( t ) => (
									<tr key={ t.id }>
										<td>
											<a href={ `#/ticket/${ t.id }` }>
												#{ t.id } { t.subject }
											</a>
										</td>
										<td>{ t.site_name }</td>
										<td>{ STATUS_TEXT[ t.status ] || t.status }</td>
										<td title={ when( t.created_at ) }>{ ago( t.created_at ) }</td>
									</tr>
								) ) }
							</tbody>
						</table>
					</div>
					<div className="hdh-noprint" style={ { padding: '0 18px 14px' } }>
						<Pager
							page={ page }
							perPage={ perPage }
							total={ data.total || 0 }
							onPage={ setPage }
							onPer={ ( n ) => {
								setPerPage( n );
								setPage( 1 );
							} }
						/>
					</div>
				</>
			) }
		</Card>
	);
}

export default function Explorer() {
	const toast = useToast();
	const inbox = ( window.helpdeskHeroHub || {} ).inbox || {};
	const { FilterButton, FilterChips, filterDefs } = inbox;
	const [ filters, setFilters ] = useState( () => ( {
		status: 'all',
		from: daysAgo( 29 ),
		to: daysAgo( 0 ),
	} ) );
	const [ group, setGroup ] = useState( 'site' );
	const [ data, setData ] = useState( null );
	const [ error, setError ] = useState( null );
	const team = useHubData( 'admin/team' );
	const tags = useHubData( 'admin/tags' );
	const tiers = useHubData( 'admin/tiers' );
	const defs = useMemo(
		() =>
			filterDefs
				? filterDefs( {
						team: team ? team.team : [],
						tags: tags ? tags.tags : [],
						tiers: tiers ? tiers.tiers : [],
				  } )
				: {},
		[ team, tags, tiers, filterDefs ]
	);
	const key = JSON.stringify( [ filters, group ] );
	useEffect( () => {
		setError( null );
		send( addQueryArgs( 'analytics/explore', { ...filters, group } ) )
			.then( setData )
			.catch( setError );
	}, [ key ] ); // eslint-disable-line react-hooks/exhaustive-deps

	const set = ( k, v ) =>
		setFilters( ( f ) => {
			const next = { ...f, [ k ]: v };
			if ( v === '' || v === undefined ) {
				delete next[ k ];
			}
			return next;
		} );
	const narrow = ( k, v ) => {
		set( k, v );
		toast( __( 'Filter added. Remove it from the chips above.', 'helpdesk-hero-pro' ), 'info', { duration: 2500 } );
	};

	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ () => setFilters( { ...filters } ) } />;
	}
	if ( ! data ) {
		return <Loading />;
	}
	const k = data.kpis;
	const timeOn = !! ( ( window.hdhProBoot || {} ).modules || {} ).time;
	const days = Math.round( ( new Date( data.to ) - new Date( data.from ) ) / 86400000 ) + 1;
	const preset = PRESETS.find( ( [ d ] ) => d === days && data.to === daysAgo( 0 ) );
	const breakdowns = [
		[ 'status', __( 'Status', 'helpdesk-hero-pro' ) ],
		[ 'priority', __( 'Priority', 'helpdesk-hero-pro' ) ],
		[ 'category', __( 'Category', 'helpdesk-hero-pro' ) ],
		[ 'tag', __( 'Tags', 'helpdesk-hero-pro' ) ],
		[ 'site', __( 'Sites', 'helpdesk-hero-pro' ) ],
		[ 'rating', __( 'Ratings', 'helpdesk-hero-pro' ) ],
	].filter( ( [ id ] ) => data.breakdowns[ id ] && data.breakdowns[ id ].length );

	return (
		<div className="hdh-explorer">
			<PageHead
				title={ __( 'Analytics', 'helpdesk-hero-pro' ) }
				lede={ sprintf(
					/* translators: 1: start date, 2: end date */
					__( 'Tickets opened %1$s – %2$s. Click any chart, bar or row to narrow down.', 'helpdesk-hero-pro' ),
					data.from,
					data.to
				) }
			>
				<span className="hdh-noprint">
					<Button size="sm" icon="download" onClick={ () => window.print() }>
						{ __( 'Print or save as PDF', 'helpdesk-hero-pro' ) }
					</Button>
				</span>
			</PageHead>

			<SavedReports
				current={ { filters, group } }
				onLoad={ ( v ) => {
					setFilters( { status: 'all', ...v.filters } );
					setGroup( v.group || 'site' );
				} }
			/>

			<div className="hdh-card hdh-noprint" style={ { marginBottom: 16 } }>
				<div className="hdh-explorer__bar">
					<div className="hdh-tabs" role="group" aria-label={ __( 'Period', 'helpdesk-hero-pro' ) }>
						{ PRESETS.map( ( [ d, label ] ) => (
							<button
								key={ d }
								type="button"
								aria-pressed={ !! preset && preset[ 0 ] === d }
								className={ `hdh-tabs__tab ${ preset && preset[ 0 ] === d ? 'is-active' : '' }` }
								onClick={ () =>
									setFilters( ( f ) => ( { ...f, from: daysAgo( d - 1 ), to: daysAgo( 0 ) } ) )
								}
							>
								{ label }
							</button>
						) ) }
					</div>
					<input
						type="date"
						className="hdh-input"
						aria-label={ __( 'From', 'helpdesk-hero-pro' ) }
						value={ filters.from || data.from }
						onChange={ ( e ) => set( 'from', e.target.value ) }
					/>
					<input
						type="date"
						className="hdh-input"
						aria-label={ __( 'Until', 'helpdesk-hero-pro' ) }
						value={ filters.to || data.to }
						onChange={ ( e ) => set( 'to', e.target.value ) }
					/>
					<select
						className="hdh-input hdh-select"
						aria-label={ __( 'Status', 'helpdesk-hero-pro' ) }
						value={ filters.status || 'all' }
						onChange={ ( e ) => set( 'status', e.target.value ) }
					>
						<option value="all">{ __( 'Any status', 'helpdesk-hero-pro' ) }</option>
						<option value="active">{ __( 'Not closed', 'helpdesk-hero-pro' ) }</option>
						{ Object.keys( STATUS_TEXT ).map( ( s ) => (
							<option key={ s } value={ s }>
								{ STATUS_TEXT[ s ] }
							</option>
						) ) }
					</select>
					{ FilterButton && (
						<FilterButton
							filters={ Object.fromEntries(
								Object.entries( filters ).filter( ( [ f ] ) => ! [ 'from', 'to' ].includes( f ) )
							) }
							defs={ defs }
							onChange={ set }
							dates={ false }
						/>
					) }
					<label className="hdh-inline-field">
						<span>{ __( 'Group by', 'helpdesk-hero-pro' ) }</span>
						<select
							className="hdh-input hdh-select"
							value={ group }
							onChange={ ( e ) => setGroup( e.target.value ) }
						>
							{ Object.keys( data.groups ).map( ( g ) => (
								<option key={ g } value={ g }>
									{ data.groups[ g ] }
								</option>
							) ) }
						</select>
					</label>
				</div>
				{ FilterChips && (
					<div style={ { padding: '0 18px 12px' } }>
						<FilterChips
							filters={ Object.fromEntries(
								Object.entries( filters ).filter( ( [ f ] ) => ! [ 'from', 'to' ].includes( f ) )
							) }
							defs={ defs }
							onRemove={ ( f ) => set( f, '' ) }
							onClear={ () =>
								setFilters( { status: 'all', from: filters.from, to: filters.to } )
							}
						/>
					</div>
				) }
			</div>

			{ data.capped && (
				<p className="hdh-muted">
					{ __( 'Only the first 5,000 tickets are counted. Choose a shorter period or more filters.', 'helpdesk-hero-pro' ) }
				</p>
			) }

			<div className="hdh-kpis is-4" style={ { marginBottom: 16 } }>
				<Kpi
					label={ __( 'Tickets', 'helpdesk-hero-pro' ) }
					value={ k.tickets }
					foot={
						/* translators: %d: closed tickets */
						sprintf( __( '%d closed', 'helpdesk-hero-pro' ), k.closed )
					}
				/>
				<Kpi label={ __( 'Median first reply', 'helpdesk-hero-pro' ) } value={ hours( k.first_response ) } />
				<Kpi label={ __( 'Median resolution', 'helpdesk-hero-pro' ) } value={ hours( k.resolution ) } />
				<Kpi
					label={ __( 'SLA met', 'helpdesk-hero-pro' ) }
					value={ k.sla_met === null ? '—' : `${ k.sla_met }%` }
					foot={ k.sla_met === null ? __( 'No SLA targets in this period', 'helpdesk-hero-pro' ) : null }
				/>
				<Kpi
					label={ __( 'Average rating', 'helpdesk-hero-pro' ) }
					value={ k.rating === null ? '—' : `${ k.rating } ★` }
					foot={
						/* translators: %d: ratings */
						sprintf( _n( '%d rating', '%d ratings', k.ratings, 'helpdesk-hero-pro' ), k.ratings )
					}
				/>
				{ timeOn && (
					<>
						<Kpi label={ __( 'Time logged', 'helpdesk-hero-pro' ) } value={ hours( k.hours ) } />
						<Kpi label={ __( 'Billable', 'helpdesk-hero-pro' ) } value={ hours( k.billable_hours ) } />
						<Kpi label={ __( 'Amount', 'helpdesk-hero-pro' ) } value={ money( k.amount, data.currency ) } />
					</>
				) }
			</div>

			{ ! k.tickets ? (
				<Card>
					<Empty
						compact
						title={ __( 'No tickets match.', 'helpdesk-hero-pro' ) }
						text={ __( 'Choose a longer period or remove a filter.', 'helpdesk-hero-pro' ) }
					/>
				</Card>
			) : (
				<>
					<Card
						title={ __( 'Tickets per day', 'helpdesk-hero-pro' ) }
						sub={ __( 'Click a day to see only that day.', 'helpdesk-hero-pro' ) }
						style={ { marginBottom: 16 } }
					>
						<StackedColumns
							title={ __( 'Tickets opened and closed per day', 'helpdesk-hero-pro' ) }
							dates={ data.series.dates }
							series={ [
								{ id: 'opened', label: __( 'Opened', 'helpdesk-hero-pro' ), values: data.series.opened, color: 'var(--hdh-s1)' },
								{ id: 'closed', label: __( 'Closed', 'helpdesk-hero-pro' ), values: data.series.closed, color: 'var(--hdh-s3)' },
							] }
							format={ ( v ) => String( v ) }
							onSelect={ ( day ) => setFilters( ( f ) => ( { ...f, from: day, to: day } ) ) }
						/>
					</Card>

					<div className="hdh-grid" style={ { marginBottom: 16 } }>
						{ breakdowns.map( ( [ id, label ] ) => (
							<Card key={ id } className="hdh-span-4" title={ label }>
								<BarList
									items={ data.breakdowns[ id ].map( ( b ) => ( {
										id: b.value,
										label: b.label,
										value: b.count,
									} ) ) }
									format={ ( v ) => String( v ) }
									onSelect={ ( item ) => {
										if ( id === 'rating' ) {
											setFilters( ( f ) => ( { ...f, rating_min: item.id, rating_max: item.id } ) );
										} else {
											narrow( FILTER_FOR[ id ], item.id );
										}
									} }
								/>
							</Card>
						) ) }
					</div>

					<Card
						title={ sprintf(
							/* translators: %s: grouping, e.g. Site */
							__( 'By %s', 'helpdesk-hero-pro' ),
							( data.groups[ group ] || '' ).toLowerCase()
						) }
						sub={ __( 'Click a row to narrow down to it.', 'helpdesk-hero-pro' ) }
						bodyClass={ null }
						style={ { marginBottom: 16 } }
					>
						<div className="hdh-table-wrap">
							<table className="hdh-table">
								<thead>
									<tr>
										<th scope="col">{ data.groups[ group ] }</th>
										<th scope="col">{ __( 'Tickets', 'helpdesk-hero-pro' ) }</th>
										<th scope="col">{ __( 'First reply', 'helpdesk-hero-pro' ) }</th>
										<th scope="col">{ __( 'Resolution', 'helpdesk-hero-pro' ) }</th>
										<th scope="col">{ __( 'SLA met', 'helpdesk-hero-pro' ) }</th>
										<th scope="col">{ __( 'Rating', 'helpdesk-hero-pro' ) }</th>
										{ timeOn && <th scope="col">{ __( 'Time', 'helpdesk-hero-pro' ) }</th> }
										{ timeOn && <th scope="col">{ __( 'Amount', 'helpdesk-hero-pro' ) }</th> }
									</tr>
								</thead>
								<tbody>
									{ data.table.map( ( r ) => (
										<tr key={ r.value }>
											<td>
												<button
													type="button"
													className="hdh-link-button"
													onClick={ () => narrow( FILTER_FOR[ group ], r.value ) }
												>
													{ r.label }
												</button>
											</td>
											<td>{ r.tickets }</td>
											<td>{ hours( r.first_response ) }</td>
											<td>{ hours( r.resolution ) }</td>
											<td>{ r.sla_met === null ? '—' : `${ r.sla_met }%` }</td>
											<td>{ r.rating === null ? '—' : `${ r.rating } ★` }</td>
											{ timeOn && <td>{ hours( r.hours ) }</td> }
											{ timeOn && <td>{ money( r.amount, data.currency ) }</td> }
										</tr>
									) ) }
								</tbody>
							</table>
						</div>
					</Card>

					<TicketList filters={ filters } />
				</>
			) }
		</div>
	);
}
