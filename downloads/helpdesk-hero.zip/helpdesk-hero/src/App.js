import { __, sprintf } from '@wordpress/i18n';
import { useRoute, useTheme } from './ui/lib/hooks';
import { ToastProvider } from './ui/components/ui';
import Icon from './ui/components/Icon';
import Connect from './pages/Connect';
import Tickets from './pages/Tickets';
import Ticket from './pages/Ticket';
import NewTicket from './pages/NewTicket';
import Access from './pages/Access';
import Activity from './pages/Activity';
import Settings from './pages/Settings';

const boot = window.hdhBoot || {};

const ROUTES = [
	{
		id: 'tickets',
		label: __( 'Tickets', 'helpdesk-hero' ),
		icon: 'inbox',
		Page: Tickets,
	},
	{
		id: 'new',
		label: __( 'New ticket', 'helpdesk-hero' ),
		icon: 'plus',
		Page: NewTicket,
	},
	{
		id: 'access',
		label: __( 'Support access', 'helpdesk-hero' ),
		icon: 'key',
		Page: Access,
	},
	{
		id: 'activity',
		label: __( 'Activity', 'helpdesk-hero' ),
		icon: 'activity',
		Page: Activity,
	},
	{
		id: 'settings',
		label: __( 'Settings', 'helpdesk-hero' ),
		icon: 'settings',
		Page: Settings,
	},
];

const THEMES = [
	{
		id: 'system',
		icon: 'monitor',
		label: __( 'Theme: match system', 'helpdesk-hero' ),
	},
	{ id: 'light', icon: 'sun', label: __( 'Theme: light', 'helpdesk-hero' ) },
	{ id: 'dark', icon: 'moon', label: __( 'Theme: dark', 'helpdesk-hero' ) },
];

export function Shell( { nav, current, children } ) {
	const [ theme, setTheme ] = useTheme();
	const themeIndex = Math.max(
		0,
		THEMES.findIndex( ( t ) => t.id === theme )
	);
	const nextTheme = THEMES[ ( themeIndex + 1 ) % THEMES.length ];
	const branding = boot.branding || {};
	const style = branding.color
		? {
				'--hdh-accent': branding.color,
				'--hdh-accent-hover': branding.color,
		  }
		: undefined;
	return (
		<div
			className="hdh-root"
			data-theme={ theme === 'system' ? undefined : theme }
			style={ style }
		>
			<ToastProvider>
				<header className="hdh-header">
					<div className="hdh-header__inner">
						<div className="hdh-brand">
							{ branding.logo ? (
								<img
									className="hdh-brand__logo"
									src={ branding.logo }
									alt={ boot.supportName }
								/>
							) : (
								<span className="hdh-brand__mark">
									<Icon name="ring" size={ 20 } />
								</span>
							) }
							<span>
								<div className="hdh-brand__name">
									{ boot.centerName ||
										__( 'Get Help', 'helpdesk-hero' ) }
								</div>
								<div className="hdh-brand__sub">
									{ boot.connected
										? sprintf(
												/* translators: %s: support team name */
												__(
													'from %s',
													'helpdesk-hero'
												),
												boot.supportName
										  )
										: __(
												'Not connected yet',
												'helpdesk-hero'
										  ) }
								</div>
							</span>
						</div>
						{ nav && (
							<nav
								className="hdh-nav"
								aria-label={ __(
									'Get Help sections',
									'helpdesk-hero'
								) }
							>
								{ nav.map( ( r ) => (
									<a
										key={ r.id }
										href={ `#/${ r.id }` }
										className={ `hdh-nav__item ${
											r.id === current ? 'is-active' : ''
										}` }
										aria-current={
											r.id === current
												? 'page'
												: undefined
										}
									>
										<Icon name={ r.icon } size={ 15 } />
										{ r.label }
									</a>
								) ) }
							</nav>
						) }
						<div className="hdh-header__end">
							{ branding.url && (
								<a
									className="hdh-btn is-ghost is-sm"
									href={ branding.url }
									target="_blank"
									rel="noopener noreferrer"
								>
									<Icon name="info" size={ 15 } />
									{ __( 'Help center', 'helpdesk-hero' ) }
								</a>
							) }
							<button
								type="button"
								className="hdh-btn is-ghost is-icon"
								onClick={ () => setTheme( nextTheme.id ) }
								title={ THEMES[ themeIndex ].label }
								aria-label={ `${
									THEMES[ themeIndex ].label
								}. ${ __(
									'Click to change.',
									'helpdesk-hero'
								) }` }
							>
								<Icon
									name={ THEMES[ themeIndex ].icon }
									size={ 17 }
								/>
							</button>
						</div>
					</div>
				</header>
				{ children }
				<footer className="hdh-footer">
					<span>{ __( 'Helpdesk Hero', 'helpdesk-hero' ) }</span>
					<span className="hdh-footer__links">
						<span>
							{ sprintf(
								/* translators: %s: plugin version number. */
								__( 'Version %s', 'helpdesk-hero' ),
								boot.version
							) }
						</span>
					</span>
				</footer>
			</ToastProvider>
		</div>
	);
}

export default function App() {
	const [ route, go ] = useRoute( 'tickets' );
	if ( ! boot.connected ) {
		return (
			<Shell>
				<main className="hdh-shell">
					<Connect />
				</main>
			</Shell>
		);
	}
	const [ section, param ] = route.split( '/' );
	const current =
		section === 'ticket'
			? { id: 'tickets', Page: Ticket }
			: ROUTES.find( ( r ) => r.id === section ) || ROUTES[ 0 ];
	const { Page } = current;
	return (
		<Shell nav={ ROUTES } current={ current.id }>
			<main className="hdh-shell" key={ route }>
				<Page go={ go } param={ param } />
			</main>
		</Shell>
	);
}
